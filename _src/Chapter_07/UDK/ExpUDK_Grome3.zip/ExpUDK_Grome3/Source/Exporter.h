//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2009-2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup Plugins Engine SDK Plugins */
/*@{*/

#ifndef __UDK_EXPORT_H
#define __UDK_EXPORT_H

#include "stdafx.h"
#include "tchar.h"
// Include the SDK files
#include <Public/TerrainEd/sdk.h>
#include <Public/ObjectEd/sdk.h>
#include <Public/Common/Math.h>

// Use the SDK namespace.
using namespace csdk;

//====================================================

//! Exporter for Unreal Development Kit.
/*!
*/
class cUDKExport: public iExportPlugin
{
public:

	cUDKExport();
	~cUDKExport();

	// ==============================================
	// Plugin interface

	//! Return the long name (the description) of the interface.
	virtual const char* Description() 
	{ 
#		ifdef D_DEBUG
			return "Unreal Development Kit Export plug-in (Debug)"; 
#		else
			return "Unreal Development Kit Export plug-in"; 
#		endif
	}

	//! Return the id identifying the type of the interface.
	virtual t_type_id Type();

	virtual const char* PluginName() 
	{ 
#		ifdef D_DEBUG
			return "Unreal Development Kit (Debug)"; 
#		else
			return "Unreal Development Kit"; 
#		endif
	}

	//! Return the author of the plug-in.
	virtual const char* Vendor() { return "Quad Software"; }
	//! Return any copyright text.
	virtual const char* CopyrightNotice() { return "Copyright 2009 Quad Software"; }

	//! Called by the engine when the module from which the plug-in is created is unloaded.
	virtual void OnUnloadModule();

	//! Load the plug-in in the system (init its data and make it active).
	virtual t_error Activate(const t_bool activate);
	//! Indicate if the plug-in is active or not.
	virtual t_bool IsActive();

	//! Return the extensions no this plug-in support.
	virtual uint GetFileExtNo() { return 1; }
	//! Return the i-th file extension this plug-in support (only the extension without the point ".").
	virtual const t_char* GetFileExt(const uint idx) { return M_SZ("bmp"); }

	//! Trigger the file export.
	virtual t_error Export(const t_char *file_path);

protected:

	// ==============================================

	// Terrain range.
	t_float3 _terrain_min, _terrain_max;

	//! Utility function to compute the height range of the current scene terrain based on the scene bounding boxes.
	t_error _GetTerrainRange(t_float3 &o_min, t_float3 &o_max);
	//! Computes the scale and bias to be used so the initial min and max is put into a new min and max (user defined range).
	void _GetHMScaleBiasFromRange(float initial_min, float initial_max, float min, float max, float &o_scale, float &o_bias);

	//! Scaling factor for heightmaps.
	float _hm_scale;
	//! Bias factor for heightmaps.
	float _hm_bias;

	// ==============================================
	// Export (user) parameters.

	//! Write user options.
	void _WriteOptions();
	//! Read user options.
	void _ReadOptions();

	//! Export only selected zones.
	bool _param_exp_selected;
	//! Don't export swapped zones.
	bool _param_dont_exp_swapped;

	//! Export heightmaps.
	bool _param_exp_heightmap;
	//! Min of the normalization interval for heightmaps.
	float _param_hm_min_interval;
	//! Max of the normalization interval for heightmaps.
	float _param_hm_max_interval;

	//! Export texture layer masks.
	bool _param_exp_masks;
	//! Export terrain tile textures.
	bool _param_exp_tile_textures;

	// ==============================================
	// UI

	//! [Windows Specific] Main dialog procedure.
	static BOOL CALLBACK _MainDlgProc(HWND hWnd, 
		UINT message, WPARAM wParam, LPARAM lParam);

	static void _MainDlgProc_SetOptionsToUI(HWND hWnd);
	static void _MainDlgProc_GetOptionsFromUI(HWND hWnd);

	// ==============================================
	// Exporting

	//! Function called to export the file (from the main dialog).
	t_error _DoExport(const t_char *file_path, HWND hWnd);

	//! Called to export terrain data.
	t_error _Export_TerrainProject(t_string &export_file, t_string &export_path, 
		iTerrainEdProject *terrain_project, iProcessingManager *proc_man);

	t_error _Save16bitBmp(const t_char *file_name, void *data, uint dx, uint dy);
	
	//! Images exported as tiled textures from terrain.
	/*! This array is used to avoid exporting the same images multiple times. */
	t_dyn_array<iImage*> _exported_images;
	void _ClearExportedImages();

};

//====================================================

//! Plug-in export function.
extern "C" D_EXPORT void* GetPluginInterface(void *sdk_root);

//! Plug-in instance.
extern cUDKExport g_export_plugin;

//! Pointer to the SDK root interface (received in \c GetPluginInterface).
extern iRootInterface *g_sdk_root;

//! Pointer to the storage manager used for various file related operations.
extern iStorageManager *g_storage_man;

//! [Windows specific] Handle to the module (need this for the plug-in dialog)
extern HINSTANCE g_hInstance;

//====================================================
#endif
/*@}*/