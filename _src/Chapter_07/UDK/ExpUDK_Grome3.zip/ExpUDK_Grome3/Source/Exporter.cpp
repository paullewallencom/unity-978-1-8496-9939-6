//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2008 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup Plugins Engine SDK Plugins */
/*@{*/

#include "Exporter.h"
#include <stdio.h>
#include <float.h>
#include <math.h>

// [Windows specific]
#include "windows.h"
#include "resource.h"
#include <Htmlhelp.h>

//====================================================

void* GetPluginInterface(void *sdk_root) 
{
	g_sdk_root = (iRootInterface*)sdk_root;

	// Verify if the editor SDK version (the parameter SDK root interface version) 
	// is the same as the SDK version this exporter was written for.
	if(g_sdk_root->Version() != C_CORE_SDK_VERSION)
	{
		// Different version, refuse to start.
		g_sdk_root = NULL;
		return NULL;
	}

	// Obtain the storage manager interface.
	g_storage_man = (iStorageManager*)g_sdk_root->GetInterface(C_STORAGEMANAGER_INTERFACE_NAME);
	if(!g_storage_man)
		return NULL;

	return &g_export_plugin; 
}

cUDKExport g_export_plugin;

iRootInterface *g_sdk_root = NULL;
iStorageManager *g_storage_man = NULL;

HINSTANCE g_hInstance;

//====================================================

cUDKExport::cUDKExport()
{
	_param_exp_selected = false;
	_param_dont_exp_swapped = false;

	_param_exp_heightmap = true;

	_hm_scale = 1.f; _hm_bias = 0.f;
	_param_hm_min_interval = 0.f;
	_param_hm_max_interval = USHRT_MAX;

	_param_exp_masks = true;
	_param_exp_tile_textures = true;
}

cUDKExport::~cUDKExport()
{
	_ClearExportedImages();
}

t_type_id cUDKExport::Type()
{
	// Return the type id from the SDK root.
	if(g_sdk_root)
	{
		return g_sdk_root->GetTypeId("Plugin");
	}
	return NULL;
}

void cUDKExport::OnUnloadModule()
{
	// Nothing to do here.
}

t_error cUDKExport::Activate(const t_bool activate)
{
	// Nothing to do here.
	return C_GENERIC_SUCCESS;
}

t_bool cUDKExport::IsActive()
{
	// Nothing to do here.
	return C_FALSE;
}

// ========================================================

t_error cUDKExport::_GetTerrainRange(t_float3 &o_min, t_float3 &o_max)
{
	iEditor *editor = (iEditor*)g_sdk_root->GetInterface(C_EDITOR_INTERFACE_NAME);

	iEdWorkspace *workspace = editor->GetCurrWorkspace();
	if(workspace == NULL) return NULL;

	t_readonly_array<iEdProject*> *projects = workspace->GetProjects();
	if(!projects->No())
	{
		o_min =  0.f;
		o_max = 0.f;
		return C_GENERIC_SUCCESS;
	}

	o_min = FLT_MAX;
	o_max = -FLT_MAX;

	// Cycle through all the terrain projects and get the minimum and maximum heights from the terrain zones.
	for(uint i=0; i<projects->No(); i++)
	{
		t_type_id type_id = projects->Elem(i)->GetProjectType();
		
		// Check the project type.
		if(type_id == g_sdk_root->GetTypeId(iTerrainEdProject::TypeString()))
		{
			// This is a terrain editing project, so we can cast the interface to a more specialized project interface.
			iTerrainEdProject *terrain_project = (iTerrainEdProject*)projects->Elem(i)->OpenSubinterface(type_id);
			if(terrain_project)
			{
				t_readonly_array<iTerrainZone*> *zones = terrain_project->GetTerrainZones();

				for(uint j=0; j<zones->No(); j++)
				// We compute the range for all the zones (swapped, selected etc).
				//if(!_param_exp_selected || zones->Elem(j)->IsSelected())
				{
					const t_float3* bbox = zones->Elem(j)->GetBBox();
					if(bbox)
					{
						//Check min extents
						if(bbox[0].x < o_min.x)
							o_min.x = bbox[0].x;

						if(bbox[0].y < o_min.y)
							o_min.y = bbox[0].y;

						if(bbox[0].z < o_min.z)
							o_min.z = bbox[0].z;

						//Check max extents
						if(bbox[7].x > o_max.x)
							o_max.x = bbox[7].x;

						if(bbox[7].y > o_max.y)
							o_max.y = bbox[7].y;
						
						if(bbox[7].z > o_max.z)
							o_max.z = bbox[7].z;
					}
				}

				// Close the zones interfaces.
				gCloseInterfaces(zones);

				terrain_project->CloseInterface();
			}
		}
	}

	if(o_min.y == FLT_MAX)
	{
		o_min = 0.f;
		o_max = 0.f;
	}

  	gCloseInterfaces(projects);

	return C_GENERIC_SUCCESS;
}

void cUDKExport::_GetHMScaleBiasFromRange(float initial_min, float initial_max, float min, float max, float &o_scale, float &o_bias)
{
	float range = initial_max - initial_min;
	if(range)
	{
		o_scale = (max - min) / range;
	}
	else
	{
		o_scale = 1.f;
	}

	o_bias = min - initial_min;
}

// ========================================================

t_error cUDKExport::Export(const t_char *file_path)
{
	if(g_sdk_root == NULL) 
		return C_NULLOBJ_ERR;

	// Obtain the interface to the editor framework as it is registered with the SDK root interface.
	iEditor *editor = (iEditor*)g_sdk_root->GetInterface(C_EDITOR_INTERFACE_NAME);

	if(editor == NULL)
	{
		MessageBox(NULL, _T("Cannot obtain interface to the editor application!")_T("\r\nConsult the console for more details."),
			_T("Error"), MB_OK | MB_ICONERROR);
		return C_NULLOBJ_ERR;
	}

	// Read previously used options from registry.
	_ReadOptions();

	_ClearExportedImages();

	iWindow *win = editor->GetMainWindow();
	if(win == NULL || win->GetOSSpecific() == NULL)
	{
		MessageBox(NULL, _T("Cannot obtain interface to the main window!")_T("\r\nConsult the console for more details."),
			_T("Error"), MB_OK | MB_ICONERROR);
		return C_NULLOBJ_ERR;
	}

	// Determine the current scene terrain range (used for raw normalization).
	_GetTerrainRange(_terrain_min, _terrain_max);

	// Show the main dialog to get the user preferences.
	DialogBoxParam(g_hInstance, MAKEINTRESOURCE(IDD_MAINDIALOG),
		(HWND)win->GetOSSpecific(), (DLGPROC)_MainDlgProc, (LPARAM)file_path);

	// Close the interfaces.
	win->CloseInterface();
	editor->CloseInterface();

	_ClearExportedImages();

	return C_GENERIC_SUCCESS;
}

t_error cUDKExport::_DoExport(const t_char *file_path, HWND hWnd)
{
	// Obtain the interface to the editor framework as it is registered with the SDK root interface.
	iEditor *editor = (iEditor*)g_sdk_root->GetInterface(C_EDITOR_INTERFACE_NAME);

	// Obtain the interface to the current scene workspace.
	iEdWorkspace *workspace = editor->GetCurrWorkspace();

	if(workspace == NULL)
	{
		MessageBox(NULL, _T("No current scene!"), _T("Error"), MB_OK | MB_ICONERROR);
		editor->CloseInterface();
		return C_NULLOBJ_ERR;
	}

	// Obtain the processing manager interface to show a progress while saving the file.
	iProcessingManager *proc_man = editor->GetProcessingManager();
	if(proc_man == NULL) 
		return C_NULLOBJ_ERR; // This should never happen.

	proc_man->BeginProcess(M_SZ("Exporting data"));

	// Compute the scale and bias so the current terrain range is put in the user defined range (normalization).
	_GetHMScaleBiasFromRange(_terrain_min.y, _terrain_max.y, 
		_param_hm_min_interval, _param_hm_max_interval,
		_hm_scale, _hm_bias);

	// Go through all the projects in the current workspace and export their content.
	t_readonly_array<iEdProject*> *projects = workspace->GetProjects();

	// Find out the export path.
	const t_char *dir = g_storage_man->ExtractFileDir(file_path);
	t_string export_path;
	if(dir) export_path = dir;

	const t_char *file_name = g_storage_man->ExtractFileName(file_path);
	t_string export_file;
	if(file_name) 
	{
		t_string export_file_with_ext = file_name;
		file_name = g_storage_man->ExtractFileWithoutExt(export_file_with_ext.Sz());
		if(file_name)
			export_file = file_name;
	}
		
	if(export_path.Length() == 0 || export_file.Length() == 0) 
	{
		MessageBox(NULL, _T("Error obtaining the export path"), _T("I/O Error"), MB_OK|MB_ICONERROR);

		// Close the interfaces.
		gCloseInterfaces(projects);
		workspace->CloseInterface();
		editor->CloseInterface();

		return C_STOR_CREATE_ERR;
	}

	t_error ret_code = C_GENERIC_SUCCESS;

	if(projects->No())
	{
		//float per_proj_progress = 100.f / projects->No();

		for(uint i=0; i<projects->No(); i++)
		{
			// Setup the project indicator subrange.
			//proc_man->SubprocessProgressRange(i*per_proj_progress, (i+1)*per_proj_progress);

			// Check the project type.
			t_type_id type_id = projects->Elem(i)->GetProjectType(); 
			if(type_id == g_sdk_root->GetTypeId(iTerrainEdProject::TypeString()))
			{
				iTerrainEdProject *ed_project = (iTerrainEdProject*)projects->Elem(i)->OpenSubinterface(type_id);
				if(ed_project)
				{
					ret_code = _Export_TerrainProject(export_file, export_path, ed_project, proc_man);
					ed_project->CloseInterface();

					if(M_FAILED(ret_code))
						break;
				}
			}

			//proc_man->UpdateCurrProcess((i+1)*per_proj_progress);
		}
	}

	// Close the interfaces.
	gCloseInterfaces(projects);
	workspace->CloseInterface();
	editor->CloseInterface();

	// Mark the end of the export.
	if(M_FAILED(ret_code))
		proc_man->UpdateCurrProcess(100.f, M_SZ("Error(s) occured while exporting!"));
	else
		proc_man->UpdateCurrProcess(100.f, M_SZ("Data exported successfuly"));
	proc_man->EndCurrProcess();

	_WriteOptions();

	return ret_code;
}

t_error cUDKExport::_Export_TerrainProject(t_string &export_file, t_string &export_path, 
			iTerrainEdProject *terrain_project, iProcessingManager *proc_man)
{
	// List of terrain zones.
	t_readonly_array<iTerrainZone*> *zones = terrain_project->GetTerrainZones();
	
	if(!zones || !zones->No()) // No data in this project.
	{
		return C_GENERIC_SUCCESS;
	}

	uint zones_no = zones->No();

	if(_param_exp_selected)
	{
		zones_no = 0;
		for(uint Z=0; Z<zones->No(); Z++)
		if(zones->Elem(Z)->IsSelected())
		{
			if(!_param_dont_exp_swapped || !zones->Elem(Z)->IsSwapped())
				zones_no ++;
		}
	}

	if(!zones_no)
	{
		gCloseInterfaces(zones);
		return C_GENERIC_SUCCESS;
	}

	// Obtain the interface to the editor framework as it is registered with the SDK root interface.
	iTerrainEd *terrain_editor = (iTerrainEd*)g_sdk_root->GetInterface(C_TERRAINED_INTERFACE_NAME);
	if(!terrain_editor) return C_NULLOBJ_ERR;

	// ===================================

	t_string wide_str;
	t_string img_name;
	float per_zone_progress = 100.f / zones_no;

	uint curr_zone = 0;
	for(uint j=0; j<zones->No(); j++)
	{
		iTerrainZone *terrain_zone = zones->Elem(j);

		t_bool is_selected = terrain_zone->IsSelected();
		t_bool is_swapped = terrain_zone->IsSwapped();

		if((_param_exp_selected && !is_selected) || // We export only selected zones and this is one is not selected.
			(_param_dont_exp_swapped && is_swapped))
		{
			curr_zone ++;
			continue;
		}

		if(is_swapped) // Unswap if necessary.
		{
			if(M_FAILED(terrain_zone->UnswapData()))
			{
				curr_zone ++;
				continue;
			}
		}

		wide_str = M_SZ("Exporting zone ");
		wide_str += terrain_zone->Name();
		proc_man->SubprocessProgressRange(curr_zone*per_zone_progress, curr_zone*per_zone_progress + per_zone_progress);
		proc_man->BeginProcess(wide_str);
		proc_man->SubprocessProgressRange(0, 100);
		proc_man->BeginProcess(M_SZ(""));

		// Heightmap size: number of tiles (which is normaly power of two) + 1 pixels.
		uint hm_x_no =  terrain_zone->GetXTilesNo() + 1;
		uint hm_z_no =  terrain_zone->GetZTilesNo() + 1;

		const char* zone_name = terrain_zone->Name();

		if(_param_exp_heightmap)
		{
			const float *heightmap = terrain_zone->GetHeightmap();
			if(heightmap)
			{
				wide_str = M_SZ("Saving heightmap");
				proc_man->UpdateCurrProcess(0, wide_str);

				img_name = export_path;
				img_name += M_SZ("\\");
				img_name += zone_name;
				img_name += M_SZ("_HM.bmp");

				ushort *hm_img = (ushort*)malloc(hm_x_no*hm_z_no*sizeof(ushort));

				// Fill the data from the heightmap.
				for(uint z=0; z<hm_z_no; z++)
				{
					uint row = z * hm_x_no;
					for(uint x=0; x<hm_x_no; x++)
					{
						// Compute the raw heightmap value by applying the bias and scale.
						// [NOTE] Use integer so we can save unsigned short values, too.
						int hm = (int)((heightmap[row + x] + _hm_bias) * _hm_scale);

						// Cap the integer to (unsigned) short.
						if(hm > USHRT_MAX)
							hm = USHRT_MAX;
						else
						if(hm < SHRT_MIN)
							hm = SHRT_MIN;

						//hm_img[(hm_z_no - z - 1) * hm_x_no + x] = (ushort)hm;
						hm_img[z * hm_x_no + x] = (ushort)hm;
					}
				}

				_Save16bitBmp(img_name, hm_img, hm_x_no, hm_z_no);

				free(hm_img);
			}
		}

		if(_param_exp_masks || _param_exp_tile_textures)
		{
			t_readonly_array<iEditorLayer*>* layers = terrain_zone->GetAssignedLayers(iTerrainMaterialLayer::TypeString());

			if(layers)
			{
				for(uint k=0; k<layers->No(); k++)
				{
					// Get the material layer interface
					iTerrainMaterialLayer* material_layer = (iTerrainMaterialLayer*)layers->Elem(k);

					// Get the material definition for this zone
					const sMaterialDefinition* material_def = material_layer->GetMaterial(terrain_zone);
					if(!material_def)
						continue;

					// Enumerate the texture channels
					for(uint t = 0; t < material_def->channels_no; t++)
					{
						sTextureChannel* texture_channel = &material_def->channels[t];
						switch(texture_channel->id)
						{
							case C_TEX_CHANNEL_TEXTURE:
								if(_param_exp_tile_textures)
								{
									iImage *img = texture_channel->source->GetImage();
									if(img)
									{
										// Check to see if this image was already saved.
										t_bool already_exported = C_FALSE;
										for(uint i=0; i<_exported_images.No(); i++)
										if(_exported_images.Elem(i) == img)
											already_exported = C_TRUE;
										
										if(already_exported == C_FALSE)
										{
											wide_str = M_SZ("Saving tile image "); wide_str += img->Name();
											proc_man->UpdateCurrProcess(50, wide_str);
											img->CopyTo(export_path + M_SZ("\\") + img->Name());
											
											_exported_images.Add(img);
											img->ReferInterface();
										}

										img->CloseInterface();
									}
								}
								break;

							case C_TEX_CHANNEL_MASK:
								if(_param_exp_masks)
								{
									iImage *img = texture_channel->source->GetImage();
									if(img)
									{
										wide_str = M_SZ("Saving mask image for layer "); wide_str += material_layer->UserDefName();
										proc_man->UpdateCurrProcess(50, wide_str);

										// Resize the image to be the size of the heightmap (a UDK request).
										iImage *mask_img = (iImage*)g_sdk_root->NewNode(C_NODE_FACTORY_IMAGE, NULL, NULL, NULL);
		
										mask_img->MakeBlank(C_IMG_TYPE_BMP, img->Width(), img->Height(), img->GetBPP(), img->GetPixelFormat(), img->GetDataType(), NULL);

										mask_img->PutPixels(0, 0, img->GetBuffer(0, 0), img->Width(), img->Height());

										mask_img->Scale(hm_x_no, hm_z_no);

										// Fill the data from the mask to the 16bit bmp format.
										uchar *mask_data = (uchar*)mask_img->GetBuffer(0, 0);
										ushort *mask_data_16bit = (ushort*)malloc(hm_x_no*hm_z_no*sizeof(ushort));
										for(uint z=0; z<hm_z_no; z++)
										{
											uint row = z * hm_x_no;
											for(uint x=0; x<hm_x_no; x++)
											{
												const uint pos = z * hm_x_no + x;
												mask_data_16bit[pos] = 256 * (ushort)mask_data[pos];
											}
										}

										img_name = export_path;
										img_name += M_SZ("\\");
										img_name += zone_name;
										img_name += M_SZ("_");
										img_name += material_layer->UserDefName();
										img_name += M_SZ(".bmp");

										_Save16bitBmp(img_name, mask_data_16bit, hm_x_no, hm_z_no);

										free(mask_data_16bit);
										g_sdk_root->DelNode(mask_img);
										img->CloseInterface();
									}
								}
								break;

						}
					}
				}
			}
		}

		// Restore zone status.
		if(is_swapped)
			terrain_zone->SwapData();
		if(is_selected)
			terrain_zone->Select(C_TRUE);

		proc_man->EndCurrProcess();
		proc_man->EndCurrProcess();

		curr_zone ++;
	}

	// ================================

	// Close the zones interfaces.
	gCloseInterfaces(zones);
	terrain_editor->CloseInterface();

	// ================================

	return C_GENERIC_SUCCESS;
}

/*! This is the G16 (16bit) bitmap saving. This is not standard because:
- bitmap doesn't support 16 bit per channel
- all bitmaps must have their rows aligned to 32bits while this format doesn't require it. */
t_error cUDKExport::_Save16bitBmp(const t_char *file_name, void *data, uint dx, uint dy)
{
	BITMAPFILEHEADER bitmapfileheader;
	bitmapfileheader.bfType = 0x4D42;
	bitmapfileheader.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + dx * dy * sizeof(ushort);
	bitmapfileheader.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
	bitmapfileheader.bfReserved1 = 0;
	bitmapfileheader.bfReserved2 = 0;

#	ifdef D_UNICODE
	FILE *file = _wfopen(file_name, M_SZ("wb"));
#	else
	FILE *file = fopen(file_name, "wb");
#	endif

	if(!file)
		return C_STOR_OPEN_ERR;

	fwrite(&bitmapfileheader, sizeof(bitmapfileheader), 1, file);

	BITMAPINFOHEADER bih;
	bih.biSize = sizeof(BITMAPINFOHEADER);
	bih.biWidth = dx;
	bih.biHeight = dy;
	bih.biPlanes = 1;
	bih.biBitCount = 16;
  	bih.biCompression = 0; 
  	bih.biSizeImage = dx * dy * sizeof(ushort);
  	bih.biXPelsPerMeter = 2835;	// 72 dpi 
  	bih.biYPelsPerMeter = 2835;	// 72 dpi 
  	bih.biClrUsed = 0;
  	bih.biClrImportant = 0;

	fwrite(&bih, sizeof(bih), 1, file);

	fwrite(data, sizeof(ushort), dx * dy, file);

	fclose(file);

	return C_GENERIC_SUCCESS;
}

void cUDKExport::_ClearExportedImages()
{
	for(uint i=0; i<_exported_images.No(); i++)
	{
		_exported_images.Elem(i)->CloseInterface();
	}
	_exported_images.Reset();
}

//====================================================

/*! [Window specific] */
BOOL CALLBACK cUDKExport::_MainDlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static const t_char *exp_path = NULL;
	static bool init_dialog = false;

	switch(message) 
	{
		case WM_INITDIALOG:

			init_dialog = true;

			exp_path = (const t_char*)lParam;
			
			_MainDlgProc_SetOptionsToUI(hWnd);

			init_dialog = false;

			return TRUE;

		case WM_COMMAND:

			if(HIWORD(wParam) == BN_CLICKED)
			{
				switch(LOWORD(wParam))
				{

				case IDC_HM_USE_ENTIRE_RANGE:
					{
					t_char sz[256];

					g_export_plugin._param_hm_min_interval = 0;
					g_export_plugin._param_hm_max_interval = USHRT_MAX;

					gSprintf(sz, M_SZ("%f"), g_export_plugin._param_hm_min_interval);
					HWND ctrl = GetDlgItem(hWnd, IDC_HM_MIN_RANGE);
					if(ctrl) SendMessage(ctrl, WM_SETTEXT, 0, (LPARAM)sz);

					gSprintf(sz, M_SZ("%f"), g_export_plugin._param_hm_max_interval);
					ctrl = GetDlgItem(hWnd, IDC_HM_MAX_RANGE);
					if(ctrl) SendMessage(ctrl, WM_SETTEXT, 0, (LPARAM)sz);
					}
					return TRUE;

				case IDOK:		// EXPORT

					// Take the user preferences from the UI.
					_MainDlgProc_GetOptionsFromUI(hWnd);

					// Path of the file is received through lParam.
					if(g_export_plugin._DoExport(exp_path, hWnd) != C_PARAM_ERR)
						EndDialog(hWnd, 0);
					return TRUE;

				case IDCANCEL:
					EndDialog(hWnd, 0);
					return TRUE;

				case IDC_SHOWHELP:
					// The help file should be in the plugin directory.
					{
						t_string help_path;
						t_char plugin_path[MAX_PATH];
						if(GetModuleFileName(g_hInstance, plugin_path, MAX_PATH))
						{
							const t_char *plugin_dir = g_storage_man->ExtractFileDir(plugin_path);
							if(plugin_dir)
							{
								help_path += plugin_dir;
								help_path += M_SZ("\\");
							}
						}
						help_path += M_SZ("ExpUDK.chm");
						HtmlHelp(hWnd, help_path.Sz(), HH_DISPLAY_TOC, NULL);
					}
					return TRUE;

				}
			}

			return FALSE;

		case WM_CLOSE:
			EndDialog(hWnd, 0);
			return TRUE;
	}

	return FALSE;
}

void cUDKExport::_MainDlgProc_SetOptionsToUI(HWND hWnd)
{
	HWND ctrl;

	ctrl = GetDlgItem(hWnd, IDC_EXP_ONLY_SEL);
	if(ctrl) 
	{
		if(g_export_plugin._param_exp_selected)
			SendMessage(ctrl, BM_SETCHECK, BST_CHECKED, 0);
		else
			SendMessage(ctrl, BM_SETCHECK, BST_UNCHECKED, 0);
	}

	ctrl = GetDlgItem(hWnd, IDC_SKIP_SWAPPED);
	if(ctrl) 
	{
		if(g_export_plugin._param_dont_exp_swapped)
			SendMessage(ctrl, BM_SETCHECK, BST_CHECKED, 0);
		else
			SendMessage(ctrl, BM_SETCHECK, BST_UNCHECKED, 0);
	}

	ctrl = GetDlgItem(hWnd, IDC_EXPORT_HM);
	if(ctrl) 
	{
		if(g_export_plugin._param_exp_heightmap)
			SendMessage(ctrl, BM_SETCHECK, BST_CHECKED, 0);
		else
			SendMessage(ctrl, BM_SETCHECK, BST_UNCHECKED, 0);
	}

	t_char sz[256];

	gSprintf(sz, M_SZ("%f"), g_export_plugin._param_hm_min_interval);
	ctrl = GetDlgItem(hWnd, IDC_HM_MIN_RANGE);
	if(ctrl) SendMessage(ctrl, WM_SETTEXT, 0, (LPARAM)sz);

	gSprintf(sz, M_SZ("%f"), g_export_plugin._param_hm_max_interval);
	ctrl = GetDlgItem(hWnd, IDC_HM_MAX_RANGE);
	if(ctrl) SendMessage(ctrl, WM_SETTEXT, 0, (LPARAM)sz);

	ctrl = GetDlgItem(hWnd, IDC_EXPORT_MASKS);
	if(ctrl) 
	{
		if(g_export_plugin._param_exp_masks)
			SendMessage(ctrl, BM_SETCHECK, BST_CHECKED, 0);
		else
			SendMessage(ctrl, BM_SETCHECK, BST_UNCHECKED, 0);
	}

	ctrl = GetDlgItem(hWnd, IDC_EXPORT_TILES);
	if(ctrl) 
	{
		if(g_export_plugin._param_exp_tile_textures)
			SendMessage(ctrl, BM_SETCHECK, BST_CHECKED, 0);
		else
			SendMessage(ctrl, BM_SETCHECK, BST_UNCHECKED, 0);
	}
}

void cUDKExport::_MainDlgProc_GetOptionsFromUI(HWND hWnd)
{
	HWND ctrl;

	ctrl = GetDlgItem(hWnd, IDC_EXP_ONLY_SEL);
	if(ctrl)
	{
		if(SendMessage(ctrl, BM_GETCHECK, 0, 0) == BST_CHECKED)
			g_export_plugin._param_exp_selected = true;
		else
			g_export_plugin._param_exp_selected = false;
	}

	ctrl = GetDlgItem(hWnd, IDC_SKIP_SWAPPED);
	if(ctrl)
	{
		if(SendMessage(ctrl, BM_GETCHECK, 0, 0) == BST_CHECKED)
			g_export_plugin._param_dont_exp_swapped = true;
		else
			g_export_plugin._param_dont_exp_swapped = false;
	}

	ctrl = GetDlgItem(hWnd, IDC_EXPORT_HM);
	if(ctrl)
	{
		if(SendMessage(ctrl, BM_GETCHECK, 0, 0) == BST_CHECKED)
			g_export_plugin._param_exp_heightmap = true;
		else
			g_export_plugin._param_exp_heightmap = false;
	}

	t_char sz[256];

	ctrl = GetDlgItem(hWnd, IDC_HM_MIN_RANGE);
	if(ctrl)
	{
		SendMessage(ctrl, WM_GETTEXT, (WPARAM)256, (LPARAM)sz);
		g_export_plugin._param_hm_min_interval = (float)gAtof(sz);
	}

	ctrl = GetDlgItem(hWnd, IDC_HM_MAX_RANGE);
	if(ctrl)
	{
		SendMessage(ctrl, WM_GETTEXT, (WPARAM)256, (LPARAM)sz);
		g_export_plugin._param_hm_max_interval = (float)gAtof(sz);
	}

	ctrl = GetDlgItem(hWnd, IDC_EXPORT_MASKS);
	if(ctrl)
	{
		if(SendMessage(ctrl, BM_GETCHECK, 0, 0) == BST_CHECKED)
			g_export_plugin._param_exp_masks = true;
		else
			g_export_plugin._param_exp_masks = false;
	}

	ctrl = GetDlgItem(hWnd, IDC_EXPORT_TILES);
	if(ctrl)
	{
		if(SendMessage(ctrl, BM_GETCHECK, 0, 0) == BST_CHECKED)
			g_export_plugin._param_exp_tile_textures = true;
		else
			g_export_plugin._param_exp_tile_textures = false;
	}
}

//====================================================

/*! [Windows Specific] Use windows registry. */
void cUDKExport::_ReadOptions()
{
	HKEY parent_key;
	if(RegCreateKeyEx(HKEY_CURRENT_USER, M_SZ("SOFTWARE"), 0, NULL,
		REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL,
		&parent_key, NULL) == ERROR_SUCCESS)
	{ 
		HKEY company_key;
		if(RegCreateKeyEx(parent_key, M_SZ("Quad Software"), 0, NULL,
			REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL,
			&company_key, NULL) == ERROR_SUCCESS)
		{
			HKEY key;
			if(RegCreateKeyEx(company_key, M_SZ("UDK Grome Exporter"), 0, NULL,
				REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL,
				&key, NULL) == ERROR_SUCCESS)
			{
				DWORD dw, size;

				size = sizeof(DWORD);
				if(RegQueryValueEx(key, M_SZ("param_exp_selected"), 0, NULL, (uchar*)&dw, &size) == ERROR_SUCCESS)
					_param_exp_selected = dw ? true: false;

				size = sizeof(DWORD);
				if(RegQueryValueEx(key, M_SZ("param_dont_exp_swapped"), 0, NULL, (uchar*)&dw, &size) == ERROR_SUCCESS)
					_param_dont_exp_swapped = dw ? true: false;

				size = sizeof(DWORD);
				if(RegQueryValueEx(key, M_SZ("param_exp_heightmap"), 0, NULL, (uchar*)&dw, &size) == ERROR_SUCCESS)
					_param_exp_heightmap = dw ? true: false;

				size = sizeof(DWORD);
				if(RegQueryValueEx(key, M_SZ("param_hm_min_interval"), 0, NULL, (uchar*)&dw, &size) == ERROR_SUCCESS)
					_param_hm_min_interval = (float)dw;

				size = sizeof(DWORD);
				if(RegQueryValueEx(key, M_SZ("param_hm_max_interval"), 0, NULL, (uchar*)&dw, &size) == ERROR_SUCCESS)
					_param_hm_max_interval = (float)dw;

				size = sizeof(DWORD);
				if(RegQueryValueEx(key, M_SZ("param_exp_masks"), 0, NULL, (uchar*)&dw, &size) == ERROR_SUCCESS)
					_param_exp_masks = dw ? true: false;

				size = sizeof(DWORD);
				if(RegQueryValueEx(key, M_SZ("param_exp_tile_textures"), 0, NULL, (uchar*)&dw, &size) == ERROR_SUCCESS)
					_param_exp_tile_textures = dw ? true: false;

				RegCloseKey(key);
			}
			RegCloseKey(company_key);
		}
		RegCloseKey(parent_key);
	}
}

/*! [Windows Specific] Use windows registry. */
void cUDKExport::_WriteOptions()
{
	// Write to registry the selected options
	HKEY parent_key;
	if(RegCreateKeyEx(HKEY_CURRENT_USER, M_SZ("SOFTWARE"), 0, NULL,
		REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL,
		&parent_key, NULL) == ERROR_SUCCESS)
	{ 
		HKEY company_key;
		if(RegCreateKeyEx(parent_key, M_SZ("Quad Software"), 0, NULL,
			REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL,
			&company_key, NULL) == ERROR_SUCCESS)
		{
			HKEY key;
			if(RegCreateKeyEx(company_key, M_SZ("UDK Grome Exporter"), 0, NULL,
				REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL,
				&key, NULL) == ERROR_SUCCESS)
			{
				DWORD dw;

				dw = (DWORD)_param_exp_selected;
				RegSetValueEx(key, M_SZ("param_exp_selected"), 0, REG_DWORD, (CONST BYTE*)&dw, sizeof(dw));

				dw = (DWORD)_param_dont_exp_swapped;
				RegSetValueEx(key, M_SZ("param_dont_exp_swapped"), 0, REG_DWORD, (CONST BYTE*)&dw, sizeof(dw));

				dw = (DWORD)_param_exp_heightmap;
				RegSetValueEx(key, M_SZ("param_exp_heightmap"), 0, REG_DWORD, (CONST BYTE*)&dw, sizeof(dw));

				dw = (DWORD)_param_hm_min_interval;
				RegSetValueEx(key, M_SZ("param_hm_min_interval"), 0, REG_DWORD, (CONST BYTE*)&dw, sizeof(dw));

				dw = (DWORD)_param_hm_max_interval;
				RegSetValueEx(key, M_SZ("param_hm_max_interval"), 0, REG_DWORD, (CONST BYTE*)&dw, sizeof(dw));

				dw = (DWORD)_param_exp_masks;
				RegSetValueEx(key, M_SZ("param_exp_masks"), 0, REG_DWORD, (CONST BYTE*)&dw, sizeof(dw));

				dw = (DWORD)_param_exp_tile_textures;
				RegSetValueEx(key, M_SZ("param_exp_tile_textures"), 0, REG_DWORD, (CONST BYTE*)&dw, sizeof(dw));

				RegCloseKey(key);
			}
			RegCloseKey(company_key);
		}
		RegCloseKey(parent_key);
	}
}

//====================================================
/*@}*/