//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Exporter.rc
//
#define IDD_MAINDIALOG                  102
#define IDC_SHOWHELP                    1001
#define IDC_INPUT_INFO                  1002
#define IDC_OUTPUT_INFO                 1003
#define IDC_EXP_HM_RAW                  1004
#define IDC_HM_UPP                      1005
#define IDC_HM_MIN_RANGE                1005
#define IDC_EXP_OP_4CPNG                1006
#define IDC_MAX_RANGE                   1006
#define IDC_HM_MAX_RANGE                1006
#define IDC_OP_RES                      1007
#define IDC_EXPORT_TILES                1008
#define IDC_LM_EXP_JPG                  1009
#define IDC_EXPORT_HM                   1009
#define IDC_LM_RES                      1010
#define IDC_EXPORT_TILES3               1010
#define IDC_EXPORT_MASKS                1010
#define IDC_LM_JPG_QUALITY              1011
#define IDC_SCR_HM_ERR                  1012
#define IDC_SCR_TREE_DEPTH              1013
#define IDC_USE_SWAP                    1014
#define IDC_SKIP_SWAPPED                1014
#define IDC_TILE_FORMAT                 1015
#define IDC_LM_LAYER                    1016
#define IDC_HM_USE_ENTIRE_RANGE         1016
#define IDC_DATA_SUBFOLDER              1017
#define IDC_SAVE_ATLAS_SCRIPT           1018
#define IDC_EXP_HM_RAW2                 1019
#define IDC_EXP_ONLY_SEL                1019
#define IDC_SAVE_MISSION_SCRIPT         1020
#define IDC_SAVE_TERRAIN_INSTANCE       1021
#define IDC_TERRAINS_FOLDER             1022
#define IDC_TERRAIN_DETAIL              1023
#define IDC_SAVE_OBJ_INSTANCES          1024
#define IDC_SCR_HM_ERR4                 1025
#define IDC_SHAPES_FOLDER               1025
#define IDC_CREATE_ZONE_SIMGROUP        1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
