//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2008-2009 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_ITRIGGERPLUGIN_H
#define __CSDK_ITRIGGERPLUGIN_H

#include "../../Engine/Plugins/iPlugin.h"

namespace csdk {

//====================================================

//! Text describing the plug-in type.
#define C_PLUGIN_TYPE_TRIGGER "Trigger"

//! Plug-in interface supported by trigger plug-ins.
/*! Trigger plug-ins are special plugins that are automatically ran by the editor when certain
user events are occurring: when a new scene is opened, when an object is edited, a tool
is called etc. 
This kind of plug-ins can be used to perform various operations before and after certain events:
validate selections, apply custom properties to newly created entities, post processing after tools etc. */
class iTriggerPlugin: public iPlugin
{
public:

	//! Return the category this plug-in belongs to.
	virtual const char* PluginType() { return C_PLUGIN_TYPE_TRIGGER; }

	//! By default, for trigger plug-ins we indicate them as active so the plugin module is never unloaded.
	virtual t_bool IsActive() { return C_TRUE; }

	//! Called by the editing system to indicate that an event is happening.
	/*! 
	\param module_node Indicate the SDK module node (e.g. iEditor, iTerrainEd, iObjectEd)
	from which the event comes.

	\param event_id An per module unique ID specifying the event. There are many possible 
	ID values. See C_TRIGGERID_* in various interface files (each SDK submodule has a
	iTriggerPlugin file with its unique ids). Each submodule (editor, terrained, objected etc.)
	has its unique ids, but these ids are not necessarely unique between modules. That's
	why the first parameter indicates the module, and thus ensure us that the ids will
	allow us to freely move ids for new modules without any conflict.

	\param event_data Event ID custom data (must be casted to proper data based on ID).

	\return Generic success or an error code to indicate that the plugin doesn't want the
	triggered event to continue (example: cancel the selection, cancel the tool apply etc).
	Usually the events are applied only if all the registered trigger plugin return success
	code, so it is necessary to return success for events you don't want to process.
	*/
	virtual t_error TriggerEvent(iSdkInterface *module_node, const uint event_id, const void *even_data) 
	{ return C_GENERIC_SUCCESS; }

};

//====================================================
// Editor general trigger ids (for iEditor module):

// ======================================
// Application global operations:

//! Called immediately after editor is started
/*! event_data: NULL.
Error return: ignored.
Usage example: Load or allocate global data. */
#define C_TRIGGERID_APP_START		1	

//! Called prior the exit of the editor.
/*! event_data: NULL.
Error return: program exit is aborted.
Usage example: Save global data when the application is exiting. */
#define C_TRIGGERID_APP_EXIT			2

// ======================================
// Scene file operations:

// At a certain scene event multiple triggers can be started. For example when
// a new scene is created and there is an existing one the triggers are:
// before new, after new (for the new scene), before close and after close (for the old scene).

// Scene events are also called when scenes are automatically loaded (e.g. at program start), 
// not necessarily only at events triggered by the user.

//! Called before a new scene is created (before new scene dialog).
/*! event_data: NULL (current scene data can be queried with SDK).
Error return: the new scene will be aborted and old scene is kept (or, at startup, Welcome dialog is kept on screen).
Usage example: Make sure prior scene data can be deleted. */
#define C_TRIGGERID_SCENE_BEFORE_NEW		10	

//! Called after the new scene dialog but before creating the new scene.
/*! event_data: pointer to sTriggerSceneNew structure.
Error return: editor returns to the new scene dialog.
Usage example: can be used to validate new scene data. */
#define C_TRIGGERID_SCENE_NEW					11	

//! Trigger plugin data structure for new scene event.
struct sTriggerSceneNew
{
	//! Name of the new scene.
	const t_char *scene_name;

	//! Storage (path location) of the new scene workspace file.
	iStorage *scene_storage;

	//! Types of projects chosen for this workspace configuration.
	/*! Client can use this information to check if all the necessary project types are selected when creating the new scene. */
	t_array<t_type_id> project_ids;
};

//! Called after a new scene is created.
/*! event_data: NULL.
Error return: ignored.
Usage example: can be used to append data to the new scene. */
#define C_TRIGGERID_SCENE_AFTER_NEW		12	

//! Called before a new scene is loaded.
/*! event_data: pointer to sTriggerSceneBeforeLoad structure.
Error return: loading is aborted, the current scene or Welcome dialog is kept.
Usage example: can be used to validate if the previous scene can be unloaded. */
#define C_TRIGGERID_SCENE_BEFORE_LOAD	13

//! Trigger plugin data structure for before-loading scene event.
struct sTriggerSceneBeforeLoad
{
	//! Name of the loading scene.
	const t_char *scene_name;

	//! Storage (path location) of the loading scene workspace file.
	iStorage *scene_storage;
};

//! Called after a new scene is loaded.
/*! event_data: NULL (scene data can be queried with SDK).
Error return: editor returns to the load scene dialog. Newly loaded scene is kept in memory and treated as previous scene.
Usage example: can be used to validate the new loaded scene data. */
#define C_TRIGGERID_SCENE_AFTER_LOAD		14

//! Called before the current scene is saved.
/*! This is also called when Save As on the same scene is performed.
event_data: NULL.
Error return: editor aborts scene save.
Usage example: can be used to perform committing operations before saving scenes. */
#define C_TRIGGERID_SCENE_BEFORE_SAVE	15

//! Called after the current scene is saved.
/*! event_data: NULL.
Error return: ignored.
Usage example: can be used to save other data with the scene. */
#define C_TRIGGERID_SCENE_AFTER_SAVE		16

//! Called before the current scene is saved under a different name (after save as dialog but before saving the data).
/*! event_data: pointer to sTriggerSceneBeforeSaveAs structure.
Error return: editor aborts scene save.
Usage example: can be used to perform committing operations before saving scenes. */
#define C_TRIGGERID_SCENE_BEFORE_SAVE_AS	17

//! Trigger plugin data structure for before-save-as scene event.
struct sTriggerSceneBeforeSaveAs
{
	//! New name of the scene.
	const t_char *scene_new_name;

	//! New storage (path location) of the scene workspace file.
	iStorage *scene_storage;
};

//! Called after the current scene is saved under a different name.
/*! event_data: NULL.
Error return: ignored.
Usage example: can be used to save other data with the scene. */
#define C_TRIGGERID_SCENE_AFTER_SAVE_AS	18

//! Called before current scene is closed.
/*! event_data: NULL.
Error return: editor aborts closing the current scene. Other operations, like creating another scene, are also aborted (since only one workspace can be valid at one time).
If C_TRIGGERID_SCENE_AFTER_CLOSE is not received it means that the current workspace close was aborted due to another error (example: a new scene was giving
an error during loading so the current workspaces reverted to the initial scene).
NOTE: this is not received when the scene is closed due to the program being shutdown. C_TRIGGERID_APP_EXIT is received in this case prior to closing the scene.
Usage example: can be used to validate if scene can be unloaded. */
#define C_TRIGGERID_SCENE_BEFORE_CLOSE	19

//! Called after the current scene was unloaded.
/*! event_data: NULL.
Error return: ignored.
Usage example: can be used to save scene additional data. */
#define C_TRIGGERID_SCENE_AFTER_CLOSE	20

// ======================================
// NOT IMPLEMENTED ! The following ids are not yet implemented but they will in a future update.

// ======================================
// NOT IMPLEMENTED !
// Selection events:

// Issue: how to correctly identify the operated entities among different 
// modules? Possible solution: each module gives a container of interfaces 
// on which the operation is taken place. Create iInterfaceContainer interface.

// NOTE: many of the entities related events are not sent for each individual entity.
// The events are sent for a batch of entities as they are operated in a group by the
// user (example: a single C_TRIGGERID_SCENE_BEFORE_SELECT is sent for all
// the entities selected at once by the user). This is done for performance reasons.
// The actual entities being operated (selected, unswapped, deleted etc) are sent
// in the event_data parameter (commonly contained in iInterfaceContainer interfaces).

//! Called before selecting one or a group of entities (before a selection operation with the mouse or by name).
#define C_TRIGGERID_ENTITY_BEFORE_SELECT		30
//! Called after selecting one or a group of entities (after a selection operation with the mouse or by name).
#define C_TRIGGERID_ENTITY_AFTER_SELECT			31
//! Called before unselecting one or a group of entities (before a unselection operation with the mouse or by name).
#define C_TRIGGERID_ENTITY_BEFORE_UNSELECT	32
//! Called after unselecting one or a group of entities (after a unselection operation with the mouse or by name).
#define C_TRIGGERID_ENTITY_AFTER_UNSELECT		33

// ======================================
// NOT IMPLEMENTED !
// Global entities operations (swap, hide etc) :

//! Called before one or a group of scene entities are swapped out to disk.
#define C_TRIGGERID_ENTITY_BEFORE_SWAP		40
//! Called after one or a group of scene entities are swapped out to disk.
#define C_TRIGGERID_ENTITY_AFTER_SWAP			41
//! Called before one or a group of scene entities are unswapped from the disk.
#define C_TRIGGERID_ENTITY_BEFORE_UNSWAP	42
//! Called after one or a group of scene entities are unswapped from the disk.
#define C_TRIGGERID_ENTITY_AFTER_UNSWAP	43

//! Called before one or a group of scene entities are about to become hidden.
#define C_TRIGGERID_ENTITY_BEFORE_HIDE		44
//! Called before one or a group of scene entities become hidden.
#define C_TRIGGERID_ENTITY_AFTER_HIDE			45
//! Called before one or a group of scene entities are about to become visible.
#define C_TRIGGERID_ENTITY_BEFORE_UNHIDE	46
//! Called before one or a group of scene entities become visible.
#define C_TRIGGERID_ENTITY_AFTER_UNHIDE	47

//! Called before scene entities are about to be deleted (not completely but sent to undo system).
#define C_TRIGGERID_ENTITY_BEFORE_DELETE	48
//! Called after scene entities were deleted (not completely but sent to undo system).
#define C_TRIGGERID_ENTITY_AFTER_DELETE		49
//! Called before scene entities are about to be delete completely from memory (undo stack entry is removed).
#define C_TRIGGERID_ENTITY_BEFORE_FINAL_DELETE	50
//! Called after scene entities are delete completely from memory (undo stack entry is removed).
#define C_TRIGGERID_ENTITY_AFTER_FINAL_DELETE		51
//! Called before scene entities are about to be resurrected from the undo stack system.
#define C_TRIGGERID_ENTITY_BEFORE_RESURRECT	52
//! Called after scene entities are resurrected from the undo stack system.
#define C_TRIGGERID_ENTITY_AFTER_RESURRECT	53

//! Called before a scene entity is about to be renamed.
#define C_TRIGGERID_ENTITY_BEFORE_RENAME		54
//! Called after a scene entity is renamed.
#define C_TRIGGERID_ENTITY_AFTER_RENAME			55

// ======================================
// NOT IMPLEMENTED !
// Undo events:

//! Called before an undo operation is performed.
#define C_TRIGGERID_BEFORE_UNDO		60
//! Called after an undo operation is performed.
#define C_TRIGGERID_AFTER_UNDO			61
//! Called before an redo operation is performed.
#define C_TRIGGERID_BEFORE_REDO		62
//! Called after an redo operation is performed.
#define C_TRIGGERID_AFTER_REDO			63

// ======================================
// NOT IMPLEMENTED !
// Tools events:

//! Called before a tool is activated (its UI is shown).
#define C_TRIGGERID_TOOL_BEFORE_ACTIVATE	70
//! Called after a tool is activated (its UI is shown).
#define C_TRIGGERID_TOOL_AFTER_ACTIVATE	71
//! Called before a tools is about to be closed (its UI closed).
#define C_TRIGGERID_TOOL_BEFORE_CLOSE		72
//! Called after a tools is closed (its UI closed).
#define C_TRIGGERID_TOOL_AFTER_CLOSE			73
//! Called before a tool is applied to the current selection.
#define C_TRIGGERID_TOOL_BEFORE_APPLY		74
//! Called after a tool is applied to the current selection.
#define C_TRIGGERID_TOOL_AFTER_APPLY			75

// ======================================
// NOT IMPLEMENTED !
// Other plug-ins events:

//! Called before an export plugin is about to be ran.
#define C_TRIGGERID_PLUGIN_BEFORE_EXPORT		100
//! Called after an export plugin is ran.
#define C_TRIGGERID_PLUGIN_AFTER_EXPORT		101
//! Called before an import plugin is about to be ran.
#define C_TRIGGERID_PLUGIN_BEFORE_IMPORT	102
//! Called after an import plugin is ran.
#define C_TRIGGERID_PLUGIN_AFTER_IMPORT		103
//! Called before an utility plugin is about to be ran.
#define C_TRIGGERID_PLUGIN_BEFORE_UTILITY	104
//! Called after an utility plugin is ran.
#define C_TRIGGERID_PLUGIN_AFTER_UTILITY		105

//====================================================
}; // namespace csdk
#endif
/*@}*/