//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_IEDPROJECT_H
#define __CSDK_IEDPROJECT_H

#include "../../Engine/Interfaces/iSdkInterface.h"

namespace csdk {

//====================================================

//! Interface to an editor project.
/*! This is a generic interface to any type of project. Use GetProjectType and OpenSubinterface to get
access to project type specific functionality (ex: terrain editing project, object editing project etc.). */
class iEdProject: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iEdProject"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Editor project interface"; }
	
	// [ Custom interface ]===================================

	//! Return the type of project as interface type.
	/*! You can return the specialized interface with OpenSubinterface with this type. */
	virtual t_type_id GetProjectType() = 0;

	//! Indicate if the project is loaded (opened along side its data from disc).
	virtual t_bool IsLoaded() = 0;

	//! Indicate if the project is active.
	virtual t_bool IsActive() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/