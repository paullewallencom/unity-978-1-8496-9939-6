//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007-2011 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_IEXPORTPLUGIN_H
#define __CSDK_IEXPORTPLUGIN_H

#include "../../Engine/Plugins/iPlugin.h"

namespace csdk {

//====================================================

//! Text describing the plug-in type.
#define C_PLUGIN_TYPE_EXPORT "Export"

// Possible flags for export plug-ins (for unsupported flags the plugin should return C_NOTSUPPORTED_ERR).
#define F_EXPORT_NO_UI		(1<<0)	//!< Silent export (not showing the UI but using the last options the user chosen in a previous session).
#define F_EXPORT_ONLY_SET_OPTIONS	(1<<1) //!< Don't do the actual export, only show the UI to get the options.

//! Plug-in interface supported by export plug-ins.
class iExportPlugin: public iPlugin
{
public:

	//! Return the category this plug-in belongs to.
	virtual const char* PluginType() { return C_PLUGIN_TYPE_EXPORT; }

	//! Return the extensions no this plug-in support.
	virtual uint GetFileExtNo() = 0;
	//! Return the i-th file extension this plug-in support (only the extension without the point ".").
	virtual const t_char* GetFileExt(const uint idx) = 0;

	//! Trigger file export.
	/*! Here the exporter could show a U.I. with various options and perform the export. */
	virtual t_error Export(const t_char *file_path) = 0;

	//! Trigger file export (custom version that can accept various modes).
	/*! Here the exporter could show a U.I. with various options and perform the export. 
	\param file_path Path to which to export (complete path to a folder or a file). 
	\param flags See F_EXPORT_* for possible flags. 
	\param custom_data Custom export data that depends on the flags being used. */
	virtual t_error CustomExport(const t_char *file_path, uint32 flags = 0, void *custom_data = NULL)
	{
		// By default we only support the normal export.

		if(flags == 0)
			return Export(file_path);

		return C_NOTSUPPORTED_ERR;
	}
};

//====================================================
}; // namespace csdk
#endif
/*@}*/