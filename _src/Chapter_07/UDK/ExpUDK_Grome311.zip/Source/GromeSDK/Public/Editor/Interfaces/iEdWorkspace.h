//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_IEDWORKSPACE_H
#define __CSDK_IEDWORKSPACE_H

#include "iEdProject.h"
#include "../../Engine/Interfaces/iStorage.h"

namespace csdk {

//====================================================

//! The spatial reference assigned to a scene by an import of georeferenced data
struct sGeoReference
{
	//! Projection reference text, in WKT format
	/*! Note that for new created scenes this member is NULL and the projection is assumed to be geographic*/
	char* projection_ref;

	//! Offset of the scene origin inside the projected space (this is used when the scene is "centered" around a particular dataset to avoid accuracy errors)
	/*! For example, if an imported dataset would span between 1.0E, 1.0N to 2.0E, 2.0N, the origin of the scene would be 0.5E, 0.5N, to center the data around 0,0 on the XoZ plane in Grome)*/
	double	origin_offset_x;
	double	origin_offset_z;

	//! Unit scale factor (this value represents the length of a projection unit expressed in Grome scene units)
	/*! For example, if the scene units represent meters and the projection is geographic, the unit_scale can be set to 113000 to indicate the length of an arc degree of longitude at 0deg Latitude*/
	double	unit_scale;
};

//====================================================

//! Interface to the a scene workspace.
/*! A scene workspace defines all the current working state regarding projects,
settings, viewports etc. The current loaded scene is a entity that permits
multiple projects to be loaded at the same time and cooperate in the editor
framework. There is always only one scene workspace active. */
class iEdWorkspace: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iEdWorkspace"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Scene workspace interface"; }
	
	// [ Custom interface ]===================================

	//! Return the projects in this workspace.
	/*! \warning After modifications to the current workspace projects (deletion,
	insertion etc.) parts of this array may become invalid (some interfaces referring
	to released projects). It is recommended to not store this array for later use. 
	When the returned projects interfaces are no longer used you should call
	CloseInterface on which one (or call gCloseInterfaces on all the arrays). */
	virtual t_readonly_array<iEdProject*>* GetProjects() = 0;

	//! Return the current active projects.
	/*! \warning After modifications to the current workspace projects (deletion,
	insertion etc.) parts of this array may become invalid (some interfaces referring
	to released projects). It is recommended to not store this array for later use. 
	When the project interface is no longer used you should call CloseInterface on it. */
	virtual t_readonly_array<iEdProject*>* GetActiveProjects() = 0;

	//! Save the workspace.
	virtual t_error Save() = 0;

	//! Set the georeference data for the scene
	virtual t_error SetGeoReference(const sGeoReference* data) = 0;

	//! Set the georeference data for the scene
	/*! This method returns the georeference data, currently applied to the scene. If no SetGeoReference call was previously made, the method
	returns NULL (no georef data)*/
	virtual const sGeoReference*	GetGeoReference() = 0;

	//! Return the interface to the current workspace file storage.
	/*! Each workspace has a file (contains the description of the scene) and a folder (in which 
	projects data is kept). The workspace folder is usually in the same directory as the workspace file.
	Returned storage interface should be closed (CloseInterface) when no longer used. */
	virtual iStorage* GetWorkspaceFileStorage() = 0;

	//! Return the interface to the current workspace folder storage.
	/*! Each workspace has a file (contains the description of the scene) and a folder (in which 
	projects data is kept). The workspace folder is usually in the same directory as the workspace file.
	Returned storage interface should be closed (CloseInterface) when no longer used. */
	virtual iStorage* GetWorkspaceFolderStorage() = 0;

	//! Return the interface to the current workspace geometry storage.
	/*! Each workspace has a folder inside the workspace folder, where it stores the imported geometry or procedurally created geometry entities.
	Returned storage interface should be closed (CloseInterface) when no longer used. */
	virtual iStorage* GetWorkspaceGeometryStorage() = 0;

	//! Return the interface to the current workspace textures storage.
	/*! Each workspace has a folder inside the workspace folder, where it stores the imported textures.
	Returned storage interface should be closed (CloseInterface) when no longer used. */
	virtual iStorage* GetWorkspaceTexturesStorage() = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/