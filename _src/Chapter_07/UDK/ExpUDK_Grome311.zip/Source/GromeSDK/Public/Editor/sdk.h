//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file Editor/sdk.h
	\brief Editor SDK includes.

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_EDITOR_SDK_H
#define __CSDK_EDITOR_SDK_H

//====================================================

// Include the engine SDK.
#include "../Engine/sdk.h"

// Interfaces.
#include "Interfaces/iEditor.h"

// Plug-ins types.
#include "Plugins/iExportPlugin.h"
#include "Plugins/iImportPlugin.h"
#include "Plugins/iUtilityPlugin.h"
#include "Plugins/iTriggerPlugin.h"

//====================================================
#endif
/*@}*/