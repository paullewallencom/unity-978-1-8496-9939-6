//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_IEDITOR_H
#define __CSDK_IEDITOR_H

#include "iEdWorkspace.h"
#include "iProcessingManager.h"
#include "iEditorTool.h"
#include "iSystemUnitsManager.h"
#include "iTextureAtlasPacker.h"
#include "../../Engine/Interfaces/iWindow.h"

namespace csdk {

//====================================================

//! Name used to register the iEditor interface with the SDK root.
#define C_EDITOR_INTERFACE_NAME		"Editor Framework"

//! Main interface to editor framework application.
/*! The Editor Framework is an the application that represents the framework
for editing modules and plug-ins to be loaded and used for specific editing tasks.
This interface can be obtained from the SDK root interface with a call to 
iRootInterface::OpenInterface with "Editor Framework" as name. */
class iEditor: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iEditor"; }

	virtual const char* Name() { return C_EDITOR_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Editor Framework interface"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to the current workspace active in the editor application.
	/*! There is always one workspace active in the framework. This interface is always
	pointing to the current workspace no matter if this has changed or not. So after the workspace
	has changed this pointer will still point to the correct current workspace.
	The workspace interface is referred so call CloseInterface on it when the no longer needed. */
	virtual iEdWorkspace* GetCurrWorkspace() = 0;

	//! Return the interface to the editor processing manager.
	/*! The processing manager interface is referred so call CloseInterface on it when the no longer needed. */
	virtual iProcessingManager* GetProcessingManager() = 0;

	//! Return the main editor window.
	/*! The window interface is referred so call CloseInterface on it when the no longer needed. */
	virtual iWindow* GetMainWindow() = 0;

	//! Return the system units manager interface
	/*! The units interfaces is used to handle the units definitions registered to the editor application and configure the units settings for the active scene/workspace*/
	virtual iSystemUnitsManager* GetUnitsManager() = 0;

	// Tools ==================================

	//! Activates a tool in the Grome UI.
	/*! Once the tool interface is no longer used close it with iEditorTool::CloseInterface or deactivate the tool
	(call iEditor::DeactivateCurrentTool). There is only one tool active at one time so calling this function will
	invalidate the previous activate tool and its interface.
	\warning Some operations (like creating scene entities (e.g. terrain zones)) are not allowed while a tool is activated.
	\param tool_name Name of the tool to be activated.
	\return Interface to the tool in case of success or NULL in case of error (tool was not found or has incomplete data to init). */
	virtual iEditorTool* ActivateTool(const char *tool_name) = 0;

	//! Deactivate the currently active tool (if any).
	/*! This call closes the interface previously obtained with iEditor::ActivateTool so be aware that the interface is no longer valid. */
	virtual t_error DeactivateCurrentTool() = 0;

	//! Get the active editor tool
	/*! Call this method to obtain an interface to the currently active editor tool. Once the tool interface is no longer used close it with iEditorTool::CloseInterface or deactivate the tool*/
	virtual iEditorTool* GetActiveTool() =  0;

	// ======================================

	//! Disable the action stack (undo system).
	/*! To be noted that this by default when a plugin starts the undo stack is always enabled.
	\warning Disabling the action stack will clear the undo stack up to this point. */
	virtual void	EnableActionStack(t_bool enable = C_TRUE) = 0;

	//! Indicate if the action stack (undo system) is enabled or not.
	/*! To be noted that this by default when a plugin starts the undo stack is always enabled. */
	virtual t_bool IsActionStackEnabled() = 0;

	// ======================================

	//! Select a scene entity (object, terrain zone etc).
	virtual t_error SelectEntity(iSdkInterface *entity) = 0;

	//! Deselect a scene entity (object, terrain zone etc).
	virtual t_error DeselectEntity(iSdkInterface *entity) = 0;

	//! Make a scene entity visible.
	virtual t_error ShowEntity(iSdkInterface *entity) = 0;

	//! Hide a scene entity.
	virtual t_error HideEntity(iSdkInterface *entity) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/