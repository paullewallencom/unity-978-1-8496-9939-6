//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_IIMPORTPLUGIN_H
#define __CSDK_IIMPORTPLUGIN_H

#include "../../Engine/Plugins/iPlugin.h"

namespace csdk {

//====================================================

//! Text describing the plug-in type.
#define C_PLUGIN_TYPE_IMPORT "Import"

//! Plug-in interface supported by import plug-ins.
class iImportPlugin: public iPlugin
{
public:

	//! Return the category this plug-in belongs to.
	virtual const char* PluginType() { return C_PLUGIN_TYPE_IMPORT; }

	//! Return the number of extensions supported by this plugin.
	virtual uint GetFileExtNo() = 0;

	//! Return the i-th file extension supported by this plugin (only the extension without the point ".").
	virtual const t_char* GetFileExt(const uint idx) = 0;

	//! Trigger file import.
	virtual t_error Import(const t_char *file_path) = 0;

};

//====================================================
}; // namespace csdk
#endif
/*@}*/