//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_ISYSTEMUNITSMANAGER_H
#define __CSDK_ISYSTEMUNITSMANAGER_H

#include "../../Engine/Interfaces/iSdkInterface.h"

namespace csdk {

//====================================================

//! Interface to the the editor system units manager.
/*! This interface exposed by the editor application is used to handle the unit definitions on the currently active workspace/scene. */
class iSystemUnitsManager: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iSystemUnitsManager"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Editor unit system manager"; }
	
	// [ Custom interface ]===================================

	//! Returns the number of unit definitions currently registered to the editor
	virtual	uint			GetUnitDefinitionsNo() = 0;

	//! Get a handle to the unit definition with the given index
	virtual	t_handle		GetUnitDefinition(uint index) = 0;

	//! Get the unit definition name, given the unit definition handle
	virtual	const t_char*	GetUnitName(t_handle definition_handle) = 0;

	//! Get the unit abbreviation, given the unit definition handle
	virtual	const t_char*	GetUnitAbbreviation(t_handle definition_handle) = 0;

	//! Get the unit transformation to standard international meter
	virtual	double		GetUnitToMeterScale(t_handle definition_handle) = 0;

	//! Get the system unit configuration for the active scene/workspace.
	/*! The system scene unit consists of a unit value and a unit definition, such as One Scene Unit = Unit Value * 1 Unit Def (e.g. 1 Scene unit = 1 meter)
		The function writes the current unit value and unit definition into the supplied parameters.
	*/
	virtual	t_error		GetSceneUnit(double& o_value, t_handle& o_definition) = 0;

	//! Set the system unit configuration for the active scene/workspace.
	/*! This function replaces the current system unit configuration for the active scene. Note that the contents of the scene are NOT SCALED after the operation, the 
		only thing that changes is the INTERPRETATION of the internal scene units.
	*/
	virtual	t_error		SetSceneUnit(double value, t_handle definition) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/