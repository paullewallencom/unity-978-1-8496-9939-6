//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_IPROCESSINGMANAGER_H
#define __CSDK_IPROCESSINGMANAGER_H

#include "../../Engine/Interfaces/iSdkInterface.h"

namespace csdk {

//====================================================

//! Interface to the a editor processing manager interface.
/*! This interface exposed by editor application perform editing processing tasks like
progress indicator, cancel/pause of current operation etc. 

Usually editor application will offer of this interface that will show progress bars during long operations.
The operation has a descriptive text and a progress bar that can be updated any time. Only one processing operation
is active at a time. A new nested subprocess can be started and become active with its progress updated with UpdateCurrProcess
between 0 and 100 but mapped in a subrange of the parent process (defined with the last SubprocessProgressRange call).
See documentation for interface functions for more details.
*/
class iProcessingManager: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iProcessingManager"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Editor processing manager"; }
	
	// [ Custom interface ]===================================

	//! Indicate if the manager is currently with an open process (in between BeginProcess and EndCurrProcess).
	virtual t_bool IsInProcess() = 0;

	//! Start a processing operation.
	/*! If the prior process was not closed (with EndProcess) a subprocess will be created and becomes current. 
	When the subprocess is closing the parent will become the current one and continue until EndProcess.
	\param description_text A text describing the process.
	\param start_progress Progress indicator at the beginning of the process (between 0 and 100). */
	virtual t_error BeginProcess(const t_char *description_text, const float start_progress = 0.f) = 0;

	//! Set the next subprocess progress range.
	/*! The subprocess 	internal progress range (as updated with UpdateRange) is between 0 and 100. 
	The parent will map this range to subprocess' start and end as defined by this function. */
	virtual void SubprocessProgressRange(const float start_progress, const float end_progress) = 0;

	//! Update the current process status.
	/*!
	\param description_text Descriptive text to be updated. If NULL the text is not changed.
	\param curr_progress Current progress indicator (between 0 and 100).
	*/
	virtual void UpdateCurrProcess(const float curr_progress, const t_char *description_text = NULL) = 0;

	//! Return the current process progress (local to this process range). In between 0 and 100.
	virtual float GetCurrProgress() = 0;

	//! End the current process.
	/*! \param remove_text Indicate if the processing description text is to be removed from the status bar. Otherwise the last text is kept. */
	virtual void EndCurrProcess(const t_bool remove_text = C_FALSE) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/