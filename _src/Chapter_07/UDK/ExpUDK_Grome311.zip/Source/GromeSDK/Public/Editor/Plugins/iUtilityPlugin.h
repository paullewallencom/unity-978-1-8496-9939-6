//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_IUTILITYPLUGIN_H
#define __CSDK_IUTILITYPLUGIN_H

#include "../../Engine/Plugins/iPlugin.h"

namespace csdk {

//====================================================

//! Text describing the plug-in type.
#define C_PLUGIN_TYPE_UTILITY "Utility"

//! Plug-in interface supported by utility plug-ins.
/*! Utility plug-ins are generic purpose plug-ins that are to be found inside the Utilities
menu in the editor. They can be used to run various tasks on demands. */
class iUtilityPlugin: public iPlugin
{
public:

	//! Return the category this plug-in belongs to.
	virtual const char* PluginType() { return C_PLUGIN_TYPE_UTILITY; }

	//! Return a string describing the category to include this utility in.
	/*! The utility plug-ins are presented to the user in the Utilities editor menu. This
	menu is organized on subpopups per category so multiple plug-ins of the same 
	category are gathered together for an easier browsing. By returning NULL the plug-in
	is included in global category and shown directly in the Utilities menu. */
	virtual const t_char* UtilityCategory() { return NULL; }

	//! Run the plug-in.
	/*! Here the plug-in can do various tasks on the current editor scene. */
	virtual t_error Run() = 0;

};

//====================================================
}; // namespace csdk
#endif
/*@}*/