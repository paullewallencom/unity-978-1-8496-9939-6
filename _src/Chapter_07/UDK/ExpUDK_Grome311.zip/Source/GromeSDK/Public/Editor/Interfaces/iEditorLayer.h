//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IEDITORLAYER_H
#define __CSDK_IEDITORLAYER_H

#include "../../Engine/Interfaces/iSdkInterface.h"

namespace csdk {

//====================================================

class iEditorLayer: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iEditorLayer";}

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Editor Layer Interface";}

	//! Indicate if the layer is marked as in use.
	/*! If a layer is not enabled is automatically not in use. */
	virtual t_bool IsUsed() = 0;

	//! Indicate if the layer is enabled.
	virtual t_bool IsEnabled() = 0;

	//! Mark a layer in use or not.
	/*! If a layer is not enabled is automatically not in use. */
	virtual void Use(t_bool use) = 0;

	//! Enable or disable a layer.
	virtual void Enable(t_bool enable) = 0;

	//! Get the stack id of the layer.
	virtual uint GetId() = 0;

	//! Get specific flags for the editor layer
	virtual uint32 GetFlags() { return 0;}



};

//====================================================
} // namespace csdk
#endif
/*@}*/