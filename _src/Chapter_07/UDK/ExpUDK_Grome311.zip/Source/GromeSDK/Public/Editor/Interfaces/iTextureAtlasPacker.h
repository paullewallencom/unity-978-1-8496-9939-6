//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2012 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_ITEXTUREATLASPACKER_H
#define __CSDK_ITEXTUREATLASPACKER_H

#include "../../Engine/Interfaces/iSdkInterface.h"
#include "../../Engine/Interfaces/iImage.h"

namespace csdk {

//====================================================

//! Structure used to output image layout information after creating an atlas.
/*! An array of these structure is passed to the packer and one item will be created for each input texture/image. */
struct sTextureAtlasItem
{
	//! Index of the owner atlas image into the atlas output list.
	uint atlas_idx;

	//! Placement rectangle of the input image into the output atlas.
	t_rect placement;
};

//====================================================

//! Atlas packing flags
#define F_AP_PWR2_ATLAS	(1<<0)  //!< If this flag is set, the packer will create atlas images with power-of-two dimensions (smallest dimensions, large enough for each atlas contents)

//====================================================

//! Name used to register the iTextureAtlasPacker interface with the SDK root.
#define C_TEXTURE_ATLAS_PACKER_INTERFACE_NAME		"Texture Atlas Packer"

//! Interface to the the editor system units manager.
/*! This interface exposed by the editor application is used to handle the unit definitions on the currently active workspace/scene. */
class iTextureAtlasPacker: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTextureAtlasPacker"; }

	virtual const char* Name() { return C_TEXTURE_ATLAS_PACKER_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Texture atlas packing utility"; }
	
	// [ Custom interface ]===================================

	//!Setup the atlas image size
	virtual t_error	SetAtlasSize(uint max_width, uint max_height) = 0;

	//! Compute the packing layout for a list of images, given the current atlas size.
	virtual t_error	PackImageList(t_readonly_array<iImage*>* i_image_list, int32 flags) = 0;

	//! Return the size of atlases created by last PackImageList call.
	virtual t_array<t_point>* GetAtlasSizes() = 0;

	//! Return the texture layout created by last PackImageList call.
	virtual t_array<sTextureAtlasItem>* GetTextureLayout() = 0;

	//! Write the current atlas packing to the supplied list of atlas images.
	virtual t_error	WriteAtlasImages(t_array<iImage*>* i_atlas_list) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/