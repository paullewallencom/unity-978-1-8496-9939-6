//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup WorldEdSDK World Editor SDK */
/*@{*/

#ifndef __CSDK_IEDITMESH_H
#define __CSDK_IEDITMESH_H

#include "../../../Public/Engine/Interfaces/iSdkInterface.h"

namespace csdk {

//====================================================

#define F_VERTEX_ATTRIB_POSITION	(1<<0)
#define F_VERTEX_ATTRIB_COLOR		(1<<1)
#define F_VERTEX_ATTRIB_NORMAL		(1<<2)
#define F_VERTEX_ATTRIB_TEXMAP0		(1<<3)
#define F_VERTEX_ATTRIB_TEXMAP1		(1<<4)
#define F_VERTEX_ATTRIB_TEXMAP2		(1<<5)
#define F_VERTEX_ATTRIB_TEXMAP3		(1<<6)
#define F_VERTEX_ATTRIB_TEXMAP4		(1<<7)
#define F_VERTEX_ATTRIB_TEXMAP5		(1<<8)
#define F_VERTEX_ATTRIB_TEXMAP6		(1<<9)
#define F_VERTEX_ATTRIB_TEXMAP7		(1<<10)
#define F_VERTEX_ATTRIB_TEXMAP8		(1<<11)
#define F_VERTEX_ATTRIB_TEXMAP9		(1<<12)
#define F_VERTEX_ATTRIB_TEXMAP10	(1<<13)
#define F_VERTEX_ATTRIB_TEXMAP11	(1<<14)
#define F_VERTEX_ATTRIB_TEXMAP12	(1<<15)
#define F_VERTEX_ATTRIB_TEXMAP13	(1<<16)
#define F_VERTEX_ATTRIB_TEXMAP14	(1<<17)
#define F_VERTEX_ATTRIB_TEXMAP15	(1<<18)


//====================================================


//! SDK interface to an editable mesh topology
/*! 
The editable geometry entity is the main editable object type, handled by the World Editor Module.
It consisits of a "seed" or "root" node, usually a simple primitive object (or an existing geometry template, loaded from library) on top of which, several geometry
modifiers are added, to create a new geometry template. The edit entity also has a default geometry instance, which reveals the edit object in the world scene.
*/
class iEditMesh: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iEditMesh"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Edit mesh interface"; }
	
	// [ Custom interface ]===================================

	//! Get the number of surfaces from this mesh
	virtual uint							GetSurfacesNo() = 0;

	//! Get a handle to the n-th surface of the mesh
	virtual t_handle					GetSurface(uint index) = 0;

	//! Get the attribute flags of the vertices in the given surface
	virtual int32							GetVertexAttributeFlags(t_handle surface) = 0;

	//! Get a ascii string description of the data type for the given vertex attribute
	/*! This method returns the ascii name of the data type used to store the specified vertex attribute.
		The returned value can be one of the following:
			- float
			- float2
			- float3
			- double
			- double2
			- double3
	*/
	virtual const char*				GetVertexAttributeDataTypeDesc(t_handle surface, int32 attrib_flag) = 0;

	//! Get the number of vertex attribute elements for the given surface and attribute flag
	virtual uint							GetVertexAttributeElementsNo(t_handle surface, int32 attrib_flag) = 0;

	//! Fill the given buffer with the specified vertex attribute data
	/*! The provided buffer size needs to be large enough to store the requested attributes. The size of the buffer in bytes can be computed by calling GetVertexAttributesNo() and
	multiplying the returned value with the size of the data type returned by the GetVertexAttributeDataTypeDesc() method.*/
	virtual t_error						GetVertexAttributeBuffer(t_handle surface, int32 attrib_flag, void* attrib_buffer) = 0;

	//! Get the number of indices for the specified surface (according to the surface face count and primitive type)
	virtual uint							GetIndicesNo(t_handle surface) = 0;

	//! Fill the given buffer with the indices for the specified surface and vertex attribute
	virtual t_error						GetIndicesBuffer(t_handle surface, int32 attrib_flag, uint* index_buffer)  = 0;


};

//====================================================
} // namespace csdk
#endif
/*@}*/