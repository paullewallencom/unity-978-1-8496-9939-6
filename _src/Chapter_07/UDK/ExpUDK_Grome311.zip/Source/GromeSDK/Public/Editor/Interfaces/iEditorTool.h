//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2008 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_IEDITORTOOL_H
#define __CSDK_IEDITORTOOL_H

#include "../../Engine/Interfaces/iSdkInterface.h"

namespace csdk {

//====================================================
typedef t_error (*t_tool_processing_hook)(iSdkInterface* target);

//! Interface to an editor tool.
class iEditorTool: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iEditorTool"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Editor tool interface"; }
	
	// [ Custom interface ]===================================

	//! Run the tool with the current settings.
	virtual void Run() = 0;

	//! Load a tool preset.
	virtual t_error LoadPreset(const char *preset_name) = 0;

	//! Set a processing hook on the tool  
	/*! The user can set a processing hook on the active tool, so that when the tool is processing a target node, the hook is called
	for that particular node and the user can do its own modification routines on the node. If the tool does not support hook functionality, an error code is returned.*/
	virtual t_error BindProcessingHook(t_tool_processing_hook hook) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/