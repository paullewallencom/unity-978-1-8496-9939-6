//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007-2011 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ILODENTITYTEMPLATE_H
#define __CSDK_ILODENTITYTEMPLATE_H

#include "iGeomEntityTemplate.h"
#include "iPropertyTable.h"
#include "iMaterial.h"

namespace csdk {

//====================================================

//! LOD entity made of discrete geometry templates.
/*! 
This interface is obtained from iGeomEntityTemplate interfaces which refer to a
geometric template made of multiple other templates representing various levels of detail.
*/
class iLODEntityTemplate: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iLODEntityTemplate"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "LOD entity template interface"; }
	
	// [ Custom interface ]===================================
	
	//! Return the no of levels in the LOD chain.
	virtual uint GetLevelsNo() = 0;

	//! Return the data from a specified level.
	/*! \warning The returned pointer is temporary and should not be stored. If you want to keep its
	content. copy all the members to your variables, increasing the reference count to the element interface. 
	sLODEntityTemplateElem::elem_interface could be released if you don't call ReferInterface on it. */
	virtual const struct sLODEntityTemplateElem* GetLevelElem(const uint level) = 0;

	//! Add a new level to the LOD template
	virtual t_error AddLevel(const struct sLODEntityTemplateElem* elem) = 0;
	
};

//! Structure describing a level in template's LOD chain (represented by iLODEntityTemplate).
struct sLODEntityTemplateElem
{
	//! Interface to the template on this level.
	/*! This can be NULL for levels that indicate no geometry to be used at the specified distances. */
	iSdkInterface *elem_interface;

	//! The distance at which this level becomes active (is visible).
	float start_distance;

	//! Custom material for this LOD.
	iMaterial *material;

	//! Custom material parameters per LOD.
	iPropertyTable *material_params;
};

//====================================================
} // namespace csdk
#endif
/*@}*/