//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_INODEPLUGIN_H
#define __CSDK_INODEPLUGIN_H

#include "iPlugin.h"
#include "../Interfaces/iStorage.h"

namespace csdk {

//====================================================

//! Text describing the plug-in type.
#define C_PLUGIN_TYPE_NODE "Node"

//! This type of plug-in defines custom engine nodes of a certain type.
/*! 
This interface is used as a base class for all the node types defining plug-ins.
There are certain types of engine nodes that can be defined by plug-ins. This is 
merely a base class. You cannot define plug-ins directly from this interface!
iStoragePlugin, iGeomEntityTemplatePlugin etc. are derived classes that provides 
plug-in interfaces for various types of engine nodes. 
*/
class iNodePlugin: public iPlugin
{
public:

	//! Return the category this plug-in belongs to.
	virtual const char* PluginType() { return C_PLUGIN_TYPE_NODE; }

	//! Load the plug-in in the system (init its data and make it active).
	virtual t_error Activate(const t_bool activate)
	{
		// Nothing to do here for now, override if you need operations here.
		return C_GENERIC_SUCCESS;
	}
	//! Always return true for node plug-ins so the node factory and their nodes are always valid.
	virtual t_bool IsActive()
	{
		return C_TRUE;
	}

	//! Return the type of the engine node this plug-in defines.
	/*! Custom derived classes will return various strings representing the node types (example: "Storage", "GeomEntityTemplate" etc.). */
	virtual const char* NodeType() = 0;

	//! Name of the node factory to be used as parameter for iRootInterface::NewNode(factory_name).
	/*! Plug-in must implement this function and return a unique factory name to be registered with the system. */
	virtual const char* NodeFactory() = 0;

	// ==================================================

	//! Called by the system to create the node custom data.
	/*!
	This is the first function called by the system when a node is created. The plug-in should allocate
	the necessary data here in a structure inherited from cNodeData.
	*/
	virtual cNodeData* NewNodeData() = 0;

	//! Release node data created by this plug-in.
	/*!
	This is the last call made by the system before the node is released.
	\param node_data Data previously allocated in NewNodeNode that must be freed.
	*/
	virtual void ReleaseNodeData(cNodeData *node_data) = 0;

	// The rest of the node type specific functions will be defined in derived classes (example: iStorageNode)

};

//====================================================
}; // namespace csdk
#endif
/*@}*/