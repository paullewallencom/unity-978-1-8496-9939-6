//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ISURFACETEMPLATE_H
#define __CSDK_ISURFACETEMPLATE_H

#include "iTexture.h"
#include "iMaterial.h"

namespace csdk {

//====================================================

//! Geometric surface primitive type.
enum E_PRIMITIVE_TYPE 
{
	C_PRIM_UNKNOWN = 0,
	C_PRIM_POINTS,
	C_PRIM_LINES,
	C_PRIM_LINE_STRIP,
	C_PRIM_LINE_LOOP,
	C_PRIM_TRIANGLES,
	C_PRIM_TRIANGLE_STRIP,
	C_PRIM_TRIANGLE_FAN,
	C_PRIM_QUADS,
	C_PRIM_QUAD_STRIP,
	C_PRIM_POLYGON
};

//! Interface to a geometrical surface template.
/* 
Surface templates contains geometrical data like indexed vertices (position,
texture mappings, normals, colors), texture bindings, material properties.

Instances (localized by a matrix) of templates create visible surfaces that can be 
manipulated via \c iSurfaceInstance interface. 

\warning Surface template interfaces are local to their geometry entity (their
interface id is NULL) and pointer to them should not be stored for later use.
*/
class iSurfaceTemplate: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iSurfaceTemplate"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Geometric Surface Template Interface"; }
	
	// [ Custom interface ]===================================

	//! Return the primitive type.
	virtual E_PRIMITIVE_TYPE GetPrimitiveType() = 0;

	//! Return the no of vertex indices (or zero for non indexed surfaces).
	virtual int GetIndNo() = 0;
	//! Return an array representing vertices indices (or NULL for non indexed surfaces).
	virtual const int* GetInd() = 0;

	//! Return the no of vertices in the surface.
	virtual int GetVertNo() = 0;
	//! Return an array representing vertices positions.
	virtual const t_float3* GetVertPositions() = 0;
	//! Return an array representing vertices normals.
	virtual const t_float3* GetVertNormals() = 0;
	//! Return an array representing vertices colors.
	virtual const t_float4* GetVertColors() = 0;
	//! Return an array representing vertices secondary colors.
	virtual const t_float4* GetVertSecondaryColors() = 0;
	//! Return an array representing vertices texture coordinates.
	/*! \param unit The texture unit this coordinates are referring to (from 0 to 15). */
	virtual const t_float2* GetVertTexMap(const uint unit) = 0;

	//! Return the surface bounding box (made of 8 vertex positions).
	virtual const t_float3* GetBBox() = 0;

	//! Return the interface to a texture bound for a certain unit (from 0 to 15).
	virtual iTexture* GetTexture(const uint unit) = 0;

	//! Return the material bound to this surface template.
	virtual iMaterial* GetMaterial() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/