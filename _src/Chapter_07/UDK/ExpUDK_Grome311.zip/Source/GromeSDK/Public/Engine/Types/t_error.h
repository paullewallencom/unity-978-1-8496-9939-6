//====================================================
/* Core SDK - QUAD Software */
/*! 
\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_ERROR_H
#define __CSDK_T_ERROR_H

//====================================================
// Error codes.

#define M_FAILED(code) ((code) < 0)
#define M_SUCCEED(code) ((code) >= 0)
#define M_SUCCEEDED(code) ((code) >= 0)

//! Generic success code.
#define C_GENERIC_SUCCESS 0
//! Success code but with with warnings.
#define C_WARNING_SUCCESS 1
#define C_SKIPPED_SUCCESS 2

#define C_GENERIC_ERROR -1

// File operations return codes.
#define C_STOR_EOF_ERR -10
#define C_STOR_INVALID_FORMAT_ERR -11
#define C_STOR_OPEN_ERR -12
#define C_STOR_CREATE_ERR -13
#define C_STOR_WRITE_ERR -14
#define C_STOR_READ_ERR -15
#define C_STOR_DELETE_ERR -16
#define C_STOR_LOCK_ERR -17
#define C_STOR_EXISTENT_LOCK_ERR -18
#define C_STOR_LINK_ERR -19
//! Storage error indicating that another node (storage?) is needed to complete the operation.
#define C_STOR_DEPENDENCY_ERR -20
#define C_STOR_NO_DATA_ERR -50
#define C_STOR_NO_STRUCT_ERR -51
#define C_STOR_PARTIAL_DATA_ERR -70

#define C_NULLOBJ_ERR -200
#define C_NULLCONTEXT_ERR -201

// Memory errors.
#define	C_ALLOC_ERR -300

// Miscellaneous.
#define C_INIT_ERR -500
#define C_PARAM_ERR -501
#define C_NOTSUPPORTED_ERR -502
#define C_NOTIMPLEMENTED_ERR -503
#define C_NOTFOUND_ERR -505
#define C_EXISTENT_ERR -506
#define C_NOTREGISTERED_ERR -507
#define C_VERSION_ERR -508
#define C_TYPE_ERR -509

// Compilation related.
#define C_SYNTAX_ERR -1000			//!< Syntax error (for shaders and other scripts).
#define C_NOT_COMPILED_ERR -1001

//====================================================

namespace csdk {

	typedef int t_error;

}

//====================================================
#endif
/*@}*/