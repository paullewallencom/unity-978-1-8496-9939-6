//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

Copyright (C) 2006 Quad Software
This software is provided 'as-is', without any express or implied warranty.  In no event 
will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_HANDLE_H
#define __CSDK_T_HANDLE_H

#ifndef __CSDK_TYPES_H
#	error Include types.h instead of dirrectly including t_handle.h
#endif

//====================================================

// Handle types (indicating what value the handle represents)
#define C_SDKHANDLE_PVOID		0
#define C_SDKHANDLE_INDEX			1

//====================================================

namespace csdk {

//! Handle typed used to refer to an element from an array, list or other collection.
class t_handle {

public:

	int type;
	t_machine_int value;

	t_handle() { type = C_SDKHANDLE_PVOID; value = 0; }
	t_handle(void* v) { type = C_SDKHANDLE_PVOID; value = (t_machine_int)v; }
	t_handle(t_machine_int v) { type = C_SDKHANDLE_INDEX; value = v; }
	
	operator t_machine_int() 
	{
		if(type == C_SDKHANDLE_INDEX)
			return value;
		else return -1; // not int type
	}

	operator void*()
	{
		if(type == C_SDKHANDLE_PVOID)
			return (void*)value;
		else return NULL;
	}

	t_bool operator==(t_handle h) const 
	{
		if(type == h.type && value == h.value) return C_TRUE;
		return C_FALSE;
	}

	t_bool operator==(t_machine_int v) const
	{
		if(type != C_SDKHANDLE_INDEX || v != value) return C_FALSE;
		return C_TRUE;
	}

	t_bool operator==(void* v) const
	{
		if(type != C_SDKHANDLE_PVOID || (t_machine_int)v != value) return C_FALSE;
		return C_TRUE;
	}

	t_bool IsNull() const 
	{
		if((type == C_SDKHANDLE_INDEX && value == -1) ||
			(type == C_SDKHANDLE_PVOID && value == 0)) 
		{
			return C_TRUE;
		}
		return C_FALSE;
	}

	t_bool IsNotNull() const 
	{
		if(type == C_SDKHANDLE_INDEX)
		{
			if(value == -1) return C_FALSE;
			return C_TRUE;
		}
		if(type == C_SDKHANDLE_PVOID)
		{
			if(value == 0) return C_FALSE;
			return C_TRUE;
		}
		return C_TRUE;
	}

};

//====================================================
} // namespace csdk
#endif
/*@}*/