//====================================================
/* Core - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_ARRAY_H
#define __CSDK_T_ARRAY_H

#include "t_readonly_array.h"

namespace csdk {

#define C_DYN_ARRAY_INVALID_IDX		UINT_MAX

//=========================================================
//! Writable array for custom types
template <class TYPE> class t_array: public csdk::t_readonly_array<TYPE>
{
public:

	t_array()
	{
		_elem = NULL;
		_no = 0;
	}

	~t_array()
	{
		if(_elem) free(_elem);
	}

	void Release()
	{
		if(_elem) { free(_elem); _elem = NULL; }
		_no = 0;
	}

	void Reset()
	{
		_no = 0;
	}

	void Resize(const uint size)
	{
		_no = size;
		_elem = (TYPE*)realloc(_elem, _no*sizeof(TYPE));
	}

	void Shrink(const uint size)
	{
		if(size > _no) return;
		_no = size;
	}

	//! Preallocate more elements to be added with AddAllocated.
	void __fastcall MakeRoom(const uint i) 
	{
		_no += i;
		_elem = (TYPE*)realloc(_elem, _no*sizeof(TYPE));
	}

	void __fastcall Ins(TYPE e, uint index)
	{
		uint prior_no = _no;

		_AddBlank();

		if(index >= prior_no)
		{
			_elem[prior_no] = e;
		}
		else
		{
			for(uint i=prior_no; i>index; i--)
				_elem[i] = _elem[i-1];
			_elem[index] = e;
		}
	}

	void __fastcall Add(TYPE e)
	{
		_AddBlank();
		_elem[_no-1] = e;
	}

	//! Add an element for which we know we have space allocated.
	void __fastcall AddAllocated(TYPE e) 
	{
		_elem[_no] = e;
		_no ++;
	}

	void AddBlank()
	{
		_AddBlank();
	}

	uint __fastcall GetIndex(TYPE e)
	{
		for(uint i=0; i<_no; i++)
			if(_elem[i] == e) 
				return i;
		return C_DYN_ARRAY_INVALID_IDX;
	}

	void __fastcall Del(uint pos)
	{
		_no --;
		if(pos < _no) // Move the last element in this position.
			_elem[pos] = _elem[_no];
	}

	t_error __fastcall DelElem(TYPE e)
	{
		uint idx = GetIndex(e);
		if(idx == C_DYN_ARRAY_INVALID_IDX)
			return C_NOTFOUND_ERR;
		Del(idx);
		return C_GENERIC_SUCCESS;
	}

	void __fastcall DelAndKeepOrder(uint pos)
	{
		for(uint i=pos; i<_no-1; i++) 
			_elem[i] = _elem[i+1];
		_no --;
	}

protected:

	void _AddBlank()
	{
		_no ++;
		_elem = (TYPE*)realloc(_elem, _no*sizeof(TYPE));
	}

};


//=========================================================
} // namespace csdk
#endif
/*@}*/