//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IPROPERTYTABLEOWNER_H
#define __CSDK_IPROPERTYTABLEOWNER_H

#include "iPropertyTable.h"

namespace csdk {

//====================================================

//! SDK interface exposed by entities that support properties to be attached to them.
class iPropertyTableOwner: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iPropertyTableOwner"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Property Table Owner"; }

	//==================================================

	//! Add a properties from a table to this entity.
	/*! The \p table is cloned and the new table is attached to the entity. The structure and values of the original 
	table can be modified, the entity with the original structure has its own table that can be returned with GetPropertyTable. */
	virtual t_error AddProperties(iPropertyTable *table) = 0;

	//! Return the number of properties tables holding the entity custom properties.
	virtual uint GetPropertyTablesNo() = 0;

	//! Return an entity table given its index.
	virtual iPropertyTable* GetPropertyTable(const uint index) = 0;

	//! Delete the entity property table given its index.
	/*! This function deletes the entity own property table that has nothing to do with the 
	original table used to add its properties. */
	virtual t_error DelPropertyTable(const uint index) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/