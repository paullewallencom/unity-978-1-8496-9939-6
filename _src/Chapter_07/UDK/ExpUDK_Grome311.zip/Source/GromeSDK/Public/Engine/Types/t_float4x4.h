//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_FLOAT4X4_H
#define __CSDK_T_FLOAT4X4_H

namespace csdk {

//====================================================

typedef struct t_float4x4 {

	union {

		struct {	

			float	m00, m01, m02, m03; 
			float	m10, m11, m12, m13; 
			float	m20, m21, m22, m23; 
			float	m30, m31, m32, m33;
		};

		float m[4][4];
	};

} t_float4x4;

//====================================================
} // namespace csdk
#endif
/*@}*/