//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IPLUGIN_H
#define __CSDK_IPLUGIN_H

#include "../Interfaces/iRootInterface.h"

// Valid plug-ins files must export the following C functions:
//! Function to be called to return the interface to the plug-in from this file.
#define C_PLGMOD_GETPLUGIN_FUNC_NAME		"GetPluginInterface"
//! Declarations for the functions.
#define C_PLGMOD_GETPLUGIN_FUNC_DECL		"void* GetPluginInterface(void*)"
// To be noted that there is only one plug-in per file.

namespace csdk {

//! Type of the function to be exported by a plug-in module.
/*! \return Pointer to the csdk::iPlugin interface. */
typedef void* (*t_getplugin_func)(void*);

//====================================================

//! Base interface for all the plug-ins written for the engine.
/*
	3rd party plug-ins must inherit and implement this interface. Pointers to 
	this interface are returned from the plug-in modules.
*/
class iPlugin: public iSdkInterface
{
public:

	//! Call this function when this interface is no longer used.
	virtual void CloseInterface()
	{
		// Nothing to do here, plug-in interfaces are usually closed automatically after usage by the system.
	}

	//! Return the SDK version this plugin was built upon.
	/*! 
	\warning Do not modify this function. This function is always first in the plugin interface.

	Returned number contains 3 groups of numbers: major (first 1 or 2), minor (the next 2)
	and details (the last 2, even for stable, odd for in development). 
	The editor usually verify the first 2 groups (major and minor) against its own version
	and decide if it is safe to use the plug-in or not. */
	virtual uint GetSdkVersion() { return C_CORE_SDK_VERSION; }

	//! Return the category this plug-in belongs to.
	virtual const char* PluginType() = 0;

	//! Short name of the plug-in.
	virtual const char* PluginName() = 0;

	//! Return the author of the plug-in.
	virtual const char* Vendor() = 0;
	//! Return any copyright text.
	virtual const char* CopyrightNotice() = 0;

	//! Called by the engine when the module from which the plug-in is created is unloaded.
	/*! Here the plug-in can do the final release operations while on GetPluginInterface can do the init operations. */
	virtual void OnUnloadModule() { }

	//! Load the plug-in in the system (init its data and make it active).
	/*! After activation a plug-in must be ready to perform its custom operations. 
	Some plug-ins here will make their U.I. available in the host application. At deactivation the plug-in will close its UI. */
	virtual t_error Activate(const t_bool activate) { return C_GENERIC_SUCCESS; }
	//! Indicate if the plug-in is active or not.
	virtual t_bool IsActive() { return C_FALSE; }

};

//====================================================
} // namespace csdk
#endif
/*@}*/