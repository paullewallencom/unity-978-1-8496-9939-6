//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_FLOAT3X3_H
#define __CSDK_T_FLOAT3X3_H

namespace csdk {

//====================================================

typedef struct t_float3x3 {
	
	union {
		
		struct {	
			
			float	m00, m01, m02; 
			float	m10, m11, m12; 
			float	m20, m21, m22; 
		};
		
		float m[3][3];
	};
	
} t_float3x3;

//====================================================
} // namespace csdk
#endif
/*@}*/