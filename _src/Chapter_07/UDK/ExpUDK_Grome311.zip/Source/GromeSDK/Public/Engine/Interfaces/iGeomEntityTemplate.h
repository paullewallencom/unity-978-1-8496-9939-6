//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IGEOMENTITYTEMPLATE_H
#define __CSDK_IGEOMENTITYTEMPLATE_H

#include "iSurfaceTemplate.h"
#include "iGeomEntityInstance.h"
#include "iTexture.h"

namespace csdk {

//====================================================

//! Node factory name to create textures (with iRootInterface::NewNode).
#define C_NODE_FACTORY_GEOMENTITYTEMPLATE	"GeomEntityTemplate"

//! Geometric entity template.
/*! 
This is an interface to an engine entity representing a geometry template. It can have multiple surfaces
(iSurfaceTemplate) associated with it (i.e. an entity can have multiple geometrical parts, every one with its 
materials, textures and geometrical data). 

This template is used to create multiple instances (called geometry entity instances and represented by
iGeomEntityInstance interfaces). For every surface in the template there is a surface instance (iSurfaceInstance)
in every geometric entity instance.

The template interface is obtained from other SDK interfaces like terrain zones, object templates etc.
*/
class iGeomEntityTemplate: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iGeomEntityTemplate"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Geometric entity template interface"; }
	
	// [ Custom interface ]===================================

	//! Return the global bounding box in 8 points format (a vertex position for every corner).
	/*! This is the global bounding box, large enough to contain all the template surfaces. 
	Individual surfaces have their own smaller bounding boxes. 
	Each of the 8 points contain 3 values (xyz): {minx, miny, minz}, {maxx, miny, minz}, 
	{minx, maxy, minz}, {maxx, maxy, minz}, {minx, miny, maxz}, {maxx, miny, maxz}, 
	{minx, maxy, maxz}, {maxx, maxy, maxz}. So 0 index contain the min point, and 7 (last)
	the max point. */
	virtual const t_float3* GetBBox() = 0;

	//! Return the surfaces that makes this template.
	/*! \warning After modifications to the current scene parts of this array may become invalid. 
	That's why it is not recommended to store this array for later use. At each GetSurfaces call
	the array and its content (the interfaces to surface templates) are released and recreated. */
	virtual t_readonly_array<iSurfaceTemplate*>* GetSurfaces() = 0;

	//! Return the geometrical entity instances created from this template.
	/*! \warning After modifications to the current scene (deletion, insertion of instances etc.) 
	parts of this array may become invalid (some interfaces referring to released instances and
	their operations have no effect). That's why it is not recommended to store this array for later use. */
	virtual t_readonly_array<iGeomEntityInstance*>* GetInstances() = 0;
	
};

//====================================================

//! Modifier class for a geometry template.
/*! Geometry templates that support modifications of their data from SDK will export this subinterface. */
class iGeomEntityTemplateModifier: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with iRootInterface::GetTypeId(iGeomEntityTemplateModifier::TypeString())).
	static const char* TypeString() { return "iGeomEntityTemplateModifier"; }

	// ==================================================

	//! Create and add a new surface template.
	/*! The surface is added as the last surface inside the geometric template. 
	The geometry must be in left handed coordinate system with X right, Y up and Z forward.
	Internally geometry is counter clockwise. You can supply clockwise winding and indicate
	this by cSurfaceDescription::clockwise_indices and the indixing is converted. */
	virtual t_error AddNewSurface(const class cSurfaceDescription *descr) = 0;

};

#define C_SURFACE_MAX_TEXMAPS	16

//! Structure describing a new geometry entity to be created (iGeomEntityTemplateModifier::AddNewSurface).
/*!
You indicate the surface topology as indexed geometry. Only triangle primitives are supported for now.
A surface can have vertex positions, normals, colors and up to C_SURFACE_MAX_TEXMAPS texture coordinates.
Use NULL for unused vertex attributes.

Every vertex attribute can be contained in a separate array and can have separate indices. A triangle is formed
by taking the first 3 indices from every attribute. So basically you must have the same number of indices for every
attribute (this being indices_no). This allow you to have positions, normals, colors and mapping per face. Internally
the engine is using unique normals, colors and mapping per vertex (not per face) and will transform the data from 
this structure accordingly (so the final indexing is not the same as the one you've indicated and vertex attributes 
may be duplicated to enforce this restriction).

All the vertex attributes indices can be indicate with a stride (step to take when taking the values by indices). 
Grome is using stride in the following mode:

	vertex_attribute = cSurfaceDescription.vertex_attribute[attribute_index * attribute_stride];

Most common case is when the user has the data in an array of structures. In this case the attributes must be copied
in a structure of arrays:

	cSurfaceDescription descr;
	descr.positions = allocate an array of t_float3 and fill it from array_of_struct[0..N].position
	descr.normals = allocate and fill from array_of_struct[0..N].normal
	...

	where N = number of vertices.

For indices, most common case is when the same indices are used for all components:

	descr.indices_no = number of indices
	descr.positions_indices = normals_indices = ... = user_indices[0...descr.indices_no] // Common to all components, user can share the same array pointer for the indices of normals, positions etc.
	descr.positions_indices_stride = descr.normals_indices_stride = ... = 1; // One since you share the same index array.

So Grome will take the final un-indexed positions as:

	internal_positions = descr.positions[descr.positions_indices[I * descr.positions_indices_stride]];
	Where I is between 0 and descr.indices_no

All the attributes have float members and their member number depends on attribute (3 for positions and normals, 
4 for colors, 2 for texture coordinates).
*/
class cSurfaceDescription
{
public:

	cSurfaceDescription()
	{
		memset(this, 0, sizeof(cSurfaceDescription));
		primitive_type = C_PRIM_TRIANGLES;
	}

	E_PRIMITIVE_TYPE primitive_type; //!< Type of primitives making the geometry entity (only C_PRIM_TRIANGLES supported for now!).

	uint indices_no; //!< Total number of indices for the surface faces.
	t_bool clockwise_indices; //!< If true, all polygons (the indexing) is clockwise. Engine uses counter clockwise geometry and must invert received indices.

	uint positions_no; //!< No of vertices in positions array.
	void *positions; //!< Array containing vertex positions (3 floats for X, Y and Z).
	uint *positions_indices; //!< Indices for the positions (array of indices_no uints).
	uint positions_indices_stride; //!< Stride (step) inside the positions_indices array to take the positions indices.

	uint normals_no; //!< No of elements in normals array.
	void *normals; //!< Array containing vertex normals (3 floats for X, Y and Z).
	uint *normals_indices; //!< Indices for the normals (array of indices_no uints).
	uint normals_indices_stride; //!< Stride (step) inside the normals_indices array to take the normals indices.

	uint colors_no; //!< No of elements in colors array.
	void *colors; //!< Array containing vertex colors (4 floats for R, G, B, A).
	uint *colors_indices; //!< Indices for the colors (array of indices_no uints).
	uint colors_indices_stride; //!< Stride (step) inside the colors_indices array to take the colors indices.

	uint sec_colors_no; //!< No of elements in sec_colors array.
	void *sec_colors; //!< Array containing vertex secondary colors (4 floats for R, G, B, A).
	uint *sec_colors_indices; //!< Indices for the secondary colors (array of indices_no uints).
	uint sec_colors_indices_stride; //!< Stride (step) inside the sec_colors_indices array to take the secondary colors indices.

	uint texmaps_no[C_SURFACE_MAX_TEXMAPS]; //!< No of elements in texmaps arrays.
	void *texmaps[C_SURFACE_MAX_TEXMAPS]; //!< Array containing vertex texture coordinates (2 floats for U, V).
	uint *texmaps_indices[C_SURFACE_MAX_TEXMAPS]; //!< Indices for the texture coordinates (arrays of indices_no uints).
	uint texmaps_indices_stride[C_SURFACE_MAX_TEXMAPS]; //!< Stride (step) inside the texmaps_indices array to take the texture coordinates indices.

	iTexture* textures[C_SURFACE_MAX_TEXMAPS]; //!< Textures for every unit.

	//! Material to be assigned for this surface.
	/*! This can be NULL in which case the default material is used. */
	iMaterial *material;

};

//====================================================
} // namespace csdk
#endif
/*@}*/