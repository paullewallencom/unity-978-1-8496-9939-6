//====================================================
/* Core - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_READONLY_ARRAY_H
#define __CSDK_T_READONLY_ARRAY_H

namespace csdk {

//=========================================================

//! Read only array of custom types.
template <class TYPE> class t_readonly_array 
{

protected:
	
	//! Allocated array of elements.
	TYPE *_elem;
	//! Elements no.
	uint _no;
	
public:

	//! Return the no of elements in the array.
	uint No() { return _no; }

	//! Return the element at position \p pos.
	TYPE& __fastcall Elem(const uint pos) { return _elem[pos]; }

	//! Operator to return the element at position \p pos.
	TYPE& operator[](const uint pos) { return _elem[pos]; }

	//! Return the buffer of elements directly.
	TYPE* Elems() {return _elem;}

};

//=========================================================
} // namespace csdk
#endif
/*@}*/