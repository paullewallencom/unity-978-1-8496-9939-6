//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IIOSTREAM_H
#define __CSDK_IIOSTREAM_H

#include "iSdkInterface.h"

namespace csdk {

#define C_IOSTREAM_INTERFACE_NAME	"IOStream"

//! Interface for I/O streaming operations.
/*! 
This interface offers basic input/output operations on the engine storage system nodes (files, memory buffers, etc).
*/
class iIOStream: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iIOStream"; }

	virtual const char* Name() { return C_IOSTREAM_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Input / Output Stream"; }

	// ==================================================

	//! Perform a read operation on the stream to the given destination buffer
	/*! The function reads the specified number of items with the given size into the buffer. It returns the number of items successfully read.*/
	virtual uint Read(void* dest, uint item_size, uint items_no) = 0;

	//! Perform a write operation on the stream from the given source buffer
	/*! The function writes the specified number of items with the given size from the buffer. It returns the number of items successfully written.*/
	virtual uint Write(void* src, uint item_size, uint items_no) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/