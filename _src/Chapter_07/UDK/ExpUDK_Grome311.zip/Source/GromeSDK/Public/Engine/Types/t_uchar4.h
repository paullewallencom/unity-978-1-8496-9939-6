//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_UCHAR4_H
#define __CSDK_T_UCHAR4_H

namespace csdk {

//====================================================

typedef struct t_uchar4 {

	unsigned char r, g, b, a;

} t_uchar4;

//====================================================
} // namespace csdk
#endif
/*@}*/