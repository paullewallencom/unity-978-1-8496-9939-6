//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file iStorageManager.h
	\brief Storage manager public SDK interface.

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_STORAGEMANAGER_H
#define __CSDK_STORAGEMANAGER_H

#include "iStorage.h"

namespace csdk {

//! Name used to register the iStorageManager interface with the SDK root.
/*! Use iRootInterface::GetInterface(C_STORAGEMANAGER_INTERFACE_NAME) to open the global scene interface. */
#define C_STORAGEMANAGER_INTERFACE_NAME		"Storage Manager"

//! Interface to the storage manager.
/*! 
Storage manager contains various storage related functions.
*/
class iStorageManager: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iStorageManager"; }

	virtual const char* Name() { return C_STORAGEMANAGER_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Storage Manager"; }
	
	// [ Custom interface ]===================================

	//! Extract the file name from a complete OS path.
	/*! \param path Complete path to extract the file name from.
	\return The file name or NULL. Returned pointer may be temporary and should not be stored */
	virtual const t_char* ExtractFileName(const t_char* path) = 0;

	//! Extract the file name without the extension.
	/*! \param file_name File name with the extension.
	\return The file name. Returned pointer may be temporary and should not be stored. */
	virtual const t_char* ExtractFileWithoutExt(const t_char* file_name) = 0;

	//! Extract the file extension from an OS path.
	/*! \param path Path to extract the file extension from.
		\return The file extension or NULL. Returned pointer may be temporary and should not be stored. */
	virtual const t_char* ExtractFileExt(const t_char* path) = 0;

	//! Extract the directory from a complete OS path.
	/*! \param path Complete path to extract the file name from.
		\return The directory name or NULL. Returned pointer may be temporary and should not be stored. */
	virtual const t_char* ExtractFileDir(const t_char* path) = 0;

	//! Create a new path by applying one path to another (if path2 is a global path this path will be returned).
	/* \return The complete path or NULL if an error occurs. Returned pointer may be temporary and should not be stored. */
	virtual const t_char* ConcatPaths(const t_char *path1, const t_char *path2) = 0;

	//! Return the relative path of a given path to another path (ex. c:\dir1\ and c:\dir2\file.txt will produce ..\dir2\file.txt as the relative path of the file.txt to the first folder)
	/* \return The complete path or NULL if an error occurs. Returned pointer may be temporary and should not be stored. */
	virtual const t_char* GetRelativePath(const t_char* path1, const t_char* path2) = 0;

	//! Indicate if the given path is relative or absolute.
	virtual t_bool IsRelativePath(const t_char *path) = 0;

	//! Return the storage associated with a (O.S. specific) path.
	/*! If the path is valid but refers to an unexistent storage (folder or package) creates a blank storage.
	\param os_path OS specific path for which to return the storage. This must be absolute
	path. To obtain an absolute path from a relative one use iStorageManager::ConcatPaths.
	If this is NULL the program installation storage is returned (where the editor is installed).
	\return NULL if the device format from the specified path is unknown. The reference count
	of the returned interface is increased so you must call CloseInterface when no longer needed. 
	/*! \warning Don't call this function too often since it may be expensive as its parsing all
	the storages from the path. */
	virtual iStorage* GetStorageFromPath(const t_char *os_path) = 0;

	//! Verify if a given path represents a directory
	/*!	\param path The path name
			\return C_TRUE if the given path name represents a directory on disk or a drive name. The function returns C_FALSE if the path points
			to a file.	*/
	virtual t_bool	IsPathDir(const t_char* path) = 0;

	//! Given an pattern path search first file/directory in that path and returns a handle to the search result to be used with FindNextFile for subsequent searches.
	/*!	\param path The path name
			\return A handle to the search result*/
	virtual t_handle FindFirstFile(const t_char *path) = 0;

	//! Given a handle returned by gFindFirstFile will search another file matching the searching pattern.
	/*!	\param find_handle The handle returned by a previous search call.
			\return C_TRUE if the search was successful
	*/
	virtual t_bool FindNextFile(t_handle find_handle) = 0;

	//! Close a searching handle.
	/*!	\param find_handle The handle returned by a previous search call*/
	virtual void CloseFindFileHandle(t_handle find_handle) = 0;

	//! Return the name (not full path) to the found file.
	/*!	\param find_handle The handle returned by a previous search call
			\return The UNICODE name of the found path.*/
	virtual const t_char* FindFileName(t_handle find_handle) = 0;

	//! Return the size of a found file,
	/*!	\param find_handle The handle returned by a previous search call
			\return The size in BYTES of the file specified by the handle.*/
	virtual unsigned long FindFileSize(t_handle find_handle) = 0;

	//! Indicate that the searching handle refers to a directory (folder).
	/*!	\param find_handle The handle returned by a previous search call
	*/
	virtual t_bool FindFileIsDir(t_handle find_handle) = 0 ;

	//! Return true if the find file handle is referring to a system file/folder.
	/*!	\param find_handle The handle returned by a previous search call
	*/
	virtual t_bool FindFileIsSystem(t_handle find_handle) = 0;

	//! Return true if the find file handle is referring to a hidden file/folder.
	/*!	\param find_handle The handle returned by a previous search call
	*/
	virtual t_bool FindFileIsHidden(t_handle find_handle) = 0;

	//! Return true if the find file handle is referring to a read only file/folder.
	/*!	\param find_handle The handle returned by a previous search call
	*/
	virtual t_bool FindFileIsReadOnly(t_handle find_handle) = 0;

	//! Return the storage interface for the engine library root
	/*! This routine returns an interface to the storage which points to the root library folder (/libraries)
	*/
	virtual iStorage* GetLibraryStorage() = 0;

	//! Remove the specified folder given its path
	virtual t_error RemoveDir(const t_char* path) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/