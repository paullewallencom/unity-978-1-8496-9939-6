//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ISTORAGEPLUGIN_H
#define __CSDK_ISTORAGEPLUGIN_H

#include "iNodePlugin.h"
#include "../Interfaces/iStorage.h"

namespace csdk {

//====================================================

//! Text describing the node type defined by this plug-in.
#define C_NODE_TYPE_STORAGE "Storage"

//! Structure to hold information about a node inside a plug-in defined storage.
/*! This structure, besides holding the information from sStorageNodeInfo like the node
name and its factory name, will hold storage plug-in specific data (node_localization_data)
that is used by the plug-in to localize the node inside its space. Here the storage can 
keep any data, like offset inside files, unique ids etc. */
struct sStoragePluginNodeInfo: public sStorageNodeInfo
{
	//! Node specif storage data.
	/*! Here the storage can keep localization data for the node inside its space. */
	void *node_localization_data;
};

//====================================================

//! Plug-in interface that defines a storage node.
/*! 
A storage is a package that holds various other nodes and resides in external discs. It can
be seen as a folder containing multiple files (everyone with a node) and other subfolders.
The storage can be made of a folder or it can be in packed form where it can be a single file
containing internal directory structure (example: a zip archive).

It can be queried to return its components, new nodes can be added or removed. Usually
engine nodes are saved and later restored from storages. That is why nodes are identified
by their name and their storage (see iNodePlugin::NewNode parameters).

You can defined plug-ins of this type to add your own custom packages to the engine
(example: define a storage plug-in to load COLLADA files. This plug-in will parse its
content from a file and expose all the nodes (materials, images, geometrical meshes)
from it).

Interfaces returned by iStoragePlugin::NewNode must be of csdk::iStorage type.
*/
class iStoragePlugin: public iNodePlugin
{
public:

	//! Return the string indicating storage type node.
	virtual const char* NodeType() { return C_NODE_TYPE_STORAGE; }

	// Custom storage specific operations =======================
	// Override this to provide storage functionality to the system.

	//! Return the signature identifying a storage of this type on the disc during disc parsing.
	/*! 
	This is to be used as a search criteria when determining the format of a storage.
	The device extension (including the prefix .) is to be used.

	Example: ".dae" is to be used for COLLADA storages, ".my_bin" for a binary custom storage etc.
	
	When system will find a device (file) matching this signature it will consider it a storage as defined by this plug-in. 

	\warning The signature of the storage format should be all lower case, the search is considered case insenzitive. 

	Note: disc folders are also considered storages but they are treated as native package storages.
	*/
	virtual const t_char *GetFormatSignature() = 0;

	//! Called for a device (e.g. a file) with a signature as defined by this plug-in to determine if the format is valid.
	/*! Here the plug-in should do format validation tests to see if the device is indeed pointing to a 
	storage structure as defined by the plug-in. */
	virtual t_error ValidateFormat(const t_char *dev_name, iStorage *parent) = 0;

	//! Called by the system to set the parent storage.
	/*! 
	Storage device will be relative to its parent storage. 
	
	\warning If a pointer to the parent storage interface is retained you must increase its reference count
	(with iSdkInterface::ReferInterface) and decreased it again at release (with iSdkInterface::CloseInterface). 
	*/
	virtual t_error SetParentStorage(cNodeData *storage_data, iStorage *parent) = 0;

	//! Set the destination device this storage is pointing to (e.g. file, folder etc.).
	/*! 
	\param storage_data Storage specific data. 
	\param dev_name Name of the the device. If NULL the full_dev_path is taken as device name too.
	\param full_dev_path The full path to the device. If NULL the full path is constructed from dev_name and parent storage full path.
	\return An error code if the device was not found or the device cannot be changed. */ 
	virtual t_error SetDevice(cNodeData *storage_data, const t_char *dev_name, const t_char *full_dev_path = NULL) = 0;

	//! Return the path for the current device (example: "my_storage.bin").
	virtual const t_char *GetDeviceName(cNodeData *storage_data) = 0;

	//! Return the complete path for the device (example: "c:/temp/my_storage.bin").
	virtual const t_char *GetDevicePath(cNodeData *storage_data) = 0;

	//! Check if the storage is parsed.
	/*! This function will return false if the storage was parsed but later modified. 
	\param storage_data Storage specific data. 
	\param parse_level Indicate how much parsing must be done for this function to return true. 
	Use -1 for complete parsing, 0 only for this level of substorages etc. */
	virtual t_bool IsParsed(cNodeData *storage_data, const int parse_level = 0) = 0;

	//! Parse the device and announce the components to the system.
	virtual t_error Parse(cNodeData *storage_data, const int parse_level = 0) = 0;

	//! Return the total no of direct sub (or child) storages.
	virtual uint GetSubstoragesNo(cNodeData *storage_data) = 0;

	//! Called by the system to get information about a substorage.
	virtual t_error GetSubstorageInfo(cNodeData *storage_data, const uint index, sStoragePluginNodeInfo *o_info) = 0; 

	//! Return the no of nodes in the storage.
	virtual uint GetNodesNo(cNodeData *storage_data) = 0;

	//! Return information about a node in the storage.
	/*! These information must be available even though the node is not loaded from storage. */
	virtual t_error GetNodeInfo(cNodeData *storage_data, const uint index, sStoragePluginNodeInfo *o_info) = 0; 

	//! Called by the system when data for a node must be extracted from the storage.
	/*! Node is created by the system and this function is called so the storage implementation 
	can fill the node with data (through its interface). 
	\param storage_data Storage specific data. 
	\param node_localization_data Storage specific localization data for the node to be extracted. 
	This is taken from the \c sStoragePluginNodeInfo when the storage is parsed.
	\param node_interface Interface to the node to be extracted. */
	virtual t_error ExtractNodeData(cNodeData *storage_data, void *node_localization_data, iSdkInterface* node_interface) = 0;

};

//====================================================
}; // namespace csdk
#endif
/*@}*/