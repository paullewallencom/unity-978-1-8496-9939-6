//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file iConsole.h
	\brief Console logging public SDK interface.

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_CONSOLE_H
#define __CSDK_CONSOLE_H

#include "iSdkInterface.h"

namespace csdk {

//! Name used to register the iConsole interface with the SDK root.
/*! Use iRootInterface::GetInterface(C_CONSOLE_INTERFACE_NAME) to open the global scene interface. */
#define C_CONSOLE_INTERFACE_NAME		"Console"

//Console channels
#define F_CON_DEV					(1<<0) //!< Developing related messages.
#define F_CON_ERROR				(1<<1) //!< Error output.
#define F_CON_WARNING			(1<<2) //!< Warnings output.
#define F_CON_GAME					(1<<3) //!< Public release output.
#define F_CON_SCRIPT				(1<<4) //!< Script related output.
#define F_CON_EVENTS				(1<<5)//!< User events output.
#define F_CON_DEFAULT_CH_NO 6 //!< How many default channels are (so you can add more).
#define F_CON_GENERAL			(F_CON_DEV|F_CON_GAME) //!< Developing messages outputed to the game console too.
#define F_CON_ALL					0xFFFFFFFF //!< Ouput to all channels.


//! Interface to the console.
/*!
	This interface contains various console logging functions.
*/
class iConsole: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iConsole"; }

	virtual const char* Name() { return C_CONSOLE_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Console"; }
	
	// [ Custom interface ]===================================

	//! Print a message to the console
	virtual void	Print(const t_char* message, const int32 channel_flags = F_CON_GENERAL) = 0;

	//! Print a message with arguments to the console
	virtual void PrintArg(const t_char* message, const int32 channel_flags = F_CON_GENERAL, ...) = 0;
	
	//! Print a message to the DEV channel
	virtual void PrintDev(const t_char* message, ... ) = 0;

	//! Print a message to the ERROR channel
	virtual void PrintError(const t_char* message, ... ) = 0;

	//! Print a message to the WARNING channel
	virtual void PrintWarning(const t_char* message, ... ) = 0;

	//! Flush the contents of the console
	virtual void Update() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/