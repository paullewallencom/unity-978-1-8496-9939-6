//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IGEOMENTITYINSTANCES_H
#define __CSDK_IGEOMENTITYINSTANCES_H

#include "iSurfaceInstance.h"

namespace csdk {

class iGeomEntityTemplate;

//====================================================

//! Geometric entity instance interface.
/*! 
The geometric entity instances are created from templates (iGeomEntityTemplate) and can have
multiple instances of surfaces (one for every surface template of the entity template). Every
surface has its own transformation matrix (there is no global transformation or a hierarchy between
them). The geometric entity instance is just a group of these surface instances. Hierarchy information
can be implemented on a higher abstraction level, i.e. on a interface above from which this one
is obtained (example: a skeleton can have its own interface exposing the bones hierarchy and will 
have a geometry entity instance interface to expose the transformed surfaces for every bone).
*/
class iGeomEntityInstance: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iGeomEntityInstance"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Geometric entity instance interface"; }
	
	// [ Custom interface ]===================================

	//! Return the entity template from which this instance is created.
	virtual iGeomEntityTemplate* GetTemplate() = 0;

	//! Return the global bounding box in 8 points format (a vertex position for every corner).
	/*! This is the global bounding box, large enough to contain all the instance surfaces. 
	Individual surfaces have their own smaller bounding boxes. */
	virtual const t_float3* GetBBox() = 0;

	//! Return the surface instances that makes this entity.
	/*! \warning After modifications to the current scene parts of this array may become invalid. 
	That's why it is not recommended to store this array for later use. */
	virtual t_readonly_array<iSurfaceInstance*>* GetSurfaces() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/