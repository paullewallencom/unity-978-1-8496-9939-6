//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_FLOAT3_H
#define __CSDK_T_FLOAT3_H

namespace csdk {

//====================================================

typedef struct t_float3 {

	union
	{
		float x;
		float r;
		float hue;
		float u;
	};

	union
	{
		float y;
		float g;
		float sat;
		float v;
	};

	union
	{
		float z;
		float b;
		float val;
		float w;
	};

	t_float3 &operator = (const t_float3& vect)
	{
		x = vect.x;
		y = vect.y;
		z = vect.z;

		return *this;
	}


	t_float3 &operator = (const float value)
	{
		x = y = z = value;
		return *this;
	}


	t_float3 &operator += (const t_float3 &vect)
	{
		x += vect.x; y += vect.y; z += vect.z;

		return *this;
	}

	t_float3 &operator -= (const t_float3 &vect)
	{
		x -= vect.x; y -= vect.y; z -= vect.z;

		return *this;
	}

	t_float3 operator + (const t_float3 &vect)const
	{
		t_float3 tmp;

		tmp.x = x + vect.x;
		tmp.y = y + vect.y; 
		tmp.z = z + vect.z;

		return tmp;
	}

	t_float3 operator - (const t_float3 &vect)const
	{
		t_float3 tmp;

		tmp.x = x - vect.x;
		tmp.y = y - vect.y; 
		tmp.z = z - vect.z;

		return tmp;
	}

	t_float3 operator - ()const
	{
		t_float3 tmp;

		tmp.x = - x;
		tmp.y = - y; 
		tmp.z = - z;

		return tmp;
	}

	float operator * (const t_float3 &vect)const
	{//dot product
		return (x * vect.x + y * vect.y + z * vect.z);
	}

	float operator | (const t_float3 &vect)const
	{//dot product
		return (x * vect.x + y * vect.y + z * vect.z);
	}

	t_float3 operator ^ (const t_float3 &vect)const
	{//cross product
		t_float3 result;
		result.x = y * vect.z  -  z * vect.y;
		result.y = z * vect.x  -  x * vect.z;
		result.z = x * vect.y  -  y * vect.x;

		return result;
	}

	t_float3 operator * (const float scale)const
	{
		t_float3 result;

		result.x = x * scale;
		result.y = y * scale;
		result.z = z * scale;

		return result;
	}

	t_float3 operator / (const float scale)const
	{
		t_float3 result;

		result.x = x / scale;
		result.y = y / scale;
		result.z = z / scale;

		return result;
	}


	t_float3 &operator *= (const float scale)
	{
		x *= scale;
		y *= scale;
		z *= scale;

		return *this;
	}

	t_float3 &operator /= (const float scale)
	{
		x /= scale;
		y /= scale;
		z /= scale;

		return *this;
	}

} t_float3;

//====================================================
} // namespace csdk
#endif
/*@}*/