//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_POLY_H
#define __CSDK_T_POLY_H

#include "t_float3.h"

namespace csdk {

//====================================================

typedef struct t_poly {

	t_float3*  vert;
	unsigned char  vert_no;

} t_poly;

//====================================================
} // namespace csdk
#endif
/*@}*/