//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ITEXTURE_H
#define __CSDK_ITEXTURE_H

#include "iImage.h"
#include "iStorage.h"

namespace csdk {

//! Texture internal formats.
enum E_TEX_INT_FORMAT 
{
	C_TEX_INT_FORMAT_UNKNOWN = 0,
	C_TEX_INT_FORMAT_LUMINANCE,
	C_TEX_INT_FORMAT_ALPHA,
	C_TEX_INT_FORMAT_RGB4,
	C_TEX_INT_FORMAT_RGB8,
	C_TEX_INT_FORMAT_RGB,
	C_TEX_INT_FORMAT_RGBA4,
	C_TEX_INT_FORMAT_RGBA8,
	C_TEX_INT_FORMAT_RGBA,
	C_TEX_INT_FORMAT_DEPTH16,
	C_TEX_INT_FORMAT_DEPTH24,
	C_TEX_INT_FORMAT_DEPTH32
};

//! Texture clamping.
enum E_TEX_CLAMP
{
	C_TEX_REPEAT = 0,
	C_TEX_CLAMP,
	C_TEX_CLAMP_TO_EDGE,
	C_TEX_CLAMP_TO_BORDER
};

//! Texture filtering.
enum E_TEX_FILTERING 
{
	C_TEX_NEAREST = 0,
	C_TEX_LINEAR,
};

//====================================================

//! Node factory name to create textures (with iRootInterface::NewNode).
#define C_NODE_FACTORY_TEXTURE	"Texture"

//! Interface to a texture.
/*! 
	A texture is a 2D, 3D or cubemap sampler used to render an image.
	For now the SDK exposes only read/get functions on textures. Future versions will allow modifications.
*/
class iTexture: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTexture"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Texture"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to the image of the texture (NULL if texture is procedural) when the texture is loaded from disk.
	/*! When the image interface is no longer needed call CloseInterface. */
	virtual iImage* GetImage() = 0;

	//! Set the source image path.
	/*! 
	\param image_path This path can contain the complete absolute path, relative or just the name of the image.
	In the second case, the image is considered from the same storage as the texture. When the
	texture is created, if the image is not found, the engine searching paths are used to find it. 
	\param storage If not NULL it is used as the image location and only the image file name is taken 
	from the \c image_path (the rest of the path is ignored).
	*/
	virtual void SetSourceImage(const t_char *image_path, csdk::iStorage *storage = NULL) = 0;

	//! Set the source image to the specified image node
	virtual void SetSourceImage(iImage* image) = 0;

	//! Return the texture internal format representation.
	virtual E_TEX_INT_FORMAT	 GetInternalFormat() = 0;

	//! Return the texture clamping mode.
	virtual E_TEX_CLAMP		GetClamp() = 0;
	//! Set the texture clamping mode.
	virtual t_error			SetClamp(E_TEX_CLAMP clamp) = 0;

	//! Return the texture filtering mode.
	virtual E_TEX_FILTERING	GetFiltering() = 0;
	//! Set the texture filtering mode.
	virtual t_error			SetFiltering(E_TEX_FILTERING filtering, const t_bool mipmaping) = 0;

	//! Indicate if mipmaps are created for the texture.
	virtual bool HasMipmaps() = 0;

	//! Return the width of the texture.
	virtual int		Width() = 0;
	//! Return the height of the texture.
	virtual int		Height() = 0;

	//! Load the texture image from disk (if not already done so) and put the texture in video memory.
	virtual t_error Load() = 0;

	//! Fill an image with data from the texture.
	/*! \param img Image to fill the data into. 
	The image is not necessary the one associated with the texture when loading it from disk. If the image
	has a different format or size than the texture it is recreated to match the texture parameters. */
	virtual t_error FillImage(iImage *img) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/