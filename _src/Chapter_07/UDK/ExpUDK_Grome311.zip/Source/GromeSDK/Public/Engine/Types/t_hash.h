//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

Copyright (C) 2006 Quad Software
This software is provided 'as-is', without any express or implied warranty.  In no event 
will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __SDK_T_HASH_H
#define __SDK_T_HASH_H

#include "t_error.h"

namespace csdk {

//=========================================================

#define M_BUCKETS_NO(x) ((sizeof (x))/(sizeof ((x)[0])))

#ifndef D_HASH_REF_COUNT_TYPE
/*! \warning Hash ref count must be signed! */
#define D_HASH_REF_COUNT_TYPE	int
#endif

// [ Hashing function ]===========================================

static unsigned long g_hash_scatter[] = 
{
	2078917053, 143302914, 1027100827, 1953210302, 755253631, 2002600785,
	1405390230, 45248011, 1099951567, 433832350, 2018585307, 438263339,
	813528929, 1703199216, 618906479, 573714703, 766270699, 275680090,
	1510320440, 1583583926, 1723401032, 1965443329, 1098183682, 1636505764,
	980071615, 1011597961, 643279273, 1315461275, 157584038, 1069844923,
	471560540, 89017443, 1213147837, 1498661368, 2042227746, 1968401469,
	1353778505, 1300134328, 2013649480, 306246424, 1733966678, 1884751139,
	744509763, 400011959, 1440466707, 1363416242, 973726663, 59253759,
	1639096332, 336563455, 1642837685, 1215013716, 154523136, 593537720,
	704035832, 1134594751, 1605135681, 1347315106, 302572379, 1762719719,
	269676381, 774132919, 1851737163, 1482824219, 125310639, 1746481261,
	1303742040, 1479089144, 899131941, 1169907872, 1785335569, 485614972,
	907175364, 382361684, 885626931, 200158423, 1745777927, 1859353594,
	259412182, 1237390611, 48433401, 1902249868, 304920680, 202956538,
	348303940, 1008956512, 1337551289, 1953439621, 208787970, 1640123668,
	1568675693, 478464352, 266772940, 1272929208, 1961288571, 392083579,
	871926821, 1117546963, 1871172724, 1771058762, 139971187, 1509024645,
	109190086, 1047146551, 1891386329, 994817018, 1247304975, 1489680608,
	706686964, 1506717157, 579587572, 755120366, 1261483377, 884508252,
	958076904, 1609787317, 1893464764, 148144545, 1415743291, 2102252735,
	1788268214, 836935336, 433233439, 2055041154, 2109864544, 247038362,
	299641085, 834307717, 1364585325, 23330161, 457882831, 1504556512,
	1532354806, 567072918, 404219416, 1276257488, 1561889936, 1651524391,
	618454448, 121093252, 1010757900, 1198042020, 876213618, 124757630,
	2082550272, 1834290522, 1734544947, 1828531389, 1982435068, 1002804590,
	1783300476, 1623219634, 1839739926, 69050267, 1530777140, 1802120822,
	316088629, 1830418225, 488944891, 1680673954, 1853748387, 946827723,
	1037746818, 1238619545, 1513900641, 1441966234, 367393385, 928306929,
	946006977, 985847834, 1049400181, 1956764878, 36406206, 1925613800,
	2081522508, 2118956479, 1612420674, 1668583807, 1800004220, 1447372094,
	523904750, 1435821048, 923108080, 216161028, 1504871315, 306401572,
	2018281851, 1820959944, 2136819798, 359743094, 1354150250, 1843084537,
	1306570817, 244413420, 934220434, 672987810, 1686379655, 1301613820,
	1601294739, 484902984, 139978006, 503211273, 294184214, 176384212,
	281341425, 228223074, 147857043, 1893762099, 1896806882, 1947861263,
	1193650546, 273227984, 1236198663, 2116758626, 489389012, 593586330,
	275676551, 360187215, 267062626, 265012701, 719930310, 1621212876,
	2108097238, 2026501127, 1865626297, 894834024, 552005290, 1404522304,
	48964196, 5816381, 1889425288, 188942202, 509027654, 36125855,
	365326415, 790369079, 264348929, 513183458, 536647531, 13672163,
	313561074, 1730298077, 286900147, 1549759737, 1699573055, 776289160,
	2143346068, 1975249606, 1136476375, 262925046, 92778659, 1856406685,
	1884137923, 53392249, 1735424165, 1602280572
};

/*! Use an array to select the bucket. */
inline unsigned long gHashFunc(const char *str, size_t len)
{
	unsigned long bucket = 0;
	for(size_t i = 0; i < len; i++)
		bucket = (bucket<<1) + g_hash_scatter[(unsigned char)str[i]];
	return bucket;
}

//=========================================================

//! Hash atom to keep the key, data and the reference count.
template <class T> class cHashAtom {

public:

	cHashAtom<T> *next;
	
	D_HASH_REF_COUNT_TYPE RefCount() { return ref_count; }

	/*! \todo Make me protected. */
	D_HASH_REF_COUNT_TYPE ref_count;
	
	T value;
		
	const char* Key() { return _key; }
	char* KeyPnt() { return _key; }
	char*& KeyRef() { return _key; }
	size_t KeyLen() { return _key_len; }
	size_t& KeyLenRef() { return _key_len; }

protected:

	size_t _key_len;
	char *_key;
	
};

//=========================================================

template <class T> inline void gDelHashValue_Nop(cHashAtom<T> *atom, T *val) { }
template <class T> inline void gUpdValueFunc_Equal(T *old_val, T *new_val) { *old_val = *new_val; }

//! Hash table with custom value per hash entry.
/* B is the number of buckets in the hash (use a prime number). T is custom data type to
	be used per hash atom.
	\warning Atom keys for the strings (character arrays with zero terminator) contain
    the null terminator but the KeyLen returns the size of the string without it. */
template <int B, class T> class t_hash {

public:

	cHashAtom<T>** Buckets() { return _buckets; }

protected:
	
	cHashAtom<T>* _buckets[B];
	unsigned long _curr_bucket;
	
	cHashAtom<T>* _prior_elem;
	
public:

	//! Function used to delete the value.
	void (*del_value_func)(cHashAtom<T> *atom, T *val);
	//! Function used to update the hash element value.
	void (*upd_value_func)(T *old_val, T *new_val);
	
	t_hash() 
	{ 
		Init(); 
	}
	~t_hash() 
	{ 
		Release(); 
	}
		
	void Init()
	{
		memset(_buckets, 0, B*sizeof(cHashAtom<T>*));
		del_value_func = gDelHashValue_Nop<T>;
		upd_value_func = gUpdValueFunc_Equal<T>;
	}
	
	//! Release all hash table.
	void Release()
	{
		cHashAtom<T> *p;
		for(int i=0; i<B; i++)
		{
			for(_prior_elem = _buckets[i]; _prior_elem; _prior_elem = p)
			{
				p = _prior_elem->next;
				
				del_value_func(_prior_elem, &_prior_elem->value);
				
				free(_prior_elem->KeyPnt());
				delete(_prior_elem);
			}
			_buckets[i] = NULL;
		}
	}

	//! Returns the hash table element corresponding to an element key.
	cHashAtom<T>* Get(const char *key, size_t len)
	{
		size_t i;
		cHashAtom<T> *p;

		_curr_bucket = gHashFunc((const char*)key, len);
		
		_curr_bucket %= M_BUCKETS_NO(_buckets);
		
		_prior_elem = NULL;
		for(p = _buckets[_curr_bucket]; p; p = p->next)
		{
			if(len == p->KeyLen())
			{
				for(i = 0; i < len && p->Key()[i] == key[i]; ) i++;
	
				if(i == len) return p;
			}
			_prior_elem = p;
		}

		return NULL; // not found
	}

	/*! \param key_sz Must be null terminated string. */
	cHashAtom<T>* Get(const char *key_sz)
	{
		return Get(key_sz, strlen(key_sz));
	}

protected:

	void _AddAtomKey(cHashAtom<T> *p, const char *key, const size_t key_len, 
		const size_t copy_len, const size_t alloc_len)
	{
		p->KeyLenRef() = key_len;

		p->KeyRef() = (char*)malloc(alloc_len);

		memcpy(p->KeyPnt(), key, copy_len);
		
		// Insert in the list.
		p->next = _buckets[_curr_bucket];
		_buckets[_curr_bucket] = p;
	}

	//! Add a new element at the beginning of the bucket.
	/*! \note The comparison (declared) length of the key (\p key_len) can differ
	from the length of the data pointed by the copy_key (\p key), but must be less for
	the comparison not to crash. This is useful for null terminating strings where
	you usually don't want to add the ending zero in comparison but in the key data. */
	cHashAtom<T>* _CurrBucketAddNew(const char *key, const size_t key_len, const size_t copy_len, const size_t alloc_len, T value)
	{
		cHashAtom<T> *p = new cHashAtom<T>;

		// Fill the element.
		p->ref_count = 1;
		p->value = value;

		_AddAtomKey(p, key, key_len, copy_len, alloc_len);
		
		return p;
	}

public:

	//! Add/update an element to the hash table and returns the hash element.
	/*! \warning Call this function to speed up addings when you know for sure the bucket
	    to add and that the token is not already present in the hash. */
	cHashAtom<T>* AddToCurrBucket(const char *key, const size_t len, T value)
	{
		//! Allocate a new element.
		return _CurrBucketAddNew(key, len, len, len, value);
	}

	//! Add/update an element to the hash table and returns the hash element.
	cHashAtom<T>* Add(const char *key, const size_t len, T value)
	{
		cHashAtom<T> *p = Get(key, len);

		if(p)
		{
			p->ref_count ++;

			upd_value_func(&p->value, &value); // Update the value.

			return p;
		}

		return AddToCurrBucket(key, len, value);
	}

	//! Add a null terminating string.
	/*! \warning Call this function to speed up addings when you know for sure the bucket
	    to add and that the token is not already present in the hash. */
	cHashAtom<T>* AddSzToCurrBucket(const char *key_sz, const size_t len, T value)
	{
		//! Allocate a new element (add including the zero terminator).
		return _CurrBucketAddNew(key_sz, len, len+1, len+1, value);
	}

	//! Add a null terminating string.
	cHashAtom<T>* Add(const char *key_sz, T value)
	{
		size_t len = strlen(key_sz);

		// Searching is not including zero terminator.
		cHashAtom<T> *p = Get(key_sz, len);

		if(p)
		{
			p->ref_count ++;

			upd_value_func(&p->value, &value); // Update the value.

			return p;
		}

		return AddSzToCurrBucket(key_sz, len, value);
	}

	//! Add a token as null terminating string (adding a zero at the end) to the current bucket.
	/*! \warning Call this function to speed up addings when you know for sure the bucket
	    to add and that the token is not already present in the hash. */
	cHashAtom<T>* AddAsSzToCurrBucket(const char *key, const size_t len, T value)
	{
		//! Allocate a new element (add including the zero terminator).
		cHashAtom<T> *p = _CurrBucketAddNew(key, len, len, len+1, value);
		// Add a zero at the end.
		p->KeyPnt()[len] = '\0';
		return p;
	}

	//! Add a token as null terminating string (adding a zero at the end).
	cHashAtom<T>* AddAsSz(const char *key, const size_t len, T value)
	{
		cHashAtom<T> *p = Get(key, len);

		if(p)
		{
			p->ref_count ++;

			upd_value_func(&p->value, &value); // Update the value.

			return p;
		}

		return AddAsSzToCurrBucket(key, len, value);
	}

	//! Add/update a non string key. Calling file and line no is supplied for named allocation in debug mode.
	/*! \warning This call should be used when adding non string keys to hash. For the rest of the operations
	(like Get, Delete) the string key variants could be used (with cast to const char* for the key parameter). 
	This is necessary since (in debug mode) the memory allocation name must be a string and in this case
	will be formed with the calling file and calling file line parameters. */
	cHashAtom<T>* AddNonSzKey(const void *key, const size_t len, T value, 
		const char *call_file, const int call_line)
	{
		cHashAtom<T> *p = Get((const char*)key, len);

		if(p)
		{
			p->ref_count ++;

			upd_value_func(&p->value, &value); // Update the value.

			return p;
		}

		p = new cHashAtom<T>;

		// Fill the element.
		p->ref_count = 1;
		p->value = value;
		p->KeyLenRef() = len;

		p->KeyRef() = (char*)malloc(len);

		memcpy(p->KeyPnt(), key, len);
		
		// Insert in the list.
		p->next = _buckets[_curr_bucket];
		_buckets[_curr_bucket] = p;
		
		return p;
	}

	//! Delete a hash element (should be called only after Release(const char* key, size_t len)).
	void CurrBucketRelease(cHashAtom<T> *p)
	{
		// Delete element from the list.
		if(_prior_elem) _prior_elem->next = p->next;
		else _buckets[_curr_bucket] = p->next;

		del_value_func(p, &p->value);

		free(p->KeyPnt());
		delete(p);
	}

	//! Release a hash element based on his key.
	t_error Release(const char *key, size_t len)
	{
		cHashAtom<T> *p = Get(key, len);
		if(p) 
		{
			CurrBucketRelease(p);
			return C_GENERIC_SUCCESS;
		}
		return C_NOTFOUND_ERR;
	}

	t_error Release(const char *key_sz)
	{
		return Release(key_sz, strlen(key_sz));
	}

	//! Decrement the reference count and delete the element if count reach zero (should be called only after Del(const char* key, size_t len)).
	t_error CurrBucketDel(cHashAtom<T> *p)
	{
		p->ref_count --;
		if(p->ref_count <= 0) // not needed
		{
			CurrBucketRelease(p);
			return C_GENERIC_SUCCESS;
		}
		return C_SKIPPED_SUCCESS;
	}

	//! Delete a hash element based on his key.
	t_error Del(const char *key, size_t len)
	{
		cHashAtom<T> *p = Get(key, len);
		if(p) 
		{
			return CurrBucketDel(p);
		}
		return C_NOTFOUND_ERR;
	}

	t_error Del(const char *key_sz)
	{
		return Del(key_sz, strlen(key_sz));
	}
	
protected:

	t_error _CurrBucketRename(cHashAtom<T> *p, const char *new_key, 
		const size_t len, const size_t copy_len, const size_t alloc_len)
	{
		char *prior_key = p->KeyPnt();
		const size_t prior_key_len = p->KeyLen();

		_AddAtomKey(p, new_key, len, copy_len, alloc_len);	

		// Delete element from the prior list...

		// First, need to set the current bucket.
		cHashAtom<T> *p2 = Get(prior_key, prior_key_len);
		// Remove from the list.
		if(_prior_elem) _prior_elem->next = p2->next;
		else _buckets[_curr_bucket] = p2->next;

		free(prior_key);

		return C_GENERIC_SUCCESS;
	}

public:

	//! Rename a hash entry to another key.
	/*! An important aspect of this call (different than a Del followed by an Add) is that the 
	key is not deleted so all the pointers to it remains valid. */
	t_error Rename(cHashAtom<T> *p, const char *new_key, const size_t len)
	{
		// First verify if the new key is free.
		if(Get(new_key, len)) return C_EXISTENT_ERR;
		// Rename the key from the current bucket.
		return _CurrBucketRename(p, new_key, len, len, len);
	}

	//! Rename a hash entry to another key.
	/*! An important aspect of this call (different than a Del followed by an Add) is that the 
	key is not deleted so all the pointers to it remains valid. */
	t_error Rename(cHashAtom<T> *p, const char *new_key_sz)
	{
		const size_t len = strlen(new_key_sz);
		// First verify if the new key is free.
		if(Get(new_key_sz, len)) return C_EXISTENT_ERR;
		// Rename the string key from the current bucket.
		return _CurrBucketRename(p, new_key_sz, len, len+1, len+1);
	}

};

//=========================================================
} // namespace csdk
#endif
/*@}*/