//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007-2012 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IROOTINTERFACE_H
#define __CSDK_IROOTINTERFACE_H

#include "iStorage.h"

#define C_CORE_SDK_VERSION 31100

//! The Core SDK namespace.
namespace csdk {

//====================================================

//! Base structure in which the plug-in specific data is kept for plug-in defined nodes.
/*! 
This class will be used as base class for specific node plug-ins data and will hold
custom node data (example: geometry information for a mesh node, data components
for a storage node etc). A pointer to this data will be sent to every plug-in
functions when the system needs to operate on the node. See iNodePlugin for details.
You can also use a pointer to this structure to obtain the node interface with iRootInterface::GetInterface.
*/
class cNodeData
{
	friend class iRootInterface;

public:

	cNodeData()
	{
		_node_id = NULL;
	}

	//! Make sure the proper destructor is used by making it virtual.
	virtual ~cNodeData() {}

protected:
	
	//! System specific (internal) node id.
	/*! This is used by iRootInterface::GetInterface to uniquely identify the node in the system. */
	void* _node_id;

	// NOTE: Additional custom data will be added for specific node plug-ins by inheritance from this class.
};

//====================================================

//! Root interface from which all other interfaces can be obtained.
/*
	This SDK expose engine functionality via global interfaces obtained from the
	root interface. Root interface is send to all the plug-ins. Other global interfaces
	can be obtained with \c OpenInterface knowing their unique name. Global
	interfaces may support subinterfaces (which don't need to have unique names).
*/
class iRootInterface: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iRootInterface"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "SDK Root Interface"; }
	
	//! Returns the version string of this SDK.
	virtual uint Version() { return C_CORE_SDK_VERSION; }

	// [ Custom interface ]===================================

	// Interfaces ===========================

	//! Return the SDK interface to a global interface or to an engine node given its name and storage.
	/*! 
	This function can be used to obtain global interfaces (localized only by a name) or 
	engine nodes (resources localized by name and storage).
	\param name Name of the interface (node).
	\param name_local_storage Local storage if the interface name is local to a storage (used to obtain nodes interfaces).
	\return Interface pointer or NULL if the interface / node is unknown.
	*/
	virtual iSdkInterface* GetInterface(const char *name, class iStorage *name_local_storage = NULL) = 0;
	//! Return a global SDK interface given its unique id.
	virtual iSdkInterface* GetInterface(const t_interface_id id) = 0;

	//! Return the id of an interface type given type string.
	virtual t_type_id		GetTypeId(const char *type_sz) = 0;
	//! Return the zero terminated string of an interface type.
	virtual const char*	GetTypeSz(const t_type_id id) = 0;

	//! Return the id of an interface name given interface name (and local storage for nodes).
	/*! 
	This function can be used to obtain global interface ids (localized only by a name) or 
	engine nodes interface ids (resources localized by name and storage).
	\param name_sz Name of the interface (node).
	\param name_local_storage Local storage if the interface name is local to a storage (used to obtain nodes interface ids).
	\return Interface id or NULL if the interface / node is unknown.
	*/
	virtual t_interface_id	GetInterfaceId(const char *name_sz, class iStorage *name_local_storage = NULL) = 0;
	//! Return the zero terminated string of an interface id.
	virtual const char*	GetNameSz(const t_interface_id id) = 0;

	// Nodes ==============================

	//! Indicate if a node name is already used (node is created or not yet loaded from its storage but the storage is parsed).
	/*! To be noted that the interface for the node may not be yet created (with GetInterface) but the node
	is known by the system (by parsing its storage).
	\param node_name Name of the node.
	\param node_local_storage Storage the node name is local to it. 
	*/
	virtual t_bool IsNodeNameUsed(const char *node_name, class iStorage *node_local_storage) = 0;

	//! Create a new engine node given the factory name and return its primary interface.
	/*! 
	\param node_factory_name The name of the node factory. The factory can be build-in or added through various node plug-ins (see iNodePlugin). 
	\param node_name Name of the node. Node name must be unique inside its local storage (see next parameter). 
	\param node_local_storage Storage the node name is local to (node will not be added to the storage, only its name is local to it). 
	This can be NULL in which case the name is global (not localized to any storage). 
	\param parent_node Interface to the parent node. 
	\return Pointer to the node main interface. The interface reference count is increased.
	*/
	virtual iSdkInterface* NewNode(const char* node_factory_name, 
		const char *node_name, class iStorage *node_local_storage, iSdkInterface *parent_node) = 0;

	//! Remove an engine node from memory.
	/*! To be noted that this function may not be supported depending on the node. Some nodes may not
	allow to be released in which case C_NOTSUPPORTED_ERR is returned. 
	
	Also, this function decrement the interface reference count by one. Once node is deleted the interface 
	may still remain in memory until its reference count drops to zero. In this case the interface operation 
	have no effect since they don't have an allocated node to operate on. 
	
	With this call the node is removed from memory but not from its storage (you need to delete it from storage
	for this)! It can be later restored from the storage if it was saved there.

	\param node_interface Interface to the node to be deleted from memory.
	\return Success code in case the deletion was successful.
	*/
	virtual t_error DelNode(iSdkInterface* node_interface) = 0;

	//! Return the main interface to a created node given its data.
	/*! This function is called when you know the node data (usually from the custom storage plug-ins).
	You can also return a node interface by extracting it from its storage (see iStorage::ExtractNode). */
	virtual iSdkInterface* GetInterface(cNodeData *node_data)
	{
		return _GetNodeIdInterface(node_data->_node_id);
	}

	//! Return the storage of an engine node.
	/*! Returns NULL if the node is global or not yet added to a storage. */
	virtual iStorage* GetNodeStorage(iSdkInterface *node_interface) = 0;

	// ===================================

	//! Run a script file.
	/*!
	\param file_sz Script (operating system specific) file path.
	\param custom_entry If not NULL indicates the entry function to be run from the script.
	*/
	virtual t_error RunScript(const t_char *file_sz, struct sRunScriptEntry *custom_entry = NULL) = 0;

	// ===================================

protected:

	//! Internal function used to return the interface given a system specific node id.
	virtual iSdkInterface* _GetNodeIdInterface(void *node_id) = 0;

};

//====================================================

//! Possible types for data variables.
enum E_DATATYPE
{
	C_DATATYPE_UNKNOWN = 0, //! Unknown type, usually used in case of errors.
	C_DATATYPE_BOOL,
	C_DATATYPE_STRING, //!< Unicode string.
	C_DATATYPE_ASCIISTRING, //!< ASCII string.
	C_DATATYPE_INT,
	C_DATATYPE_UINT,
	C_DATATYPE_FLOAT,
	C_DATATYPE_FLOAT2, //!< Two floating point values.
	C_DATATYPE_FLOAT3, //!< Three floating point values (usually used to hold a vector, RGB color (with components between 0 and 255) etc).
	C_DATATYPE_FLOAT4, //!< Four floating point values (usually used to hold a vector, plane equation, RGBA color (with components between 0 and 255) etc).
	C_DATATYPE_FLOAT4x4, //!< 4x4 matrix of floats.
	C_DATATYPE_INTERFACE, //!< Hold a reference to an engine interface.
	C_DATATYPE_CHAR,
	C_DATATYPE_UCHAR,
	C_DATATYPE_SHORT,
	C_DATATYPE_USHORT,
	C_DATATYPE_DOUBLE
};

//! Structure that can be sent to iRootInterface::RunScript to setup a custom script entry function.
struct sRunScriptEntry
{
	//! Custom entry point function declaration (C style, use NULL for "void main()").
	/*\warning If this is NULL the rest of the parameters are ignored. */
	char	*entry_point_declaration; 
	//! Pointer to one parameter to be sent to the entry function. Use NULL for no parameter.
	void	*param;
	//! Type of the parameter (use C_DATATYPE_UNKNOWN for pointer to an object).
	E_DATATYPE param_type;
	//! Pointer to a properly allocated memory to receive the function return value. Use NULL if you are not interested in the return value.
	void	*ret_value; 
	//! Type of the return value.
	E_DATATYPE ret_value_type;
};

//====================================================
} // namespace csdk
#endif
/*@}*/