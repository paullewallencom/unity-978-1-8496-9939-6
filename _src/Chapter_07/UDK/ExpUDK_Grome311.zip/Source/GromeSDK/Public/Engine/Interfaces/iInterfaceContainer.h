//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2008 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IINTERFACECONTAINER_H
#define __CSDK_IINTERFACECONTAINER_H

#include "iSdkInterface.h"

namespace csdk {

//! A node containing references to multiple other interfaces.
/*! 
Think of this interface as an array of interfaces. This was introduced since, different than
a simple array of interfaces, it can create and return interfaces only at requests (when needing
an interface from a certain index). 
This interface is used by other parts of SDK when multiple interfaces to various objects are returned
and, for performance reasons, we don't want to allocate all the interface at once.
*/
class iInterfaceContainer: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iInterfaceContainer"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Interface Container"; }
	
	// ==================================================

	//! Return the number of interfaces contained in this container.
	virtual uint GetInterfacesNo() = 0;

	//! Return the pointer to an interface given its index.
	/*! When the returned image interface is no longer needed call CloseInterface. */
	virtual iSdkInterface* GetInterface(const uint index) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/