//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005-2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ISDKINTERFACE_H
#define __CSDK_ISDKINTERFACE_H

#include "../Types/types.h"

namespace csdk {

//====================================================

//! Base class for all the SDK interfaces.
class iSdkInterface
{
public:

	iSdkInterface()
	{
		_interface_id = NULL;
	}

	virtual ~iSdkInterface()
	{ }

	//! Return the unique id for this interface.
	/*! This id can be NULL for interfaces which cannot be globally identified (are local to 
	a specific context, e.g. obtaining the surface instance for a geometric entity). These local
	interfaces are automatically closed when the context is released (e.g. when the geometry
	entity interface is closed). Pointers to them should not be stored for later use. 
	Local interfaces are explicitely marked in their documentation. */
	t_interface_id InterfaceId() { return _interface_id; }

	//! Indicate that the interface is referred (increase the interface reference count).
	/*! Every interface has a reference count indicating how many times it is used.
	This reference count is increased every time a pointer to the interface is obtained
	(e.g. iEdWorkspace::GetActiveProjects is called to obtain interfaces to active projects)
	or when ReferInterface is called on the interface, and decrease at CloseInterface call. 
	When the reference count reaches zero it is indicating that no one is using the interface and 
	it can be released. Not closing interfaces will not cause memory leaks (as the system will release 
	all the interfaces at shutdown) but will leave the interfaces hanging around even though they are not used. */
	virtual void ReferInterface() {}

	//! Call this function when this interface is no longer used.
	/*! Every interface has a reference count indicating how many times it is used.
	This reference count is increased every time a pointer to the interface is obtained
	(e.g. iEdWorkspace::GetActiveProjects is called to obtain interfaces to active projects), at OpenSubinterface
	or when ReferInterface is called on the interface. The count is decreased at CloseInterface call. 
	When the reference count reaches zero it is indicating that no one is using the interface and 
	it can be released. Not closing interfaces will not cause memory leaks (as the system will release 
	all the interfaces at shutdown) but will leave the interfaces hanging around even though they are not used. */
	virtual void CloseInterface() {};

	//! Return the name for the interface.
	/*! The returned pointer may be temporary and should not be stored for later use. 
	This return the user defined name if defined, otherwise it returns the internal name. */
	virtual const char* Name() { return NULL; }

	//! Return the internal unique name for the interface.
	/*! Usually the engine nodes have internal names different than the exposed names. These names are unique 
	for the node storage and can be used (together with the storage path) to uniquely identify a node interface. */
	virtual const char* InternalUniqueName() { return NULL; }

	//! Return the long name (the description) of the interface.
	virtual const char* Description() { return "No description"; }
	
	//! Return the user defined name for this interface (this is in the current character set).
	virtual const t_char* UserDefName() { return NULL; }
	//! Set user defined name (only engine nodes may support this).
	virtual t_error SetUserDefName(const t_char *name) { return C_NOTSUPPORTED_ERR; }

	//! Return the id identifying the type of the interface.
	virtual t_type_id Type() = 0;

	//! Returns the version string of this interface.
	/*! Returned no contains 3 groups of no: major (first 1 or 2), minor (the next 2,
	even for stable, odd for in development) and details (the last 2).  Ex: 10203 means 
	version 1.02.03: 1 major, 03 minor (in development) and 3rd build for this version.
	This can be used as a protection method when modules from various engine builds  are 
	mixed together and interfaces can vary.  Paranoid code could use this no to verify if this 
	interface is referring to the version he is expecting. In general newer versions include old ones. */
	virtual uint Version() { return 10000; }

	//! Return a subinterface of the specified type (if supported).
	/*! Returned interface must be closed with CloseInterface when no longer needed. */
	virtual iSdkInterface* OpenSubinterface(t_type_id type) { return NULL; }

	//! Indicate that the interface is referring to an engine node that is no longer in memory (it was deleted or swapped).
	/*! If the interface is referring to a NULL node its functions will have no effect. */
	virtual t_bool IsNULL() { return C_FALSE; }

	//! Indicate that the engine data behind this interface was sent to swap storage and it is no longer in memory.
	/*! The system supports a special storage space called swap which can be used to temporary release and store
	scene elements. When a SDK code is running some parts of system nodes can be in this swapped state. Interfaces
	to them are still accessible but because the actual data is not in memory all the operations have no effect. 
	The SDK code can reactivate these nodes with UnswapData. Some nodes don't support swapping, they always return false. */
	virtual t_bool IsSwapped() { return C_FALSE; }

	/*! The system supports a special storage space called swap which can be used to temporary release and store
	scene elements. When a SDK code is running some parts of system nodes can be in this swapped state. Interfaces
	to them are still accessible but because the actual data is not in memory all the operations have no effect. 
	The SDK code can reactivate these nodes with UnswapData. 
	Some nodes don't support swapping, they always not supported error code. 
	\warning To be noted that for some nodes (like terrain zones) unswapping does automatically select them. */
	virtual t_error UnswapData() { return C_NOTSUPPORTED_ERR; }

	/*! The system supports a special storage space called swap which can be used to temporary release and store
	scene elements. When a SDK code is running some parts of system nodes can be in this swapped state. Interfaces
	to them are still accessible but because the actual data is not in memory all the operations have no effect. 
	The SDK code can send unswapped nodes to the swap state with SwapData. */
	virtual t_error SwapData() { return C_NOTSUPPORTED_ERR; }

protected:

	//! The interface registration unique id (internal usage).
	t_interface_id _interface_id;

};

//! Helper macro used to close an array of interfaces.
#define gCloseInterfaces(interfaces)	\
{	\
	for(uint i=0, no=(interfaces)->No(); i<no; i++)	\
	{	\
		(interfaces)->Elem(i)->CloseInterface();	\
	}	\
}

//====================================================
} // namespace csdk
#endif
/*@}*/