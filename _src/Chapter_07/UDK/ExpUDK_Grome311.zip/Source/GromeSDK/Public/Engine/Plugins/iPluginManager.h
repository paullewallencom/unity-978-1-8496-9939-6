//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2011 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IPLUGINMAN_H
#define __CSDK_IPLUGINMAN_H

#include "../Interfaces/iRootInterface.h"

namespace csdk {

//====================================================

//! Name used to register the iPluginManager interface with the SDK root.
/*! Use iRootInterface::GetInterface(C_PLUGINMANAGER_INTERFACE_NAME	) to open the global plug-in manager interface. */
#define C_PLUGINMANAGER_INTERFACE_NAME		"PluginManager"

//! Plug-in manager which offers info about the currently registered plug-ins.
class iPluginManager: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iPluginManager"; }

	virtual const char* Name() { return C_PLUGINMANAGER_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Plug-in Manager"; }
	
	// ================================================
	// Known types of plug-ins (export, import, utility, trigger etc).

	//! Return the no of known (parsed) plug-in types.
	virtual uint	GetPluginTypesNo() = 0;
	//! Return the index id for a certain plug-in type given its index.
	/*! Returns UINT_MAX if the type is not known. */
	virtual uint GetPluginTypeId(const char *type_name) = 0;
	//! Return the name identifying a certain type of plug-ins.
	virtual const char* GetPluginTypeName(const uint idx) = 0;
	//! Return a description of a certain type of plug-ins.
	virtual const char* GetPluginTypeDescription(const uint idx) = 0;

	// ================================================
	// Registered plug-ins organized per type.

	//! Return the total number of registered plug-ins for a certain type (index returned with a call to GetPluginTypeId).
	virtual uint	GetPluginsNo(uint plugin_type_id) = 0;
	//! Return the plugin file name.
	/*! To be noted that the plug-in doesn't need to be loaded in order to get its name. */
	virtual const t_char* GetPluginFileName(uint plugin_type_id, uint plugin_id) = 0;
	//! Return the plugin path name.
	/*! To be noted that the plug-in doesn't need to be loaded in order to get its name. */
	virtual const t_char* GetPluginPathName(uint plugin_type_id, uint plugin_id) = 0;
	//! Return the index of the plugin given its file name.
	virtual uint GetPluginId(uint plugin_type_id, const t_char* file_name) = 0;
	//! Return the SDK interface for the plug-in.
	/*! Plug-in module (file) is loaded in order to get its interface. When no longer needed you should call ClosePluginInterface so the system,
	after closing the interface, will also unload the plug-in module if no longer needed by other system components. */
	virtual iPlugin* OpenPluginInterface(uint plugin_type_id, uint plugin_id) = 0;
	//! Close a plug-in interface opened with OpenPluginInterface and unload the plug-in module if no longer used by anybody else.
	virtual void ClosePluginInterface(uint plugin_type_id, uint plugin_id) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/