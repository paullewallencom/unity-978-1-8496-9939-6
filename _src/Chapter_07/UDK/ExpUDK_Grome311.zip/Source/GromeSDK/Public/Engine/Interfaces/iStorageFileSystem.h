//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ISTORAGEFILESYSTEM_H
#define __CSDK_ISTORAGEFILESYSTEM_H

#include "iSdkInterface.h"
#include "iIOStream.h"

namespace csdk {

#define C_STORAGE_FILESYSTEM_NAME	"StorageFileSystem"

//! Interface to the storage file system.
/*! 
This interface provides access to the files and directory structure within the path specified by the storage.
*/
class iStorageFileSystem: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iStorageFileSystem"; }

	virtual const char* Name() { return C_STORAGE_FILESYSTEM_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Storage File System"; }
	
	// ==================================================

	//! Create a folder inside the storage path
	virtual t_error MakeDir(const t_char* name) = 0;

	//! Open a file with the given mode and return a stream interface for read/write operations
	virtual iIOStream* OpenFile(const t_char* name, const t_char* mode) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/