//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005-2011 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_STORAGE_H
#define __CSDK_STORAGE_H

#include "iSdkInterface.h"

namespace csdk {

//====================================================

struct sStorageNodeInfo
{
	//! Internal name of the name as used by the engine.
	/*! This can be different than the name returned by iSdkInterface::Name() which is 
	the user defined name. Internal name (used for localization) must be unique inside the 
	storage while the user defined name can be duplicated among multiple nodes. */
	const char* node_name;

	//! Name of the factory for this node.
	/*! This indicate the actual internal implementation of the node (example: NativeGeomTemplate, 
	MyCustomMesh etc.). */
	const char* node_factory;

	//! String for the main interface type the node exposes (example: iImage::TypeString, iMaterial::TypeString).
	const char* node_interface_type;
};

//====================================================

//! Commit flags for the storage
#define F_STORAGE_COMMIT_DEFAULT			0
#define F_STORAGE_COMMIT_IN_MEMORY		(1<<0)


//! Interface to a storage.
/*! 
A storage is a package that holds various other nodes and resides in external discs. It can
be seen as a folder containing multiple files (every file corresponding to a node) and other subfolders.
The storage can be made of a simple folder or it can be in packed form where it can be a single file
containing internal directory structure (example: a zip archive).

All the data loaded by the engine is organized as nodes in storages. Thus all the disk content
(its folders and custom packages) is seen as an hierarchy of storages.

It can be queried to return its components, new nodes can be added or removed. Usually
engine nodes are saved and later restored from storages. That is why nodes are identified
by their name and their storage (see iNodePlugin::NewNode parameters).

It is not a necesity to load an entire storages to have access to its content. Storages can
be only parsed and information about their content (its nodes and substorages) becomes
available (see GetNodeInfo). Nodes can be individually extracted with ExtractNode once
the storage is parsed.

You can defined plug-ins of this type to add your own custom packages to the engine
(example: define a storage plug-in to load COLLADA files. This plug-in will parse its
content from a file and expose all the nodes (materials, images, geometrical meshes)
from it). See iStoragePlugin.

NOTE: for now the storage have only read functions (doesn't have save to disc and add new nodes capability).
These will be included in future SDK versions.
*/
class iStorage: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iStorage"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Storage"; }
	
	// [ Custom interface ]===================================

	//! Return the parent storage or NULL if this is the engine storage root.
	virtual iStorage* GetParentStorage() = 0;

	//! Return the path for the current device (example: "my_storage.bin").
	virtual const t_char *GetDeviceName() = 0;

	//! Return the complete path for the device (example: "c:/temp/my_storage.bin").
	virtual const t_char *GetDevicePath() = 0;

	//! Check if the storage is parsed.
	/*! This function will return false if the storage was parsed but later modified. 
	\param parse_level Indicate how much parsing must be done for this function to return true. 
	Use -1 for complete parsing, 0 only for this level of substorages etc. */
	virtual t_bool IsParsed(const int parse_level = 0) = 0;

	//! Parse the device and announce the components to the system.
	virtual t_error Parse(const int parse_level = 0) = 0;

	//! Return the total no of direct sub (or child) storages.
	virtual uint GetSubstoragesNo() = 0;
	//! Return a direct substorage given its index.
	virtual iStorage* GetSubstorage(const uint index) = 0;
	//! Return a direct substorage given its name.
	virtual iStorage* GetSubstorage(const char *storage_name) = 0;

	//! Return the no of nodes in the storage.
	virtual uint GetNodesNo() = 0;

	//! Given a node name return the index if the node is present inside this storage.
	/*! \return The index of the node or UINT_MAX if no node with that name exists in the storage. */
	virtual uint GetNodeIndex(const char *name) = 0;
	
	//! Return information about a node in the storage.
	/*! These information must be available even though the node is not loaded from storage. */
	virtual t_error GetNodeInfo(const uint index, sStorageNodeInfo *o_info) = 0; 

	//! Return the name of the file for a node (this is the name of the storage for packed storages).
	virtual const csdk::t_char* GetNodeFileName(const uint index) = 0;

	//! Return the interface to a storage node given its index.
	/*! The node is loaded from storage if necessary. */
	virtual iSdkInterface* ExtractNode(const uint index) = 0;

	//! Return the interface to a storage node given its name.
	/*! The node is loaded from storage if necessary. */
	virtual iSdkInterface* ExtractNode(const char *name) = 0;

	//! Add a node content to the storage.
	/*! 
	This function adds the content of the node to the storage. After this call
	the node can be deleted and its data remains in the storage. This call doesn't
	commit the storage data to the disk (for this you must call Commit). Thus all
	the added nodes are merely added to a commit queue. Until you call Commit
	no data is written to the disk and the added nodes are not yet part of the storage
	(they are not returned by GetNodeIndex etc). After Commit the nodes become
	part of the storage. 
	*/
	virtual t_error AddNode(iSdkInterface *node_interface) = 0;

	//! Writes the added nodes data to the external storage.
	/* 
	Added nodes can be safely deleted after they are added and before the Commit is performed. 
	\param commit_level indicate how deep (i.e. how many levels of substorages) the commit is to be performed, . 
	Use -1 for complete commit, 0 to commit only this storage, 1 for commit of immediate substorages etc. 
	\param storage_buffer For packed formats this is the parent buffer used by substorages to themselfs.
	\param commit_flags See F_STOR_COMMIT_* flags for possible values. 
	*/
	virtual t_error Commit(const int commit_level = 0, const uint32 commit_flags = F_STORAGE_COMMIT_DEFAULT) = 0;

	//! Remove a node from the storage (node is not deleted from memory).
	virtual t_error RemoveNode(iSdkInterface *node_interface) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/