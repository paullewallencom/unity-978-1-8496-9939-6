//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file t_string.h
	\brief Depending on the character set, can be ASCII, Unicode etc.

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_STRING_H
#define __CSDK_T_STRING_H

#include <string>
#include "t_char.h"

namespace csdk {

//====================================================

class t_string : public std::basic_string<t_char, std::char_traits<t_char>, std::allocator<t_char> >
{
public:

	t_string()
	{
	}

	t_string(const t_char *sz)
	{
		if(sz) assign(sz);
	}

	t_string(const t_string &str)
	{
		assign(str.Sz());
	}

	t_string(const t_string *str)
	{
		if(str) assign(str->Sz());
	}

#	ifdef D_UNICODE

	t_string(const char* val)
	{
		if(val)
		{
			size_t len = strlen(val);
			t_char *ret_sz = (t_char*)malloc((len+1)*sizeof(t_char));
			gStrCharSetFillAndZero(val, len, ret_sz);
			assign(ret_sz);
			free(ret_sz);
		}
	}

#	endif

	const t_char* Sz() const
	{
		return c_str();
	}

	size_t Length() const
	{
		return length();
	}

	t_string& operator = (const t_string& val)
	{
		assign(val.Sz());
		return (*this);
	}

	t_string& operator = (const t_char* val)
	{
		if(val) assign(val);
		return (*this);
	}

#	ifdef D_UNICODE

	//! Conversion from ASCII to WIDE is seen as an assignment operator.
	t_string& operator = (const char* val)
	{
		if(val)
		{
			size_t len = strlen(val);
			t_char *ret_sz = (t_char*)malloc((len+1)*sizeof(t_char));
			gStrCharSetFillAndZero(val, len, ret_sz);
			assign(ret_sz);
			free(ret_sz);
		}
		return (*this);
	}

#	endif

	t_string& operator += (const t_char* sz)
	{
		if(sz)
		{
			append(sz);
		}
		return (*this);
	}

	t_string& operator += (const t_string& str)
	{
		append(str.Sz());
		return (*this);
	}

#	ifdef D_UNICODE

	t_string& operator += (const char* sz)
	{
		if(sz)
		{
			size_t len = strlen(sz);
			t_char *ret_sz = (t_char*)malloc((len+1)*sizeof(t_char));
			gStrCharSetFillAndZero(sz, len, ret_sz);
			append(ret_sz);
			free(ret_sz);
		}
		return (*this);
	}

#	endif

	t_string operator + (const t_char* sz) const
	{
		t_string res(this);
		if(sz) res.append(sz);
		return res;
	}

#	ifdef D_UNICODE

	t_string operator + (const char* sz) const
	{
		t_string res(this);
		if(sz) 
		{
			size_t len = strlen(sz);
			t_char *wide_sz = (t_char*)malloc((len+1)*sizeof(t_char));
			gStrCharSetFillAndZero(sz, len, wide_sz);
			res.append(wide_sz);
			free(wide_sz);
		}
		return res;
	}

#	endif

	operator t_char*()
	{
		return (t_char*)Sz();
	}

	//! Make string lower case.
	void Lwr()
	{
		gStrLwr((t_char*)Sz());
	}

	//! Make string upper case.
	void Upr()
	{
		gStrUpr((t_char*)Sz());
	}

	void AssignToken(const t_char* str, const size_t len)
	{
		if(str)
		{
			assign(str, len);
		}
	}

	void AppendToken(const t_char* str, const size_t len)
	{
		if(str)
		{
			append(str, len);
		}
	}

	void AssignAsciiToken(const char* str, const size_t len)
	{
		if(str)
		{
			t_char *sz = (t_char*)malloc((len+1)*sizeof(t_char));
			gStrCharSetFillAndZero(str, len, sz);
			assign(sz);
			free(sz);
		}
	}

	void AppendAsciiToken(const char* str, const size_t len)
	{
		if(str)
		{
			t_char *sz = (t_char*)malloc((len+1)*sizeof(t_char));
			gStrCharSetFillAndZero(str, len, sz);
			append(sz);
			free(sz);
		}
	}

};

//====================================================

class t_ascii_string : public std::basic_string<char, std::char_traits<char>, std::allocator<char> >
{
public:

	t_ascii_string()
	{
	}

	t_ascii_string(const char *sz)
	{
		if(sz) assign(sz);
	}

	t_ascii_string(const t_ascii_string &str)
	{
		assign(str.Sz());
	}

	t_ascii_string(const t_ascii_string *str)
	{
		if(str) assign(str->Sz());
	}

#	ifdef D_UNICODE

	t_ascii_string(const t_char *sz)
	{
		if(sz)
		{
			size_t len = gStrLen(sz);
			char *ascii_sz = (char*)malloc((len+1)*sizeof(char));
			gStrAsciiFillAndZero(sz, len, ascii_sz);
			assign(ascii_sz);
			free(ascii_sz);
		}
	}

#	endif

	const char* Sz() const
	{
		return c_str();
	}

	size_t Length() const
	{
		return length();
	}

	t_ascii_string& operator = (const t_ascii_string &str)
	{
		assign(str.Sz());
		return (*this);
	}

	t_ascii_string& operator = (const char* val)
	{
		if(val) assign(val);
		return (*this);
	}

#	ifdef D_UNICODE

	//! Conversion from UNICODE to ASCII is seen as an assignment operator.
	t_ascii_string& operator = (const t_char* val)
	{
		if(val)
		{
			size_t len = gStrLen(val);
			char *ret_sz = (char*)malloc((len+1)*sizeof(char));
			gStrAsciiFillAndZero(val, len, ret_sz);
			assign(ret_sz);
			free(ret_sz);
		}
		return (*this);
	}

#	endif

	t_ascii_string& operator += (const char* sz)
	{
		if(sz)
		{
			append(sz);
		}
		return (*this);
	}

	t_ascii_string& operator += (const t_ascii_string& str)
	{
		append(str.Sz());
		return (*this);
	}

#	ifdef D_UNICODE

	t_ascii_string& operator += (const t_char* sz)
	{
		if(sz)
		{
			size_t len = gStrLen(sz);
			char *ret_sz = (char*)malloc((len+1)*sizeof(char));
			gStrAsciiFillAndZero(sz, len, ret_sz);
			append(ret_sz);
			free(ret_sz);
		}
		return (*this);
	}

#	endif

	t_ascii_string operator + (const char* sz) const
	{
		t_ascii_string res(this);
		if(sz) res.append(sz);
		return res;
	}

#	ifdef D_UNICODE

	t_ascii_string operator + (const t_char* sz) const
	{
		t_ascii_string res(this);
		if(sz) 
		{
			size_t len = gStrLen(sz);
			char *ascii_sz = (char*)malloc((len+1)*sizeof(char));
			gStrAsciiFillAndZero(sz, len, ascii_sz);
			res.append(ascii_sz);
			free(ascii_sz);
		}
		return res;
	}

#	endif

	operator char*()
	{
		return (char*)Sz();
	}

	//! Make string lower case.
	void Lwr()
	{
		_strlwr((char*)Sz());
	}

	//! Make string upper case.
	void Upr()
	{
		_strupr((char*)Sz());
	}

	void AssignToken(const char* str, const size_t len)
	{
		if(str)
		{
			assign(str, len);
		}
	}

	void AppendToken(const char* str, const size_t len)
	{
		if(str)
		{
			append(str, len);
		}
	}

	void AssignChSetToken(const t_char* str, const size_t len)
	{
		if(str)
		{
			char *sz = (char*)malloc((len+1)*sizeof(char));
			gStrAsciiFillAndZero(str, len, sz);
			assign(sz);
			free(sz);
		}
	}

	void AppendChSetToken(const t_char* str, const size_t len)
	{
		if(str)
		{
			char *sz = (char*)malloc((len+1)*sizeof(char));
			gStrAsciiFillAndZero(str, len, sz);
			append(sz);
			free(sz);
		}
	}

};

//====================================================
} // namespace csdk
#endif
/*@}*/