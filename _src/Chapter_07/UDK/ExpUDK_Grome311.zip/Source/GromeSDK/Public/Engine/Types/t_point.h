//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_POINT_H
#define __CSDK_T_POINT_H

namespace csdk {

//====================================================

//! 2D integer coordinates point.
typedef struct t_point {

	union
	{
		int x;
		int u;
	};

	union
	{
		int y;
		int v;
	};

} t_point;

//====================================================
} // namespace csdk
#endif
/*@}*/