//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file types.h
	\brief Basic types, type related defines and other common files.

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_TYPES_H
#define __CSDK_TYPES_H

#include <stdlib.h>

namespace csdk {

//===========================================================

//! ASCII unsingned char.
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned int uint;

#ifdef _WINDOWS	// [WINDOWS SPECIFIC]

	typedef __int8 int8;
	typedef __int16 int16;
	typedef __int32 int32;
	typedef __int64 int64;
	typedef unsigned __int8 uint8;
	typedef unsigned __int16 uint16;
	typedef unsigned __int32 uint32;
	typedef unsigned __int64 uint64;
	
	typedef float float32;
	typedef double float64;

	//! Operating system (16, 32 or 64 bit) integer.
	/*! This can be used when sending an int or a pointer (since the for example
	    pointer can be bigger for 64bit operating systems). */
#ifdef _WIN64 // First check win64 since both are defined for 64bit
	typedef __int64 t_machine_int;
	typedef unsigned __int64 t_machine_uint;
	typedef __int64 t_bool;
#else
#ifdef _WIN32
	typedef __int32 t_machine_int;
	typedef unsigned __int32 t_machine_uint;
	typedef __int32 t_bool;
#endif
#endif

#	define C_TRUE		1
#	define C_FALSE	0

#	define D_EXPORT		__declspec(dllexport)
#	define D_INPORT		__declspec(dllimport)

#endif // _WINDOWS

//! Variable parameter (can be a pointer or a machine int).
typedef t_machine_int t_param;

//! Control ID type.
typedef t_machine_int t_ctrl_id;

}; // namespace csdk

//===========================================================

#include "t_error.h"
#include "t_point.h"
#include "t_rect.h"
#include "t_float2.h"
#include "t_float3.h"
#include "t_float4.h"
#include "t_float3x3.h"
#include "t_float4x4.h"
#include "t_char.h"
#include "t_string.h"
#include "t_uchar3.h"
#include "t_uchar4.h"
#include "t_quat.h"
#include "t_vert_list.h"
#include "t_bbox.h"
#include "t_atom.h"
#include "t_type_id.h"
#include "t_interface_id.h"
#include "t_readonly_array.h"
#include "t_array.h"
#include "t_dyn_array.h"
#include "t_handle.h"
#include "t_hash.h"

//===========================================================
#endif
/*@}*/