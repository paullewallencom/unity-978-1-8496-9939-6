//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IPROPERTYTABLE_H
#define __CSDK_IPROPERTYTABLE_H

#include "iStorage.h"

namespace csdk {
	
//====================================================

//! Possible types for properties in a property table.
enum E_PROP_TYPE
{
	C_PROP_UNKNOWN = 0, //! Unknown type, usually used in case of errors.
	C_PROP_BOOL,
	C_PROP_STRING,
	C_PROP_INT,
	C_PROP_UINT,
	C_PROP_FLOAT,
	C_PROP_FLOAT2, //!< Two floating point values.
	C_PROP_FLOAT3, //!< Three floating point values (usually used to hold a vector, RGB color (with components between 0 and 255) etc).
	C_PROP_FLOAT4, //!< Four floating point values (usually used to hold a vector, plane equation, RGBA color (with components between 0 and 255) etc).
	C_PROP_RESOURCE, //!< Hold a reference to another engine entity (texture, material, geometry etc).
	C_PROP_CHAR,
	C_PROP_UCHAR,
	C_PROP_SHORT,
	C_PROP_USHORT,
	C_PROP_DOUBLE,
	C_PROP_ARRAY //!< Hold an array of elements with the same elementary type (bool, string, int, uint, float etc). Used with combo controls.
};

//! Possible UI controls to be used to modify properties from a property table.
/*! \warning Make sure you match the control type with the property data type, otherwise
the user will not be able to introduce values. */
enum E_PROP_CONTROL
{
	C_PROP_EDITBOX = 1, //!< Can be used for all property types.
	C_PROP_COMBOBOX, //!< Can be used for bool and array types.
	C_PROP_CHECKBOX, //!< Can be used for bool types.
	C_PROP_SPINNER, //!< Can be used for single numerical (int, uint, float) types.
	C_PROP_COLORPICKER, //!< Can be used for 3 and 4 floats types.
	C_PROP_RESOURCE_BROWSE, //!< Can be used for resource property type to browse any type of resource.
	C_PROP_IMAGE_BROWSE, //!< Can be used for resource property type to browse images.
	C_PROP_GEOMETRY_BROWSE, //!< Can be used for resource property type to browse geometrical entities.
	C_PROP_MATERIAL_BROWSE //!< Can be used for resource property type to browse materials.
};

#define F_PROP_HIDDEN			(1<<0) //!< Property is not shown to the user in the UI.
#define F_PROP_READONLY		(1<<1) //!< Property value cannot be changed by user (iPropertyTable::SetPropValue can be used, this is merely an indication).
#define F_PROP_NON_PERSISTENT	(1<<2) //!< Property is not saved / restored from storage.
#define F_PROP_UNREMOVABLE		(1<<3) //!< Property value is current blocked and cannot be removed.

//! Information about a property in a property table.
struct sPropertyStructure
{
	//! See F_PROP_* for possible values.
	uint32 flags;

	//! Name of the property (must be unique inside its category!).
	t_char *name;

	//! User readable description of the property.
	t_char *description;

	//! Type of the property.
	E_PROP_TYPE type;

	//! UI control type used to modify the property (can be 0 for default control based on the value type).
	E_PROP_CONTROL ctrl_type;
};

//====================================================

//! Data hold for a property of array type.
struct sArrayPropertyData
{
	uint elems_no; //!< No of elements in the array.

	int current_sel; //!< Element considered selected in the array (-1 for no selection).

	E_PROP_TYPE elem_type; //!< Data type of an element.

	 //! Pointer to the array elements.
	/*! Array of boolean, char, uint, int, float, float2, float3 or float4 values. For string elements it contains an array of t_char*. */
	void *elems;
};

//====================================================

#define F_PROPTABLE_INTERNAL						(1<<0) //!< Property table is internal and should not be shown to the user in the UI.
#define F_PROPTABLE_READONLY					(1<<1) //!< Property table structure and values cannot be modified inside the UI.
#define F_PROPTABLE_NON_PERSISTENT		(1<<2) //!< Property table is not saved / restored from storage.
#define F_PROPTABLE_UNREMOVABLE			(1<<3) //!< Property table cannot be removed from the entity it is assigned.

//====================================================

//! Node factory name to create property tables (with iRootInterface::NewNode).
#define C_NODE_FACTORY_PROPERTY_TABLE	"Property Table"

//! Property table interface.
/*! Property tables are a way to add custom properties per engine entities (resources). Not all entities
support property tables attached to them. The ones that support this feature contain iPropertyTableOwner
interface (returned with a call to iSdkInterface::OpenSubinterface).

Inside a table, properties are organized in categories and have type, value, UI control types and validation data.
A table is formed by two parts: its structure and its properties values. The table structure contains a description of
the categories and their properties (their type, UI controls etc). The values represents the data contained in the 
properties.

The user can give a table structure a name as an indicative of what the structure represents (example: "Light source", 
"Physique properties" etc). The user can compare two tables structure (to see if they have the same structure) by the 
structure name or by the actual properties descriptions (which can be a little expensive but it is safer) (see
iPropertyTable::HasSameStructure function).

To assign properties for an engine entity, the user first creates a property table (or use an existent one, created in
memory or loaded from storage), obtain the entity iPropertyTableOwner interface, and use iPropertyTableOwner::AssignProperties 
function to assign the properties from that table to the entity. Internally the table is duplicated and its clone is assigned to
the entity. The structure cannot be changed for these cloned property tables existent on engine entities. To change the structure
of a table from an entity, the user must delete the old property table from the entity and assign a new one with the new structure.
*/
class iPropertyTable: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iPropertyTable"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Property table interface"; }
	
	// [ Custom interface ]===================================

	//! Return the owner of the property table (the resource that has this table attached to it).
	/*! NULL is returned if no entity has this table assigned to it.
	When the owner interface is no longer needed call CloseInterface. */
	virtual iSdkInterface* GetOwner() = 0;

	//! See F_PROPTABLE_* for possible values.
	virtual const uint32 GetFlags() = 0;

	//! Set some property table flags.
	virtual t_error AddFlags(const uint32 flags) = 0;

	//! Remove some property table flags.
	virtual t_error DelFlags(const uint32 flags) = 0;

	//! Duplicate the property table.
	/*! The newly created table inherits this table structure. 
	\param name Name of the new table.
	\param local_name_storage Name is allocated locally in this storage. If NULL node is global. Name should
	be unique inside the local name storage.
	\param copy_values If true values are allocated and duplicated in the new table. If false the
	new table doesn't have any values allocated and set. */
	virtual iPropertyTable* Clone(const char *name, iStorage *local_name_storage, const t_bool copy_values) = 0;

	// ===========================================
	// Structure functions.

	//! Indicate if a property table has the same structure as this one.
	/*!
	\param table Table to compare the structure with.
	\param compare_by_properties If true the comparison is done property by property (in the existent order) otherwise
	the comparison is faster since only the structure name is used.
	*/
	virtual t_bool HasSameStructure(iPropertyTable *table, const t_bool compare_by_properties = C_FALSE) = 0;

	//! Set the name of the structure.
	/*! This can be used as an indicative as what the structure is referring to (example: "LightProps", "SoundSource" etc.). */
	virtual t_error SetStructureName(const t_char *structure_name) = 0;

	//! Return the name of the structure.
	/*! This can be used as an indicative as what the structure is referring to 
	(example: "LightProps", "SoundSource" etc.). */
	virtual const t_char* GetStructureName() = 0;

	// ===========================================

	//! Get the number of categories in this property table.
	virtual uint GetCategsNo() = 0;

	//! Return the index of a category given its name or UINT_MAX if no category with that name not found.
	virtual uint GetCategIndex(const t_char *categ_name) = 0;

	//! Add a new category into the table.
	/*! \warning This function is not supported (C_ERR_NOTSUPPORTED is returned) if the property
	table is an attached table on an entity. 
	\warning Category names must be unique inside a property table. */
	virtual t_error AddCateg(const t_char *categ_name) = 0;

	//! Delete a category from the table given its index.
	/*! \warning This function is not supported (C_ERR_NOTSUPPORTED is returned) if the property
	table is an attached table on an entity. */
	virtual t_error DelCateg(const uint categ_index) = 0;

	//! Return the name of a category given its index.
	virtual const t_char* GetCategName(const uint index) = 0;

	//! Changes the name of a category.
	/*! \warning This function is not supported (C_ERR_NOTSUPPORTED is returned) if the property
	table is an attached table on an entity. 
	\warning Category names must be unique inside a property table. */
	virtual t_error SetCategName(const uint categ_index, const t_char *new_name) = 0;

	// ===========================================

	//! Add a property (into a category given by categ_index and not sPropertyInfo::category) to a certain index (use UINT_MAX to append at the end).
	/*! \warning This function is not supported (C_ERR_NOTSUPPORTED is returned) if the property
	table is an attached table on an entity. */
	virtual t_error AddProp(const sPropertyStructure *structure, const uint categ_index, const uint prop_index = UINT_MAX) = 0;

	//! Delete a property from a category.
	/*! \warning This function is not supported (C_ERR_NOTSUPPORTED is returned) if the property
	table is an attached table on an entity. */
	virtual t_error DelProp(const uint categ_index, const uint index) = 0;

	// ===========================================

	//! Return the number of properties in a category.
	virtual uint GetPropNo(const uint categ_index) = 0;

	//! Return the index of a property given its name or UINT_MAX if no property with that name is found.
	virtual uint GetPropIndex(const uint categ_index, const t_char *prop_name) = 0;

	//! Return information about a property (in o_struct).
	virtual t_error GetPropStructure(const uint categ_index, const uint prop_index, csdk::sPropertyStructure &o_struct) = 0;

	//! Return information about a property (in o_struct) given category and its name.
	virtual t_error GetPropStructure(const t_char *categ_name, const t_char *prop_name, csdk::sPropertyStructure &o_struct) = 0;

	// ===========================================

	//! Get the value of a property.
	/*!
	\param categ_index Index of the category containing the property.
	\param index Index of the property inside the category.
	\param o_value Pointer to data to be filled with the value. The pointed data must be preallocated and its size depends 
	on the property type (see sPropertyStructure::type for possible types). o_value is as follows:
	C_PROP_BOOL: o_value is the address of the t_bool to recieve the value.
	C_PROP_CHAR: address of the char (8 bit) to be filled with the value.
	C_PROP_UCHAR: address of the unsigned char (8 bit) to be filled with the value.
	C_PROP_STRING: address of the UNICODE string pointer (t_char**) to be filled with the pointer of the 
	property string. Example: t_char* str; GetPropValue(categ_index, index, &str); str now points to the 
	internal allocate string. Do not modify the returned string directly, use SetPropValue instead.
	C_PROP_SHORT: address of the short (16 bit) to be filled with the value.
	C_PROP_USHORT: address of the unsigned short (16 bit) to be filled with the value.
	C_PROP_INT: address of the int (32 bit) to be filled with the value.
	C_PROP_UINT: address of the unsigned int (32 bit) to be filled with the value.
	C_PROP_FLOAT: address of the float to be filled with the value.
	C_PROP_FLOAT2: address of the t_float2 to be filled with the value.
	C_PROP_FLOAT3: address of the t_float3 to be filled with the value.
	C_PROP_FLOAT4: address of the t_float4 to be filled with the value.
	C_PROP_DOUBLE: address of the double (64 bit) to be filled with the value.
	C_PROP_RESOURCE: address of a pointer to a iSdkInterface to be filled with the resource interface pointer. When the 
	interface is no longer need it should be closed with iSdkInterface::CloseInterface.
	C_PROP_ARRAY: address of a sArrayPropertyData structure to receive the array data.
	*/
	virtual t_error GetPropValue(const uint categ_index, const uint index, void* o_value) = 0;

	//! Set the value of a property.
	/*! \warning Make sure you use a valid allocated data for i_value according with the property
	data type otherwise the program may crash.
	\param categ_index Index of the category containing the property.
	\param index Index of the property inside the category.
	\param i_value Pointer to the value. The value data format depends on the property type:
	C_PROP_BOOL: i_value is the address of the t_bool to be set on the property.
	C_PROP_CHAR: address of the char (8 bit) to be set on the property.
	C_PROP_UCHAR: address of the unsigned char (8 bit) to be set on the property.
	C_PROP_STRING: pointer to the UNICODE string (t_char*) to be set on the property.
	C_PROP_SHORT: address of the short (16 bit) to be set on the property.
	C_PROP_USHORT: address of the unsigned short (16 bit) to be set on the property.
	C_PROP_INT: address of the int (32 bit) to be set on the property.
	C_PROP_UINT: address of the unsigned int (32 bit) to be set on the property.
	C_PROP_FLOAT: address of the float (32 bit floating point number) to be set on the property.
	C_PROP_FLOAT2: address of the t_float2 to be set on the property.
	C_PROP_FLOAT3: address of the t_float3 to be set on the property.
	C_PROP_FLOAT4: address of the t_float4 to be set on the property.
	C_PROP_DOUBLE: address of the double (64 bit floating point number) to be set on the property.
	C_PROP_RESOURCE: pointer to a iSdkInterface to be set on the property.
	C_PROP_ARRAY: address of a sArrayPropertyData structure filled with the array data. 
	After setting the property value the structure may be deallocated. The engine keeps an internal copy of the data.
	*/
	virtual t_error SetPropValue(const uint categ_index, const uint index, const void* i_value) = 0;

	//! Copy the values from this table to a new one.
	/*! If the structure of the property table differ only common variable (with the same name and
	type no matter what category) are copied. */
	virtual t_error CopyValues(iPropertyTable *destination_table) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/