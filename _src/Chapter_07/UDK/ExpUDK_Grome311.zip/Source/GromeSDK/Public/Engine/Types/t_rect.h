//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_RECT_H
#define __CSDK_T_RECT_H

namespace csdk {

//====================================================

typedef struct t_rect {

	union
	{
		int xmin;
		int umin;
	};

	union
	{
		int ymin;
		int vmin;
	};

	union
	{
		int xmax;
		int umax;
	};

	union
	{
		int ymax;
		int vmax;
	};

	t_rect &operator += (const t_rect &rect)
	{
		if(rect.xmin <= xmin)
			xmin = rect.xmin;

		if(rect.xmax >= xmax)
			xmax = rect.xmax;

		if(rect.ymin <= ymin)
			ymin = rect.ymin;

		if(rect.ymax >= ymax)
			ymax = rect.ymax;

		return *this;
	}

	t_rect operator + (const t_rect &rect)const
	{
		t_rect tmp;
		
		tmp.xmin = xmin;
		tmp.xmax = xmax;
		tmp.ymin = ymin;
		tmp.ymax = ymax;

		tmp += rect;

		return tmp;
	}

} t_rect;

//====================================================
} // namespace csdk
#endif
/*@}*/