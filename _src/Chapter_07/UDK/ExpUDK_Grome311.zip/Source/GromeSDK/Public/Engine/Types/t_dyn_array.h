//====================================================
/* Core - QUAD Software */
/*! 
\file 
\brief 

Copyright (C) 2006 Quad Software
This software is provided 'as-is', without any express or implied warranty.  In no event 
will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_DYN_ARRAY_H
#define __CSDK_T_DYN_ARRAY_H

namespace csdk {

#define C_DYN_ARRAY_INVALID_IDX		UINT_MAX

//====================================================

//! Array that increases its size by doubling it when necessary.
template <class TYPE> class t_dyn_array
{
public:

	t_dyn_array()
	{
		_elem = NULL;
		_alloc_no = 0;
		_no = 0;
	}

	~t_dyn_array()
	{
		if(_elem) free(_elem);
	}

	void Release()
	{
		_alloc_no = 0;
		if(_elem)
		{
			free(_elem); _elem = NULL;
		}
		_no = 0;
	}

	void Reset()
	{
		_no = 0;
	}

	uint No() { return _no; }

	/*! \warning Range check is not performed. */
	TYPE& __fastcall Elem(const uint pos) { return _elem[pos]; }

	/*! \warning Range check is not performed. */
	TYPE& operator[](const uint pos) { return _elem[pos]; }

	uint AllocNo() { return _alloc_no; }

	uint __fastcall GetIndex(TYPE e)
	{
		for(uint i=0; i<_no; i++)
			if(_elem[i] == e) 
				return i;
		return C_DYN_ARRAY_INVALID_IDX;
	}

	//! Make sure we have enough space to add i no of elements.
	/*! \warning Different than static t_array this call doesn't make the no of elements equal to i. 
	It just makes memory loom for additional elements. */
	void __fastcall MakeRoom(uint i)
	{
		if(_no + i > _alloc_no)
		{
			if(_alloc_no == 0)
				_alloc_no = 1;

			do
			{
				_alloc_no <<= 1;
			} 
			while(_no + i > _alloc_no);

			_elem = (TYPE*)realloc(_elem, _alloc_no*sizeof(TYPE));
		}
	}

	void Repack()
	{
		if(_alloc_no != _no)
		{
			_alloc_no = _no;
			_elem = (TYPE*)realloc(_elem, _alloc_no*sizeof(TYPE));
		}
	}

	void AddBlank()
	{
		_AddBlank();
	}
	
	void __fastcall Add(TYPE e)
	{
		_AddBlank();
		_elem[_no-1] = e;
	}

	//! Add an element for which we know we have space allocated.
	void __fastcall AddAllocated(TYPE e) 
	{
		_elem[_no] = e;
		_no ++;
	}

	void AddAllocatedBlank()
	{
		_no ++;
	}

	void AddAllocatedBlanks(uint i)
	{
		if(_no + i <= _alloc_no)
			_no += i;
	}

	void __fastcall Ins(TYPE e, uint index)
	{
		uint prior_no = _no;

		_AddBlank();

		if(index >= prior_no)
		{
			_elem[prior_no] = e;
		}
		else
		{
			for(uint i=prior_no; i>index; i--)
				_elem[i] = _elem[i-1];
			_elem[index] = e;
		}
	}

	void __fastcall Del(uint pos)
	{
		_no --;
		if(pos < _no) // Move the last element in this position.
			_elem[pos] = _elem[_no];
	}

	t_error __fastcall DelElem(TYPE e)
	{
		uint idx = GetIndex(e);
		if(idx == C_DYN_ARRAY_INVALID_IDX)
			return C_NOTFOUND_ERR;
		Del(idx);
		return C_GENERIC_SUCCESS;
	}

	void __fastcall DelToEndAndKeepOrder(uint pos)
	{
		TYPE e = _elem[pos];

		for(uint i=pos; i<_no-1; i++) 
			_elem[i] = _elem[i+1];
		_no --;

		_elem[_no] = e;
	}

	t_error __fastcall DelElemAndKeepOrder(TYPE e)
	{
		uint idx = GetIndex(e);
		if(idx == C_DYN_ARRAY_INVALID_IDX)
			return C_NOTFOUND_ERR;
		DelAndKeepOrder(idx);
		return C_GENERIC_SUCCESS;
	}

	//! Put the content of the deleted item at the end because someone may want to reuse the data.
	void __fastcall DelToEnd(uint pos)
	{
		TYPE e = _elem[pos];

		_no --;

		if(pos < _no) // Move the last element in this position.
		{
			_elem[pos] = _elem[_no];
		}

		_elem[_no] = e; // Put the deleted element to the end.
	}

	//! Return the buffer of elements directly.
	TYPE* Elems() {return _elem;}

protected:
	
	//! Pointer to the array of elements.
	TYPE *_elem;
	//! No of elements in the array.
	uint _no;
	//! No of allocated elements in the array.
	uint _alloc_no;

	void _AddBlank()
	{
		_no ++;
		if(_no > _alloc_no)
		{
			if(_alloc_no == 0)
			{
				_alloc_no = 1;
			}
			else
			{
				_alloc_no <<= 1; // Double the allocation size.
			}

			_elem = (TYPE*)realloc(_elem, _alloc_no*sizeof(TYPE));
		}
	}

};

//=========================================================
} // namespace csdk
#endif
/*@}*/