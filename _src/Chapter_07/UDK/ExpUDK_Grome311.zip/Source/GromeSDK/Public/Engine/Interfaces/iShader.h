//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ISHADER_H
#define __CSDK_ISHADER_H

#include "iSdkInterface.h"

namespace csdk {

//====================================================

//! Possible material stages.
enum E_MAT_STAGE 
{
	C_MAT_INIT_STAGE = 0, //!< Shaders of this stage are executed after the material is successfully compiled.
	C_MAT_INSTANCING_STAGE, //!< Shaders of this stage are executed after the material is bound to a geometry entity.
	C_MAT_RUNTIME_STAGE, //!< Shaders of this stage are executed when a bound geometry must be rendered.
	C_MAT_STAGES_NO
};

//====================================================

//! Node factory name to create shaders (with iRootInterface::NewNode).
#define C_NODE_FACTORY_SHADER	"Shader"

//! Interface to a shader.
/*! 
A shader represents the rendering representation of a geometric entities. Multiple shaders are
part of materials (iMaterial) and gathered together in a material will indicate how geometric 
entities must be rendered.

Shaders have multiple implementations. They can represent rendering states (iRenderStateShader),
pixel/vertex shaders, custom scripts etc. For now only rendering state shaders are exposed by the SDK.

Possible subinterfaces supported by this node:

	iRenderStateShaderModifier - if this is referring to a render state shader that supports modifications.
*/
class iShader: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iShader"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Shader"; }
	
	// ==================================================

	//! Return the material stage this shader is intended for.
	virtual E_MAT_STAGE ShaderType() = 0;

};

//====================================================

//! Modifier class for a rendering state shader (obtained from iShader::OpenSubinterface).
/*! 
Rendering state shader implementation that support modifications of their data from SDK 
will export this subinterface. Rendering state shaders are the shaders that define rendering states like
alpha blending, current color etc (see interface for all the possible states). 
*/
class iRenderStateShaderModifier: public iSdkInterface
{
public:


};

//====================================================
} // namespace csdk
#endif
/*@}*/