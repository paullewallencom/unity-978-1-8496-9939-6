//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2012 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IIMAGE_H
#define __CSDK_IIMAGE_H

#include "iSdkInterface.h"
#include "iStorage.h"
#include "iIOStream.h"

namespace csdk {

//====================================================

//! Image format type.
enum E_IMG_TYPE
{
	C_IMG_TYPE_UNKNOWN = 0,
	C_IMG_TYPE_BMP,
	C_IMG_TYPE_ICO,
	C_IMG_TYPE_JPG,
	C_IMG_TYPE_PCD,
	C_IMG_TYPE_PCX,
	C_IMG_TYPE_PIC,
	C_IMG_TYPE_PNG,
	C_IMG_TYPE_PNM,
	C_IMG_TYPE_SGI,
	C_IMG_TYPE_TGA,
	C_IMG_TYPE_TIF,
	C_IMG_TYPE_RAW,
	C_IMG_TYPE_JNG,
	C_IMG_TYPE_GIF,
	C_IMG_TYPE_DDS,
	C_IMG_TYPE_PSD,
	C_IMG_TYPE_PSP,
	C_IMG_TYPE_PIX,
	C_IMG_TYPE_PXR
};

//! Pixel format (channels and their order) of an image.
enum E_IMG_PIXEL_FORMAT 
{
	C_IMG_PIXEL_UNKNOWN = 0,
	C_IMG_PIXEL_LUMINANCE, //!< Grayscale
	C_IMG_PIXEL_RGB, 
	C_IMG_PIXEL_RGBA, 
	C_IMG_PIXEL_BGR,
	C_IMG_PIXEL_BGRA,
	C_IMG_PIXEL_RGB_DXT1, //!< Compressed as DXT1
	C_IMG_PIXEL_RGB_DXT3, //!< Compressed as DXT3
	C_IMG_PIXEL_RGB_DXT5 //!< Compressed as DXT5
};

//! Data type for a channel of an image.
enum E_IMG_DATA_TYPE
{
	C_IMG_DATA_BYTE = 0,
	C_IMG_DATA_UNSIGNED_BYTE,
	C_IMG_DATA_SHORT,
	C_IMG_DATA_UNSIGNED_SHORT,
	C_IMG_DATA_INT,
	C_IMG_DATA_UNSIGNED_INT,
	C_IMG_DATA_FLOAT,
	C_IMG_DATA_DOUBLE
};

enum E_IMG_SCALE_FILTER
{
	C_IMG_SCALE_NEAREST = 0,
	C_IMG_SCALE_LINEAR,
	C_IMG_SCALE_BILINEAR,
	C_IMG_SCALE_BOX,
	C_IMG_SCALE_TRIANGLE,
	C_IMG_SCALE_BELL,
	C_IMG_SCALE_BSPLINE,
	C_IMG_SCALE_LANCZOS3,
	C_IMG_SCALE_MITCHELL
};

//====================================================
// iImage::CopyToEx save options structures.

//! Structure to describe JPG save options.
struct sJPGSaveOptions
{
	//! Quality of the jpg file upon saving. Lower quality have greater compression ratio.
	enum E_JPG_QUALITY quality;
};

//! JPG compression quality.
enum E_JPG_QUALITY
{
	C_JPG_QUALITY_HIGHEST = 0,
	C_JPG_QUALITY_GOOD,
	C_JPG_QUALITY_NORMAL,
	C_JPG_QUALITY_AVERAGE,
	C_JPG_QUALITY_BAD
};

//! Structure to describe DDS save options.
struct sDDSSaveOptions
{
	//! Compressor to be used.
	enum E_DDS_COMPRESSOR compressor;

	//! Quality of compression (not available for standard compressor).
	enum E_DDS_QUALITY quality;

	//! If we are to generate mipmaps or not (not available for standard compressor).
	bool generate_mipmaps;

	//! Use GPU acceleration when possible (not available for standard compressor).
	bool gpu_acceleration;
};

//! DDS compressor.
enum E_DDS_COMPRESSOR
{
	C_DDS_COMPRESSOR_STANDARD = 0, //!< Standard (recommended) compressor, offer relative good results in short time.
	C_DDS_COMPRESSOR_ADVANCED //!< Offers more options than the simple compressor (use when you have issues with standard compressor).
};

//! DDS compression quality.
enum E_DDS_QUALITY
{
	C_DDS_QUALITY_FAST = 0, //!< Fast compression, may produce visible artifacts (to be used for testing).
	C_DDS_QUALITY_NORMAL //!< Slower, high quality compression (to be used for final images).
};

//====================================================

//! Interface to write / read images to / from custom streams.
/*! User needs to implement his / her own version of this stream and provide it to the SDK functions were allowed. */
class iImageCustomStream
{
public:

	virtual unsigned int Read(void *buffer, unsigned size, unsigned count, void* handle) = 0;

	virtual unsigned int Write(void *buffer, unsigned size, unsigned count, void* handle) = 0;

	virtual int Seek(void* handle, long offset, int origin) = 0;

	virtual long Tell(void* handle) = 0;
};

//====================================================

//! Node factory name to create images (with iRootInterface::NewNode).
#define C_NODE_FACTORY_IMAGE	"Image"

//! Interface to a image.
/*! 
	For now the SDK exposes only read/get functions on the image. Future versions will allow image modifications.
*/
class iImage: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iImage"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Image"; }
	
	// [ Custom interface ]===================================

	//! Return the target path used by the image.
	virtual const t_char*	GetPath() = 0;

	//! Return the image format type.
	virtual E_IMG_TYPE	GetImgType() = 0;

	//! Save the image on the current path.
	/*! \param type Type under which the image is saved. Use unknown to save with the current format.
	\param format Pixel format (only DXTn format are supported for now and only for DDS images).
	\param save_parameters Advance format save options. Use NULL to use default options. Only sDDSSaveOptions 
	and sJPGSaveOptions are supported (save_parameters must be NULL or a pointer to a sDDSSaveOptions or sJPGSaveOptions structure). 
	*/
	virtual t_error Save(const E_IMG_TYPE type = C_IMG_TYPE_UNKNOWN, const E_IMG_PIXEL_FORMAT format = C_IMG_PIXEL_UNKNOWN, void *save_parameters = NULL) = 0;

	//! Append an image data to a file stream.
	/*! 
	\param file Interface to the file to which the image is appended.
	\param type Type under which the image is saved. Use unknown to save with the current format.
	\param format Pixel format (only DXTn format are supported for now and only for DDS images).
	\param save_parameters Advance format save options. Use NULL to use default options. Only sDDSSaveOptions 
	and sJPGSaveOptions are supported (save_parameters must be NULL or a pointer to a sDDSSaveOptions or sJPGSaveOptions structure). 
	*/
	virtual t_error AppendToStream(iIOStream *file, const E_IMG_TYPE type = C_IMG_TYPE_UNKNOWN, const E_IMG_PIXEL_FORMAT format = C_IMG_PIXEL_UNKNOWN, void *save_parameters = NULL) = 0;

	//! Append an image data to a custom stream file.
	/*! 
	\param stream_handle Custom handle on which the stream to operate (this will be the handle parameter sent to the stream functions).
	\param stream_interface Custom stream interface used to write the image data. User needs to implemen and allocate this interface.
	\param type Type under which the image is saved. Use unknown to save with the current format.
	\param format Pixel format (only DXTn format are supported for now and only for DDS images).
	\param save_parameters Advance format save options. Use NULL to use default options. Only sDDSSaveOptions 
	and sJPGSaveOptions are supported (save_parameters must be NULL or a pointer to a sDDSSaveOptions or sJPGSaveOptions structure). 
	*/
	virtual t_error AppendToCustomStream(void *stream_handle, iImageCustomStream *stream_interface, 
		const E_IMG_TYPE type = C_IMG_TYPE_UNKNOWN, const E_IMG_PIXEL_FORMAT format = C_IMG_PIXEL_UNKNOWN, void *save_parameters = NULL) = 0;

	//! Save the image into a different path than its current path.
	/*! The current image path is not modified. The image is just copied to another path.
	For more saving options you can use \c iImage::CopyToEx.
	\param os_path Path where to save the file.
	\param type Type under which the image is saved. Use unknown to save with the current format.
	\param format Pixel format (only DXTn format are supported for now and only for DDS images). */
	virtual t_error	CopyTo(const t_char *os_path, const E_IMG_TYPE type = C_IMG_TYPE_UNKNOWN, const E_IMG_PIXEL_FORMAT format = C_IMG_PIXEL_UNKNOWN) = 0;

	//! Save the image into a different path than its current path.
	/*! The current image path is not modified. The image is just copied to another path.
	Different than \c iImage::CopyTo, this extended version adds save_parameters which can indicate advanced save parameters. 
	For now only sDDSSaveOptions is supported so the user can tweak DDS compression.
	\param os_path Path where to save the file.
	\param type Type under which the image is saved. Use unknown to save with the current format.
	\param format Pixel format (only DXTn format are supported for now and only for DDS images).
	\param save_parameters Advance format save options. Use NULL to use default options. Only sDDSSaveOptions 
	and sJPGSaveOptions are supported (save_parameters must be NULL or a pointer to a sDDSSaveOptions or sJPGSaveOptions structure). 
	*/
	virtual t_error CopyToEx(const t_char *os_path, const E_IMG_TYPE type = C_IMG_TYPE_UNKNOWN, 
		const E_IMG_PIXEL_FORMAT format = C_IMG_PIXEL_UNKNOWN, void *save_parameters = NULL) = 0;

	//! Return the width of the image.
	virtual int	Width() = 0;
	//! Return the height of the image.
	virtual int	Height() = 0;
	//! Return the no of bits per pixel.
	virtual int	GetBPP() = 0;
	//! Return the image pixel format.
	virtual E_IMG_PIXEL_FORMAT GetPixelFormat() = 0;
	//! Return the data type of the pixel.
	virtual E_IMG_DATA_TYPE GetDataType() = 0;

	//! Indicate if the image is a cubemap or not.
	virtual bool IsCubemap() = 0;

	// Blank the image of the specified size, type, format and color.
	/*! If the image already has some data the old content is removed. 
	Some images may not support this operation and return C_NOTSUPPORTED_ERR.
	Usually all the SDK created images can be made blank. Some of the scene images
	will refuse to change the format and size (like the layers images).
	\param type Image file format.
	\param w Width of the image.
	\param h Height of the image.
	\param bpp Bytes per plane (1, 2, 3 or 4).
	\param format Channels format.
	\param data_type Type of data per channel.
	\param color Initial color as 4 floating values (RGBA format with each channel between 0 and 1). It can be NULL. */
	virtual t_error	MakeBlank(const E_IMG_TYPE type, const uint w, const uint h, const uint bpp, 
		const E_IMG_PIXEL_FORMAT format, const E_IMG_DATA_TYPE data_type, const float *color) = 0;
	//! Modify some pixels in the image at the specified position.
	/*! Set a pixels rectangle (x, y is the bottom left corner, while dx, dy is the rectangle width and 
	height) inside the image.
	\param x X coordinate where the pixels should be put (left to right order).
	\param y Y coordinate where the pixels should be put (bottom to top order).
	\param src Pointer to the pixel to be put in the image.
	\param dx Width of the pixels rectangle to be modified (from left to right).
	\param dy Height of the pixels rectangle to be modified (from bottom to top).
	*/
	virtual t_error	PutPixels(const uint x, const uint y, const void *src, const uint dx, const uint dy) = 0;

	//! Modify some pixels in the image at the specified position to a certain color.
	/*! Set a rectangle (x, y is the bottom left corner, while dx, dy is the rectangle width and 
	height) inside the image to a certain color.
	\param x X coordinate where the pixels should be put (left to right order).
	\param y Y coordinate where the pixels should be put (bottom to top order).
	\param color Pointer to the t_float4 color (RGBA) to be put in the image.
	\param dx Width of the pixels rectangle to be modified (from left to right).
	\param dy Height of the pixels rectangle to be modified (from bottom to top).
	*/
	virtual t_error	PutColor(const uint x, const uint y, const t_float4 *color, const uint dx, const uint dy) = 0;

	//! Get pixels from image specified position.
	/*! Read a pixels rectangle (x, y is the bottom left corner, while dx, dy is the rectangle width and 
	height) from the image.
	\param x X coordinate from where the pixels should be read (left to right order).
	\param y Y coordinate from where the pixels should be read (bottom to top order).
	\param o_pixels Pointer to the client allocated memory to read the pixels into.
	\param dx Width of the pixels rectangle to be read (from left to right).
	\param dy Height of the pixels rectangle to be read (from bottom to top).
	*/
	virtual t_error	GetPixels(const uint x, const uint y, void *o_pixels, const uint dx, const uint dy) = 0;

	//! Get a pointer directly to the image data, starting with the specified pixel.
	/*!	\param x The column position of the starting pixel.
		\param y The row position of the starting pixel.
	*/
	virtual const void* GetBuffer(const uint x, const uint y) = 0;

	//! Scale the image to the new dimensions, using the specified image filter.
	virtual	t_error	Scale(const uint new_width, const uint new_height, const E_IMG_SCALE_FILTER filter = C_IMG_SCALE_BOX) = 0;

	//! Scale the image into another image of new dimensions.
	virtual	t_error	ScaleTo(iImage *destination, const uint new_width, const uint new_height, const E_IMG_SCALE_FILTER filter = C_IMG_SCALE_BOX) = 0;

	//! Convert the image to a new pixel format and data type
	virtual	t_error Convert(const E_IMG_PIXEL_FORMAT pixel_format, const E_IMG_DATA_TYPE data_type) = 0;

	//! Clone the image
	/*! This method creates a new image with the specified type into the specified storage.
	\param clone_type The image type of the clone. If this parameter is UNKNOWN, the clone image has the same type as the source;
	\param clone_storage The storage holding the clone image. If the storage is NULL, the storage is the same as the storage of the source image.*/
	virtual iImage* Clone(E_IMG_TYPE clone_type = C_IMG_TYPE_UNKNOWN, iStorage* clone_storage = NULL) = 0;

	//! Change the type of the image
	virtual t_error ChangeType(const E_IMG_TYPE type	= C_IMG_TYPE_UNKNOWN) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/