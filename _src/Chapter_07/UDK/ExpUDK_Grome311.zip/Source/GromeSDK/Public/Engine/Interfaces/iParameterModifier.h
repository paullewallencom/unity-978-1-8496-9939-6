//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IPARAMETERMODIFIER_H
#define __CSDK_IPARAMETERMODIFIER_H

#include "iSdkInterface.h"

namespace csdk {

//! Possible types for node parameters
enum E_PARAM_TYPE
{
	C_PARAM_TYPE_UNKNOWN = 0, //! Unknown type, usually used for "command" parameters (parameters which trigger a certain processing routine for the node)
	C_PARAM_TYPE_BOOL,
	C_PARAM_TYPE_STRING,
	C_PARAM_TYPE_INT,
	C_PARAM_TYPE_UINT,
	C_PARAM_TYPE_FLOAT,
	C_PARAM_TYPE_FLOAT2, //!< Two floating point values.
	C_PARAM_TYPE_FLOAT3, //!< Three floating point values (usually used to hold a vector, RGB color (with components between 0 and 255) etc).
	C_PARAM_TYPE_FLOAT4, //!< Four floating point values (usually used to hold a vector, plane equation, RGBA color (with components between 0 and 255) etc).
	C_PARAM_TYPE_RESOURCE, //!< Hold a reference to another engine entity (texture, material, geometry etc).
	C_PARAM_TYPE_CHAR,
	C_PARAM_TYPE_UCHAR,
	C_PARAM_TYPE_SHORT,
	C_PARAM_TYPE_USHORT,
	C_PARAM_TYPE_DOUBLE,
	C_PARAM_TYPE_ARRAY //!< Hold an array of elements with the same elementary type (bool, string, int, uint, float etc). Used with combo controls.
};

//====================================================

//! Parameter modifier interface.
/*! This interface is usually obtained as a subinterface of a node interface and it is used for parameter I/O transfer for the underlaying engine node.
As opposed to the PropertyTable interface, which "attaches" certain properties to a node, the ParameterModifer interface operates directly on the parameters
exposed by the node, so that the caller can directly modify the node's behaviour.*/
class iParameterModifier: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iParameterModifier"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Node parameter I/O interface"; }
	
	// [ Custom interface ]===================================

	//! Get the number of parameters exposed by the target node
	virtual uint			GetParamsNo() = 0;

	//! Get the name of a parameter, given its index
	virtual const char*		GetParamName(uint index) = 0;

	//! Get the type of a parameter, given its index
	virtual E_PARAM_TYPE	GetParamType(uint index) = 0;

	//! Get the parameter specified by name, as a pointer to a value of the parameter's type
	virtual void*			GetParam(const char* name) = 0;

	//! Set the parameter specified by name, using a pointer to a value of the parameter's type
	virtual t_error			SetParam(const char* name, void* value_pnt) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/