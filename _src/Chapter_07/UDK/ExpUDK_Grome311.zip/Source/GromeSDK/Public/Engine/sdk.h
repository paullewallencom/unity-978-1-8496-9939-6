//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file Engine/sdk.h
	\brief Engine SDK includes.

	Copyright (C) 2005-2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ENGINE_SDK_H
#define __CSDK_ENGINE_SDK_H

//===========================================================

#if defined(UNICODE) || defined(_UNICODE)
#	ifndef D_UNICODE
#		define D_UNICODE
#	endif
#endif

#include "Types/types.h"

#include "Plugins/iStoragePlugin.h"
#include "Plugins/iPluginManager.h"

#include "Interfaces/iStorageManager.h"
#include "Interfaces/iGeomEntityTemplate.h"
#include "Interfaces/iLODEntityTemplate.h"
#include "Interfaces/iImage.h"
#include "Interfaces/iTexture.h"
#include "Interfaces/iMaterial.h"
#include "Interfaces/iMaterialManager.h"
#include "Interfaces/iWindow.h"
#include "Interfaces/iPropertyTableOwner.h"
#include "Interfaces/iScene.h"
#include "Interfaces/iConsole.h"
#include "Interfaces/iInterfaceContainer.h"
#include "Interfaces/iStorageFileSystem.h"

//===========================================================
#endif
/*@}*/