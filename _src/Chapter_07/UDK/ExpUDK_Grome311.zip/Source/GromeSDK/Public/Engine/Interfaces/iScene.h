//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ISCENE_H
#define __CSDK_ISCENE_H

#include "iTexture.h"

namespace csdk {

//! Name used to register the iScene interface with the SDK root.
/*! Use iRootInterface::GetInterface(C_SCENE_INTERFACE_NAME) to open the global scene interface. */
#define C_SCENE_INTERFACE_NAME		"Scene"

typedef void *t_snapshot_handle;
typedef bool (*t_snapshot_filter)(iSdkInterface *node);

//! Interface to the scene.
/*! 
Scene interface presents function to access global scene properties.
*/
class iScene: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iScene"; }

	virtual const char* Name() { return C_SCENE_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Scene"; }
	
	// ==================================================

	//! Return 8 positions indicating the corners of the bounding box containing the entire (visible) scene.
	/*! The return value is constant and must not be changed. The pointer can be temporary allocated and
	should not be stored. There is no guarantee but usually the bounding box is axis aligned. 
	\param include_hidden Indicate if hidden entities must be returned or not. */
	virtual const t_float3*	GetGlobalBBox(const t_bool include_hidden) = 0;

	//! Create a scene snapshot context.
	virtual t_snapshot_handle CreateSnapshotContext(uint width, uint height) = 0;

	//! Release a snapshot context when no longer needed.
	virtual void ReleaseSnapshotContext(t_snapshot_handle h) = 0;

	//! Return the texture in which the snapshot context renders.
	/*! This texture data can be be filled in an image (iTexture::FillImage) and saved to disk or data extracted.
	\warning You need to close this interface when no longer needed. */
	virtual iTexture*	 GetSnapshotTexture(t_snapshot_handle h) = 0;

	//! Take a top view snapshot (from above on -OY axis) of the world.
	/*! The snapshot is rendered in the context texture. The entire scene (including terrain zones
	and objects) are rendered in the texture but doesn't include editing elements like gizmos.
	The width of the world area (max.x - min.x) it is matched perfectly to match the snapshot width. 
	The height is matching the snapshot height as indicate at CreateSnapshotContext rather than max.z - min.z. 
	For possible flags see F_SCENE_SNAPSHOT_* values. User can also specify a custom filter function which is called
	for all the visible entities that also pass the flags check. If this function returns false the entity will not be included
	in the snapshot. */
	virtual t_error TopViewSnapshot(t_snapshot_handle h, const t_float3& min, const t_float3& max, uint flags, t_snapshot_filter custom_filter = NULL) = 0;

	//! Take a ortho snapshot (from a specified position) of the world.
	virtual t_error CustomDirSnapshot(t_snapshot_handle h, const t_float3& min, const t_float3& max, const t_float3& dir, uint flags, t_snapshot_filter custom_filter = NULL) = 0;
};

// Possible scene snapshot flags.
#define F_SCENE_SNAPSHOT_NO_LIGHT		(1<<0) //!< Use no lighting for the scene (usually enforced for lightmapped scenes).
#define F_SCENE_SNAPSHOT_NOLIGHT			F_SCENE_SNAPSHOT_NO_LIGHT //!< Old define (for backward compatibility).
#define F_SCENE_SNAPSHOT_NO_OBJS		(1<<1) //!< Don't include objects (on top of terrain) in the snapshot.
#define F_SCENE_SNAPSHOT_NO_TERRAIN	(1<<2) //!< Don't include terrain in the snapshot.
#define F_SCENE_SNAPSHOT_NO_WATER		(1<<3) //!< Don't render water in snapshot.
#define F_SCENE_SNAPSHOT_NO_DETAILS	(1<<4) //!< Don't render details in the snapshot.
#define F_SCENE_SNAPSHOT_NO_ROADS		(1<<5) //!< Don't render roads in the snapshot.
#define F_SCENE_SNAPSHOT_NO_IMGFILTERING	(1<<6) //!< Don't apply any texture filtering for terrain simple color maps (this should be used when you want to aquire unblurred images from top down views).

//====================================================
} // namespace csdk
#endif
/*@}*/