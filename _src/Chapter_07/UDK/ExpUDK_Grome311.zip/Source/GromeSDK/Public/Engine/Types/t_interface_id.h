//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __SDK_T_INTERFACE_ID_H
#define __SDK_T_INTERFACE_ID_H

namespace csdk {

// ====================================================

//! Uniquely identify a SDK interface.
typedef void* t_interface_id;

// ====================================================
} // namespace csdk
#endif
/*@}*/