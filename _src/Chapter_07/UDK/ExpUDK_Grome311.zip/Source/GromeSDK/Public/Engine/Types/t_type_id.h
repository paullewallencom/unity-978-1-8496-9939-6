//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __SDK_T_TYPE_ID_H
#define __SDK_T_TYPE_ID_H

namespace csdk {

// ====================================================

typedef void* t_type_id;

// ====================================================
} // namespace csdk
#endif
/*@}*/