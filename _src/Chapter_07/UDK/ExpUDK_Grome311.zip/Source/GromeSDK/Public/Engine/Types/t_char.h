//====================================================
/* Core - QUAD Software */
/*! 
	\file 
	\brief Depending on the character set, can be ASCII, Unicode etc.

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_CHAR_H
#define __CSDK_T_CHAR_H

namespace csdk {

//====================================================

#include <string.h>

#ifdef D_UNICODE

// Define Windows specific UNICODE mode.
#	ifndef UNICODE
#		define UNICODE
#	endif
#	ifndef _UNICODE
#		define _UNICODE
#	endif

#	include <stdlib.h>
#	include <wchar.h>

	//! Wide character (UNICODE).
	typedef wchar_t t_char;
	//! Wide unsigned character (UNICODE).
	typedef wchar_t t_uchar;

	// [ Operations ]===============================

	//! UNICODE version of \c strlen.
	inline size_t gStrLen(const t_char *string) { return wcslen(string); }
	//! UNICODE version of \c strcpy.
	inline t_char* gStrCpy(t_char *dst, const t_char *src) { return wcscpy(dst, src); }
	//! UNICODE version of \c strncpy.
	inline t_char* gStrNCpy(t_char *dst, const t_char *src, const size_t count) { return wcsncpy(dst, src, count); }
	//! UNICODE version of \c strcat.
	inline t_char* gStrCat(t_char *dst, const t_char *src) { return wcscat(dst, src); }
	//! UNICODE version of \c strncat.
	inline t_char* gStrNCat(t_char *dst, const t_char *src, const size_t count) { return wcsncat(dst, src, count); }
	//! UNICODE version of \c strcmp.
	inline int gStrCmp(const t_char *s1, const t_char *s2) { return wcscmp(s1, s2); }
	//! UNICODE version of \c strncmp.
	inline int gStrNCmp(const t_char *s1, const t_char *s2, const size_t count) { return wcsncmp(s1, s2, count); }
	//! UNICODE version of \c stricmp.
	inline int gStrICmp(const t_char *s1, const t_char *s2) { return _wcsicmp(s1, s2); }
	//! UNICODE version of \c strnicmp.
	inline int gStrNICmp(const t_char *s1, const t_char *s2, const size_t count) { return _wcsnicmp(s1, s2, count); }
	//! UNICODE version of \c strstr.
	inline const t_char* gStrStr(const t_char *dst, const t_char *src) { return wcsstr(dst, src); }
	//! UNICODE version of \c strchr.
	inline const t_char* gStrChr(const t_char *dst, int c) { return wcschr(dst, (wint_t)c); }
	//! UNICODE version of \c strlwr.
	inline t_char* gStrLwr(t_char *string) { return _wcslwr(string); }
	//! UNICODE version of \c strupr.
	inline t_char* gStrUpr(t_char *string) { return _wcsupr(string); }
	//! UNICODE version of \c strdup.
	inline t_char* gStrDup(const t_char* src) { return _wcsdup(src); }
	//! UNICODE version of sprintf.
#	define gSprintf swprintf
#	define gVsnprintf _vsnwprintf

	//! Macro to convert a constant ASCII string to current character set.
#	define M_SZ(SZ) L ## SZ

	inline double gAtof(const t_char *string) 
	{ 
		// For older Visual C++ (like VS6) the _wtof was not defined.
#ifdef D_VS6
		double d;
		swscanf(string, M_SZ("%f"), &d);
		return d;
#else
		return _wtof(string); 
#endif
	}
	inline int gAtoi(const t_char *string) { return _wtoi(string); }

	// [ Character set convertion ]=====================

	//! Fill a wide character buffer (must be enough allocated!) with an ascii token.
	inline void gStrCharSetFill(const char *ascii, const size_t ascii_len, t_char *o_receive_buffer)
	{
		for(size_t i=0; i<ascii_len; i++)
			o_receive_buffer[i] = (t_char)ascii[i];
	}

	//! Fill a wide string (must be enough allocated!) with an ascii token (and add the null terminator).
	inline void gStrCharSetFillAndZero(const char *ascii, const size_t ascii_len, t_char *o_receive_buffer)
	{
		gStrCharSetFill(ascii, ascii_len, o_receive_buffer);
		o_receive_buffer[ascii_len] = M_SZ('\0');
	}

	//! Fill an ascii character buffer (must be enough allocated!) with a current character set token.
	/*! \warning Conversion data lost of wide characters. */
	inline void gStrAsciiFill(const t_char *wide, const size_t wide_len, char *o_receive_buffer)
	{
		for(size_t i=0; i<wide_len; i++)
			o_receive_buffer[i] = (char)wide[i]; 
	}

	//! Fill an ascii string (must be enough allocated!) with a current character set token.
	inline void gStrAsciiFillAndZero(const t_char *wide, const size_t wide_len, char *o_receive_buffer)
	{
		gStrAsciiFill(wide, wide_len, o_receive_buffer);
		o_receive_buffer[wide_len] = '\0';
	}

#else // ASCII ============================================

#	define D_ASCII

	//! ASCII character.
	typedef char t_char;
	//! ASCII unsigned character.
	typedef unsigned char t_uchar;

	// [ Character set convertion ]=====================

	//! Macro to convert a constant ASCII string to current character set.
#	define M_SZ(SZ) SZ

	//! Fill a wide character buffer (must be enough allocated!) with an ascii token.
	inline void gStrCharSetFill(const char *ascii, const size_t ascii_len, t_char *o_receive_buffer)
	{
		memcpy(o_receive_buffer, ascii, ascii_len);//*sizeof(char));
	}

	//! Fill a wide string (must be enough allocated!) with an ascii token (and add the null terminator).
	inline void gStrCharSetFillAndZero(const char *ascii, const size_t ascii_len, t_char *o_receive_buffer)
	{
		memcpy(o_receive_buffer, ascii, ascii_len);//*sizeof(char));
		o_receive_buffer[ascii_len] = '\0';
	}

	//! Fill an ascii character buffer (must be enough allocated!) with a current character set token.
	/*! \warning Conversion data lost of wide characters. */
	inline void gStrAsciiFill(const t_char *wide, const size_t wide_len, char *o_receive_buffer)
	{
		memcpy(o_receive_buffer, wide, wide_len);//*sizeof(char));
	}

	//! Fill an ascii string (must be enough allocated!) with a current character set token.
	inline void gStrAsciiFillAndZero(const t_char *wide, const size_t wide_len, char *o_receive_buffer)
	{
		memcpy(o_receive_buffer, wide, wide_len);//*sizeof(char));
		o_receive_buffer[wide_len] = '\0';
	}

	// [ Operations ]===============================

	//! ASCII version of \c strlen.
	inline size_t gStrLen(const t_char *string) { return strlen(string); }
	//! ASCII version of \c strcpy.
	inline t_char* gStrCpy(t_char *dst, const t_char *src) { return strcpy(dst, src); }
	//! ASCII version of \c strncpy.
	inline t_char* gStrNCpy(t_char *dst, const t_char *src, const size_t count) { return strncpy(dst, src, count); }
	//! ASCII version of \c strcat.
	inline t_char* gStrCat(t_char *dst, const t_char *src) { return strcat(dst, src); }
	//! ASCII version of \c strncat.
	inline t_char* gStrNCat(t_char *dst, const t_char *src, const size_t count) { return strncat(dst, src, count); }
	//! ASCII version of \c strcmp.
	inline int gStrCmp(const t_char *s1, const t_char *s2) { return strcmp(s1, s2); }
	//! ASCII version of \c strncmp.
	inline int gStrNCmp(const t_char *s1, const t_char *s2, const size_t count) { return strncmp(s1, s2, count); }
	//! ASCII version of \c stricmp.
	inline int gStrICmp(const t_char *s1, const t_char *s2) { return _stricmp(s1, s2); }
	//! ASCII version of \c strnicmp.
	inline int gStrNICmp(const t_char *s1, const t_char *s2, const size_t count) { return _strnicmp(s1, s2, count); }
	//! ASCII version of \c strstr.
	inline const t_char* gStrStr(const t_char *dst, const t_char *src) { return strstr(dst, src); }
	//! ASCII version of \c strchr.
	inline const t_char* gStrChr(const t_char *dst, int c) { return strchr(dst, c); }
	//! ASCII version of \c strlwr.
	inline t_char* gStrLwr(t_char *string) { return _strlwr(string); }
	//! ASCII version of \c strupr.
	inline t_char* gStrUpr(t_char *string) { return _strupr(string); }
	//! ASCII version of strdup.
	inline t_char* gStrDup(const t_char* src) { return _strdup(src); }
	//! ASCII version of sprintf.
#	define gSprintf sprintf
#	define gVsnprintf _vsnprintf

	inline double gAtof(const char *string) { return atof(string); }
	inline int gAtoi(const char *string) { return atoi(string); }

#endif // D_UNICODE

//====================================================
}; // namespace csdk
#endif
/*@}*/