//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2012 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IMATERIAL_H
#define __CSDK_IMATERIAL_H

#include "iShader.h"
#include "iImage.h"

namespace csdk {

//====================================================

//! Node factory name to create materials (with iRootInterface::NewNode).
#define C_NODE_FACTORY_MATERIAL		"Material"

//! Information about a texture channel custom attribute.
struct sMaterialTexChannelAttrib
{
	t_ascii_string *name;
	t_ascii_string *value;
};

//! Data about a texture channel used by the material.
struct sMaterialTexChannel
{
	//! Name of the channel.
	const t_char *name;

	//! Texture unit associated with this channel.
	uint tex_unit;

	//! Image used by default if none is indicated.
	iImage* default_image;

	//! Number of custom attributes for this channel.
	uint custom_attribs_no;
	sMaterialTexChannelAttrib *custom_attribs;
};

//====================================================

//! Interface to a material.
/*! 
Materials are the engine nodes used to render various geometry.

Every material go thru several stages (see E_MAT_STAGE) before the rendering is performed:
- Compilation and init (compile the material components)
- Instancing (prepare the geometry for rendering)
- Runtime (rendering of the geometry)

NOTE: only runtime shaders stage is currently exposed by the SDK!

Compilation/init is done once after the material content was created. Material must
be recompiled if its structure changes. 

Instancing is done once for every geometry entity that is to be rendered with this material. 
It must be reapplied if the geometry changes. 

Runtime shaders are applied when the geometry must be rendered.

The content of the material is made of shaders. Shaders can be of different types
and implementations. There are 3 distinct types of shaders for every stage of the 
material: material init shaders, instantiation shaders and runtime shaders.
Every type can have different implemenation (e.g. runtime shaders can be fixed
pipeline shaders, vertex programs, fragment programs, GLSL code etc.). 

The material act as a set of containers of shaders (one for every stage). The actual 
shaders to be applied during stages (the so called instance and runtime running paths) 
are  determined during the compilation stage. Some "smart" materials can have 
variable running paths when the shaders to be applied at rendering can change from
one frame to another.

The material compilation will determine what no of rendering passes the material requests. 
Smart implementations of materials can aggregate multiple shaders into one rendering 
pass by taking full advantage of the current hardware configuration. 

The job of material init shaders is usually to determine the configuration of the instance 
and runtime shaders, to prepare global variables etc. The instance shaders job is
to check if the structure of the bound geometry is ready for runtime and to prepare runtime
parameters. The runtime shaders are applied during runnings to prepare the context of rendering.

*/
class iMaterial: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with iRootInterface::GetTypeId(iMaterial::TypeString())).
	static const char* TypeString() { return "iMaterial"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Material"; }
	
	// [ Components] ===========================================

	//! Return the no of shader referred by this material on a stage.
	/*! \warning Only C_MAT_RUNTIME_STAGE is currently supported by the SDK. The other stages always return 0. */
	virtual uint				ShadersNo(E_MAT_STAGE stage) = 0;
	//! Return a shader from this material given its index in a stage.
	/*! \warning Only C_MAT_RUNTIME_STAGE is currently supported by the SDK. The other stages always return NULL. */
	virtual iShader*	GetShader(E_MAT_STAGE stage, const uint index) = 0;

	// Texture channels used by this material ==========================

	//! Return the number of texture channels used by this material.
	virtual uint			GetTextureChannelsNo() = 0;

	//! Return information about a texture channel used by the material.
	/*! The returned data may be temporary and should not used (especially between calls to GetTextureChannel on the same
	or different material. */
	virtual sMaterialTexChannel*	GetTextureChannel(uint index) = 0;

	// [ Compilation ]============================================

	//! Indicate if the material was modified since the last compilation.
	virtual t_bool			IsModified() = 0;
	//! Indicate if the material is compiled or not.
	virtual t_bool			IsCompiled() = 0;

	// [ Misc ]==================================================

	//! Return the no of tags associated with this material.
	virtual uint					GetTagsNo() = 0;

	//! Return a tag associated with this material.
	/*! 
	A material tag is a string that indicate what type of usage this material has (example:
	"Lightmap", "AlphaTest" etc.). Tags are a mean to generally show the material purpose. 
	You don't need to know the material implementation details (which can contain shaders of
	GLSL, Cg etc) but we still get an idea about what the material should produce. These tags
	are added by the material creators and are stored in the material node. 

	There could be multiple tags (example: "LightMap" + "AlphaBlend" indicates that the 
	material applies a lightmap and also has alpha blending activated). 

	User can use this tags to make their own material implementations (in other languages
	like DX HLSL) during export, import etc.

	Standard tags include: "NoLight", "AlphaTest", "AlphaBlend", "NoDepth", "NoDepthWrites",
	"DoubleFace", "Lightmap", but the user can add more. 
	*/
	virtual const char*	GetTag(const uint idx) = 0;

	//! Indicate if the material has the tag.
	virtual t_bool			HasTag(const char *tag_sz) = 0;
};

//====================================================

//! Modifier class for a material.
/*! Material implementation that support modifications of their data from SDK will export this subinterface. */
class iMaterialModifier: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with iRootInterface::GetTypeId(iMaterialModifier::TypeString())).
	static const char* TypeString() { return "iMaterialModifier"; }

	// [ Components] ===========================================

	//! Add a shader to the material.
	/*! \warning Only C_MAT_RUNTIME_STAGE is currently supported by the SDK. */
	virtual t_error		AddShader(E_MAT_STAGE stage, iShader *shader) = 0;
	//! Insert a shader to a specified index in a stage.
	/*! \warning Only C_MAT_RUNTIME_STAGE is currently supported by the SDK. */
	virtual t_error		InsertShader(E_MAT_STAGE stage, iShader *shader, const uint index) = 0;
	//! Remove a shader from the material.
	/*! \warning Only C_MAT_RUNTIME_STAGE is currently supported by the SDK. */
	virtual t_error		RemoveShader(E_MAT_STAGE stage, iShader *shader) = 0;
	//! Clear all the content of the material.
	virtual void			DelAllShaders() = 0;

	// [ Compilation ]============================================

	//! Compile the material. 
	/*! Internally, this stage can collapse multiple shaders in one shader for faster rendering, 
	determine the running order based on the shader links. 
	\param o_err_str If not NULL it will contain an explanation if an error occurs. */
	virtual t_error		CompileMaterial(t_string *o_err_str = NULL) = 0;

	//! Unload the compilation from memory (no content deletion).
	virtual void			Unload() = 0; 

};

//====================================================
} // namespace csdk
#endif
/*@}*/