//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IMATERIALMANAGER_H
#define __CSDK_IMATERIALMANAGER_H

#include "iMaterial.h"

namespace csdk {

//! Name used to register the iMaterialManager interface with the SDK root.
/*! Use iRootInterface::GetInterface(C_MATERIALMANAGER_INTERFACE_NAME) to open the global material manager interface. */
#define C_MATERIALMANAGER_INTERFACE_NAME		"Material Manager"

//! Interface to the materials manager.
/*! 
Materials manager offer access to the rendering materials loaded in the system.
*/
class iMaterialManager: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iMaterialManager"; }

	virtual const char* Name() { return C_MATERIALMANAGER_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*	Description() { return "Material Manager"; }
	
	// ==================================================

	//! Return a handle to the first material in the system.
	virtual csdk::t_handle GetFirstMaterial() = 0;
	//! Return the next material in the system given the current handle.
	virtual csdk::t_handle GetNextMaterial(const csdk::t_handle h) = 0;
	//! Return the interface to the material associated with a handle.
	virtual csdk::iMaterial* GetMaterial(const csdk::t_handle h) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/