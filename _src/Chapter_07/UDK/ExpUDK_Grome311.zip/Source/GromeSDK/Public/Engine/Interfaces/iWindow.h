//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IWINDOW_H
#define __CSDK_IWINDOW_H

#include "iSdkInterface.h"

namespace csdk {

//====================================================

//! Interface to an engine window.
/*! 
*/
class iWindow: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iWindow"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Window"; }
	
	// [ Custom interface ]===================================

	//! Return the OS specific window data (example: HWND for Windows OS).
	/* The returned OS specific handle can be used to create OS specific windows
	children of the this window. Windows that return NULL are not initiated or
	doesn't have a direct OS window correspondent (example: a custom engine control). */
	virtual void* GetOSSpecific() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/