//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_ISURFACEINSTANCE_H
#define __CSDK_ISURFACEINSTANCE_H

#include "iSurfaceTemplate.h"

namespace csdk {

//====================================================

//! Interface to a geometrical surface instance.
/*! 
An instance is a space localization (via a matrix) to a surface template (see
\c iSurfaceTemplate interface). It can also contain individual data that customize
the template appearance (like custom mapping while keeping the template vertices).

\warning Surface instance interfaces are local to their geometry entity (their
interface id is NULL) and pointer to them should not be stored for later use.
*/
class iSurfaceInstance: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iSurfaceInstance"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Geometric Surface Instance Interface"; }
	
	// [ Custom interface ]===================================

	//! Return the template interface this is instance of.
	virtual iSurfaceTemplate* GetTemplate() = 0;

	//! Return the instance transformation (object) matrix,
	virtual const t_float4x4* GetTransformMatrix() = 0;

	//! Return the instance (transformed) surface bounding box (made of 8 vertex positions).
	virtual const t_float3* GetBBox() = 0;

	//! Return the interface to a texture bound for a certain unit (from 0 to 15) of the surface.
	/*! This function returns textures bound on the surface and not to the surface template. The most common
	case is when textures are bound to the template and shared by all the surface instances. But in some
	cases custom textures are bound to the instances. */
	virtual iTexture* GetTexture(const uint unit) = 0;

	//! Return the material bound to this surface.
	/*! This function returns the material bound on the surface and not to the surface template. The most common
	case is when material is bound to the template and shared by all the surface instances. But in some
	cases custom material is bound to the a certain instance. */
	virtual iMaterial* GetMaterial() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/