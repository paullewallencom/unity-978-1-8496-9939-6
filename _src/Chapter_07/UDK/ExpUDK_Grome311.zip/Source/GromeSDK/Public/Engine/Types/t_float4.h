//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2005 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_T_FLOAT4_H
#define __CSDK_T_FLOAT4_H

namespace csdk {

//====================================================

typedef struct t_float4 {

	union
	{
		float x;
		float r;
	};

	union
	{
		float y;
		float g;
	};

	union
	{
		float z;
		float b;
		float dx;
	};

	union
	{
		float w;
		float a;
		float dy;
	};

	t_float4()
	{
		r = g = b = a = 0.f;
	}

	t_float4(float red, float green, float blue, float alpha)
	{
		r = red;
		g = green;
		b = blue;
		a = alpha;
	}

	bool operator == (const t_float4 &vect)
	{
		return (x == vect.x && y == vect.y && z == vect.z && w == vect.w);
	}

	t_float4 &operator = (const t_float4 &vect)
	{
		x = vect.x;
		y = vect.y;
		z = vect.z;
		w = vect.w;

		return *this;
	}

} t_float4;

//====================================================
} // namespace csdk
#endif
/*@}*/