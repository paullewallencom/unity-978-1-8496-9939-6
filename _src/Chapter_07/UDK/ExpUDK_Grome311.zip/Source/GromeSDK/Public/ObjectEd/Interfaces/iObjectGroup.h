//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file iObjectGroup.h
	\brief Object group interface.

	Copyright (C) 2009 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IOBJECTGROUP_H
#define __CSDK_IOBJECTGROUP_H

#include "iObjectInstance.h"

namespace csdk {

//====================================================

//! Sub-interface obtain from iGeomEntityInstance to indicate an object group.
/*! 
Groups can be created or loaded into the current scene using the iObjectEd interface.
*/
class iObjectGroup: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iObjectGroup"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Group of object instances"; }
	
	// [ Custom interface ]===================================

	//! Return the number of sub-entities from the group.
	/*! Sub-entities can be other groups or normal object instances. */
	virtual uint GetGroupMembersNo() = 0;

	//! Return an entity part of this group.
	/*! \param index Index of the group member.
	\return Pointer to group member object instance interface. To verify if this is a sub-group try to open its iObjectGroup sub-interface. */
	virtual iObjectInstance* GetGroupMember(uint index) = 0;

	//! Attach an object to the group.
	/*! After attachment the entity will be manipulated as part of the group (when the group is closed). 
	You can even indicate another group to attach (nested group). 
	Attaching an member to a closed group triggers group pivot to become the center of the group. */
	virtual t_error AttachMember(iObjectInstance *object) = 0;

	//! Detach an object from the group.
	/*! Calling this function for an entity that is not present in the group is ignored with C_NOTFOUND_ERR return code. 
	Detaching an member to a closed group triggers group pivot to become the center of the group. */
	virtual t_error DetachMember(iObjectInstance *object) = 0;

	//! Detach an object from the group given its index.
	virtual t_error DetachMember(uint index) = 0;

	//! Return the current pivot point for the group.
	virtual t_float3 GetGroupPivot() = 0;

	//! Change the group pivot to point to a specific position.
	virtual void SetGroupPivot(t_float3 &p) = 0;

	//! Recompute the pivot to become the center of the group. 
	virtual void ComputeCentralPivot() = 0;

	//! Open the group.
	/*! While the group is opened its entity members can be individually manipulated. */
	virtual t_error OpenGroup() = 0;

	//! Close the group.
	/*! By default the groups are closed so they are manipulated as a whole. 
	Closing a group will make its pivot to point to the center of the bounding box and group
	transformation to be identify (no transformation except the group pivot translation). */
	virtual t_error CloseGroup() = 0;

	//! Indicate if the group opened.
	virtual t_bool IsOpened() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/