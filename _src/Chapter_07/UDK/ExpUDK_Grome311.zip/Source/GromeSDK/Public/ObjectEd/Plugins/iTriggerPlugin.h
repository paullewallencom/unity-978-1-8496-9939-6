//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief Object editing trigger plugins event constants.

	Copyright (C) 2008 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_OBJECTED_ITRIGGERPLUGIN_H
#define __CSDK_OBJECTED_ITRIGGERPLUGIN_H

#include "../../Editor/Plugins/iTriggerPlugin.h"
#include "../../Engine/Interfaces/iInterfaceContainer.h"
#include "../../ObjectEd/Interfaces/iObjectTemplate.h"

namespace csdk {

//====================================================
// Object editor trigger ids (for iTerrainEd module):

// Object instances operations:

//! Called before one or a group of objects are about to be instantiated.
/*! event_data: pointer to a t_readonly_array<sTriggerObjInstBeforeCreate> containing information for every new instance to be created.
Error return: editor aborts instances creation.
Usage example: can be used to perform validation before creating instances. 
NOT YET IMPLEMENTED ! */
#define C_TRIGGERID_OBJINST_BEFORE_CREATE		1

//! Structure with information for each instance to be created. C_TRIGGERID_OBJINST_BEFORE_CREATE plugin event data contain an array of these structures.
struct sTriggerObjInstBeforeCreate
{
	//! Name of the instance.
	t_char *inst_name;

	//! Instance template.
	iObjectTemplate *obj_template;

	//! Owner of the instance link (e.g. the terrain zone or NULL for global plane).
	iSdkInterface *link_owner_node;

	//! Creation flags.
	uint32 flags;

	//! Link position.
	t_float3 link_pos;
	//! Link normal.
	t_float3 link_norm;
	//! Link surface normal following strength.
	float link_norm_strength;

	//! Instance transformation scale.
	t_float3 scale;
	//! Instance transformation rotation.
	t_float3 rot;
	//! Instance translation.
	t_float3 translation;
};

//! Called after one or a group of objects are instantiated.
/*! event_data: pointer to sTriggerObjInstAfterCreate structure.
Error return: ignored.
Usage example: can be used to assign custom properties to new instances. */
#define C_TRIGGERID_OBJINST_AFTER_CREATE			2

//! Structure containing data for C_TRIGGERID_OBJINST_AFTER_CREATE plugin event.
struct sTriggerObjInstAfterCreate
{
	//! Container with all the created instances interfaces (you can cast these interfaces to iObjectInstance).
	iInterfaceContainer* created_instances;
};


// The following events are NOT YET IMPLEMENTED:

//! Called before one or a group of objects are about to be deleted.
#define C_TRIGGERID_OBJINST_BEFORE_DELETE		3
//! Called after one or a group of objects are deleted.
#define C_TRIGGERID_OBJINST_AFTER_DELETE			4
//! Called before one or a group of objects are about to be transformed (translated, rotated, scaled or link properties changed).
#define C_TRIGGERID_OBJINST_BEFORE_TRANSFORM		5
//! Called after one or a group of objects are transformed (translated, rotated, scaled or link properties changed).
#define C_TRIGGERID_OBJINST_AFTER_TRANSFORM			6

// Object containers operations:

//! Called before a container of objects is about to be swapped to disk.
#define C_TRIGGERID_OBJCONTAINER_BEFORE_SWAP		20
//! Called after a container of objects is swapped to disk.
#define C_TRIGGERID_OBJCONTAINER_AFTER_SWAP			21
//! Called before a container of objects is about to be unswapped from disk.
#define C_TRIGGERID_OBJCONTAINER_BEFORE_UNSWAP	22
//! Called after a container of objects is unswapped from disk.
#define C_TRIGGERID_OBJCONTAINER_AFTER_UNSWAP	23

//====================================================
}; // namespace csdk
#endif
/*@}*/