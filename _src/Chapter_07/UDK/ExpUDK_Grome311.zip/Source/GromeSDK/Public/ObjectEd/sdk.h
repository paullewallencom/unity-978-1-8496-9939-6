//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file ObjectEd/sdk.h
	\brief Object Editor SDK includes.

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup ObjectEdSDK Object Editor SDK */
/*@{*/

#ifndef __CSDK_OBJECTED_SDK_H
#define __CSDK_OBJECTED_SDK_H

//===========================================================

// Include Framework SDK header.
#include "../Editor/sdk.h"

#include "Interfaces/iObjectEd.h"
#include "Plugins/iTriggerPlugin.h"

//===========================================================
#endif
/*@}*/