//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup ObjectEdSDK Object Editor SDK */
/*@{*/

#ifndef __CSDK_IOBJECTEDPROJECT_H
#define __CSDK_IOBJECTEDPROJECT_H

#include "iObjectContainer.h"

namespace csdk {

//====================================================

//! SDK interface to object editor project.
/*! This is a subinterface of iEdProject and expose the object editing interface. */
class iObjectEdProject: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iObjectEdProject"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Object editor project"; }
	
	//! Return an array with all the object containers from this project.
	/*! You can use this array to enumerate all the objects from this project.
	Object containers contain all the objects linked to certain scene surfaces.
	For more details refer to \c iObjectContainer. */
	virtual t_readonly_array<iObjectContainer*>* GetObjectContainers() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/