//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup ObjectEdSDK Object Editor SDK */
/*@{*/

#ifndef __CSDK_IOBJECTTEMPLATE_H
#define __CSDK_IOBJECTTEMPLATE_H

#include "../../Engine/Interfaces/iSdkInterface.h"
#include "iObjectInstance.h"

namespace csdk {

//====================================================

//! SDK interface to an object template.
/*! 
This kind of entity is used to create multiple object instances of the same template 
with custom transformation and link properties. 

Usually the templates are geometric entities (like meshes, gizmos etc). 
In this case it supports iGeomEntityInstance interface (from OpenSubinterface).
*/
class iObjectTemplate: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iObjectTemplate"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Object template interface"; }
	
	// [ Custom interface ]===================================

	//! Return the instances created from this template.
	/*! \warning After modifications to the current scene (deletion, insertion of instances etc.) 
	parts of this array may become invalid (some interfaces referring to released instances and
	their operations have no effect). That's why it is not recommended to store this array for later use. */
	virtual t_readonly_array<iObjectInstance*>* GetInstances() = 0;
	
};

//====================================================
} // namespace csdk
#endif
/*@}*/