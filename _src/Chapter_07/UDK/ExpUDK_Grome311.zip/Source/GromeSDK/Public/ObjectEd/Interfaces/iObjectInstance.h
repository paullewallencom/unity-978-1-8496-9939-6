//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup ObjectEdSDK Object Editor SDK */
/*@{*/

#ifndef __CSDK_IOBJECTINSTANCE_H
#define __CSDK_IOBJECTINSTANCE_H

#include "../../Engine/Interfaces/iSdkInterface.h"

namespace csdk {

//====================================================

//! Link point information inside an owner surface for an object instance.
struct sObjectLinkPoint
{
	t_float3 pos; //!< World space position of the link point.
	t_float3 normal; //!< Normal in the link point (usually the face normal of the link surface).
};

//====================================================
// Instance flags:

#define F_OBJINST_FOLLOW_NORM_OX		(1<<0) //!< Indicate that the instance must follow link surface normal as OX axis.
#define F_OBJINST_FOLLOW_NORM_OY		(1<<1) //!< Indicate that the instance must follow link surface normal as OY axis.
#define F_OBJINST_FOLLOW_NORM_OZ		(1<<2) //!< Indicate that the instance must follow link surface normal as OZ axis.
#define F_OBJINST_FOLLOW_NORM				(F_OBJINST_FOLLOW_NORM_OX|F_OBJINST_FOLLOW_NORM_OY|F_OBJINST_FOLLOW_NORM_OZ)

#define F_OBJINST_TRANSF_FOLLOW_LINK			(1<<3) //!< Link distance is to be kept constant while transforming the instance (instance follow link surface), eexcept when the link point or position from it is changed.
#define F_OBJINST_IGNORE_OWNER_MODIFIC	(1<<4) //!< Link distance is to be kept constant while the link surface is modified (the instance react at surface modifications).

#define F_OBJINST_EDITOR								(1<<5) //!< Instance is an editor element and must not be saved/deleted etc as an usual instance (these are usually temporary instances).
#define F_OBJINST_EXTERNAL							(1<<20) //!< The instance is external (from another editing module, example: a light source), it is not a normal instance that needs to be modified / exporter / imported using its module functions.
#define F_OBJINST_GIZMO								(1<<21) //!< The instance is a gizmo (usually the editor flag is also set).

#define F_OBJINST_SELECTED							(1<<6) //!< Indicate that the instance is selected (in editing application).

//====================================================

class iObjectTemplate;
class iObjectContainer;

//! SDK interface to an object instance.
/*! 
Object instances are localized (transformed and linked) templates 
in the current scene. Usually the templates represent geometric data and the instances,
through 3D transformation, place this data into the world. 

If the object instance is a geometrical entity it supports iGeomEntityInstance interface (from OpenSubinterface).

Instances support linkage to other geometric surfaces (called link owner) so they can react to 
these surfaces modifications (e.g. instances of trees remain on a terrain surface even though this 
surface is modified).  Not only the instance position can be affected by the link point but also its 
orientation. Because of this link imposed on the instance, its translation and rotation is made of 
two components: one from the link point and one of the instance itself (relative to the link point). 

All the instances in a scene are part of an object container (see csdk::iObjectContainer).
The scene (the object project) is formed by multiple containers, one for every linking 
surface. An instance is part of a single containers (it cannot be linked to multiple surfaces). 
Unlinked instances are part of the container referring to scene origin plane (usually XZ plane).

Object instances also supports iPropertyTableOwner interface so custom property tables can
be attached to them.

Object instances can be part of a group (iObjectGroup). If the group is closed the instances will 
be transformed by the group global matrix. To be noted that while an instance is part of a closed
group, this interface will still return global instance transformation (not local to the group)!
*/
class iObjectInstance: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iObjectInstance"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Object instance interface"; }
	
	// [ Custom interface ]===================================

	//! Return the object template this is instance of.
	virtual iObjectTemplate*		GetTemplate() = 0;

	//! Return the instance flags (see F_OBJINST_* for possible values).
	virtual uint32		GetFlags() = 0;

	t_bool IsSelected() { return (t_bool)(GetFlags() & F_OBJINST_SELECTED); }

	//! Return the link position this instance has on its owner link surface.
	virtual t_float3	GetLinkPosition() = 0;

	//! Return the normal of the link owner surface at link point.
	virtual t_float3	GetLinkNormal() = 0;

	//! Return information about the link point (its position and normal).
	void GetLinkPoint(sObjectLinkPoint &o_pnt)
	{
		o_pnt.pos = GetLinkPosition();
		o_pnt.normal = GetLinkNormal();
	}

	//! Return the object space scale of the instance.
	virtual t_float3	GetScale() = 0;
	//! Return the object space rotation.
	/*! This rotation is relative to owner surface normal if F_OBJINST_FOLLOW_NORM is set. */
	virtual t_float3	GetRotation() = 0;
	//! Return the object translation relative to the link point.
	virtual t_float3	GetTranslation() = 0;

	//! Return the global (world space) translation ( = translation of the link point + translation from the link).
	t_float3					GetTotalTranslation() { return GetTranslation() + GetLinkPosition(); }

	//! Return the global (world space) rotation ( = rotation from the link point combined with object rotation).
	virtual t_float3	GetTotalRotation() = 0;

	//! Return the rotation imposed by the link point normal.
	virtual t_float3	GetLinkRotation() = 0;

	//! Return the strength (0 = no link, 1 = full follow) of the owner surface following.
	/*! When linked to a surface, an instance can follow its orientation by aligning one of its axes (see F_OBJINST_FOLLOW_NORM* flags)
	with the surface normal in the link point. This value will indicate how much the instance is following the surface normal. */
	virtual float			GetFollowNormStrength() = 0;

	//! Set the link position this instance has on its owner surface.
	/*! After modifying one or multiple transformation parameters (link pos, scale, tran, rot etc), user must call 
	UpdateTransformation to make the changes final. 
	You cannot modify an instance that is part of a closed group. 
	For performance reasons undo is not register for this operation. */
	virtual t_error		SetLinkPosition(const t_float3& v) = 0;

	//! Set the object space scale of the instance.
	/*! After modifying one or multiple transformation parameters (link pos, scale, tran, rot etc), user must call 
	UpdateTransformation to make the changes final.
	You cannot modify an instance that is part of a closed group. 
	For performance reasons undo is not register for this operation. */
	virtual t_error		SetScale(const t_float3& v) = 0;

	//! Set the object space rotation.
	/*! This rotation is relative to owner surface normal if F_OBJINST_FOLLOW_NORM is set. 
	/*! After modifying one or multiple transformation parameters (link pos, scale, tran, rot etc), user must call 
	UpdateTransformation to make the changes final.
	You cannot modify an instance that is part of a closed group. 
	For performance reasons undo is not register for this operation. */
	virtual t_error		SetRotation(const t_float3& v) = 0;

	//! Set the object translation relative to the link point.
	/*! After modifying one or multiple transformation parameters (link pos, scale, tran, rot etc), user must call 
	UpdateTransformation to make the changes final.
	You cannot modify an instance that is part of a closed group. 
	For performance reasons undo is not register for this operation. */
	virtual t_error		SetTranslation(const t_float3& v) = 0;

	//! Set the strength (0 = no link, 1 = full follow) of the owner surface following.
	/*! After modifying one or multiple transformation parameters (link pos, scale, tran, rot etc), user must call 
	UpdateTransformation to make the changes final. 
	You cannot modify an instance that is part of a closed group. 
	For performance reasons undo is not register for this operation. */
	virtual t_error		SetFollowNormStrength(const float strength) = 0;

	//! Called after some transformations (scale, rot, translations) are set and we want to recompute the final instance transformation.
	virtual void			UpdateTransformation() = 0;

	//! Return the final transformation matrix for the object instance.
	/*! Note: if the geometry is made of multiple surfaces (represented by iSurfaceInstance) these 
	individual surfaces may have different matrices than this one. This is the group matrix and
	the surfaces in the group may have additional offsets from the group pivot. In this case the
	individual surfaces matrices represent the final matrices used for render. These can be obtained
	with iSurfaceInstance::GetTransformMatrix. */
	virtual void			GetTransformMatrix(t_float4x4 &o_mat) = 0;

	//! Return the container of this object instance.
	/*! All the instances in a scene are part of a container. The scene is formed by multiple
	containers, one for every linking surface. An instance is part of a single containers (it cannot
	be linked to multiple surfaces). Unlinked instances are part of the container referring to 
	scene origin plane (usually XZ plane). */
	virtual iObjectContainer* GetObjectContainer() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/