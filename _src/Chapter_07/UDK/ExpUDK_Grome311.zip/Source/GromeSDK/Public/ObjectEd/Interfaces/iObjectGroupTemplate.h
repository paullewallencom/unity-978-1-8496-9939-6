//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file iObjectGroupTemplate.h
	\brief Object group template interface.

	Copyright (C) 2009 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_IOBJECTGROUPTEMPLATE_H
#define __CSDK_IOBJECTGROUPTEMPLATE_H

#include "../../Engine/Interfaces/iGeomEntityTemplate.h"

namespace csdk {

//====================================================

//! Node factory name to create textures (with iRootInterface::NewNode).
#define C_NODE_FACTORY_OBJECTGROUPTEMPLATE		"ObjectGroupTemplate"


//====================================================

//! Sub-interface obtain from iGeomEntityTemplate to indicate an object group.
/*! 
Groups can be created or loaded into the current scene using the iObjectEd interface.
*/
class iObjectGroupTemplate: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iObjectGroupTemplate"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Template for a group of object instances"; }
	
	// [ Custom interface ]===================================

	//! Attach an object to the group.
	/*! After attachment the entity will be manipulated as part of the group (when the group is closed). 
	You can even indicate another group to attach (nested group). 
	Attaching an member to a closed group triggers group pivot to become the center of the group. */
	virtual t_error AttachMember(iGeomEntityTemplate *object, const t_float3* pos, const t_float3* rot, const t_float3* scale) = 0;

	//! Detach an object from the group.
	/*! Calling this function for an entity that is not present in the group is ignored with C_NOTFOUND_ERR return code. 
	Detaching an member to a closed group triggers group pivot to become the center of the group. */
	virtual t_error DetachMember(iGeomEntityTemplate *object) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/