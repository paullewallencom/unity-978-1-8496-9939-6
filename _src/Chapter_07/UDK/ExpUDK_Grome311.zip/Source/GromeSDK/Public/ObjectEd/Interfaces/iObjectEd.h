//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup ObjectEdSDK Object Editor SDK */
/*@{*/

#ifndef __CSDK_IOBJECTED_H
#define __CSDK_IOBJECTED_H

#include "iObjectEdProject.h"
#include "iObjectGroup.h"
#include "iObjectGroupTemplate.h"
#include "../../Engine/Interfaces/iStorage.h"

namespace csdk {

//====================================================

//! Picking method for iObjectEd::PickLinkPoint.
enum E_PICKLINK_METHOD
{
	C_PICKLINK_SEGMENT = 0, //!< Pink the point inside a segment (limited, oriented ray).
	C_PICKLINK_VECTOR, //!< Pick the point by a vector (oriented ray).
	C_PICKLINK_RAY //!< Pick the point with a ray (2 way vector).
};

//! Data to be sent to iObjectEditor::PickLinkPoint for C_PICKLINK_Segment method.
struct sPickLinkSegment
{
	t_float3 point1;
	t_float3 point2;
};

//! Data to be sent to iObjectEditor::PickLinkPoint for C_PICKLINK_VECTOR and C_PICKLINK_RAY method.
struct sPickLinkVector
{
	t_float3 origin;
	t_float3 vector;
};

//====================================================

//! Name used to register the iObjectEd interface with the SDK root.
#define C_OBJECTED_INTERFACE_NAME		"Object Editor"

//! SDK interface to object editor engine node.
/*! This interface can be obtained from the SDK root interface with a call to 
iRootInterface::GetInterface with C_OBJECTED_INTERFACE_NAME as name. */
class iObjectEd: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iObjectEd"; }

	virtual const char* Name() { return C_OBJECTED_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Object editor module"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to the current working object project.
	virtual iObjectEdProject* GetCurrProject() = 0;

	//! Find a object instance linking point inside the scene.
	/*! Pick a new link point for an object instance given a method and method specific data.
	\param method Method of picking.
	\param data Pointer to method specific data (see bellow for possible data structures).
	\param o_owner Contains the link owner. The the new owner SDK is opened so you must close it when no longer used.
	\param o_pnt The computed link point.
	*/
	virtual t_error PickLinkPoint(E_PICKLINK_METHOD method, void *data,
		iSdkInterface *&o_owner, sObjectLinkPoint &o_pnt) = 0;

	//! Create an object instance linked to a owner and in the current object editing project.
	/*!
	\param inst_name Name of the instance to be created.
	\param templ Object template for this instance.
	\param link_owner_node Pointer to the node owning the instance link (e.g. a terrain zone or an objects layer from the zone). 
	If NULL the global owner (the origin plane) is used.
	\param flags Instance flags (see F_OBJINST_* for possible values).
	\param link_pos Position of the instance link (obtained with iObjectEd::PickLinkPoint).
	\param link_norm Normal at the link position (obtained with iObjectEd::PickLinkPoint).
	\param link_norm_strength Between 0.0 and 1.0. It indicates how much the instance orientation
	is following the terrain surface (0 no follow, 1 full orientation).
	\param scale The scaling of the instance.
	\param rot The Euler rotation of the instance (this is added to the rotation caused by the link point orientation).
	\param translation The translation of the instance relative to the link position.
	*/
	virtual iObjectInstance* CreateObjectInstance(
		const char *inst_name, iObjectTemplate *templ, 
		iSdkInterface *link_owner_node, uint32 flags, 
		const t_float3 &link_pos, const t_float3 &link_norm, const float link_norm_strength, 
		const t_float3 &scale, const t_float3 &rot, const t_float3 &translation) = 0;

	//! Delete an object instance.
	/*! This is the proper method to delete an instance (it is not enough to delete its node).
	This method also remove the instance link. */
	virtual t_error DeleteObjectInstance(iObjectInstance *inst) = 0;

	// Objects group support. Groups are acting like normal instances but they don't have their own geometry. They
	// contain various other instances (including sub-groups) that they transform. Once a group is created it can be
	// manipulated as any other object instance (by obtaining its iObjectInstance sub-interface). Creating groups can
	// be done with CreateObjectGroup. Deleting a group is done with DeleteObjectInstance on its object instance interface.

	//! Create a new scene blank group.
	/*! The group is represented as any other object instance. By default the group is blank has no other objects in it. 
	The iObjectGroup sub-interface interface should be opened and group elements added:
	iObjectGroup *group_interface = (iObjectGroup*)group_instance->OpenSubinterface(g_sdk_root->GetTypeId(iObjectGroup::TypeString())); */
	virtual iObjectGroup* CreateObjectGroup(const t_char *user_def_name) = 0;

	//! Create a new object group template
	virtual iObjectGroupTemplate* CreateObjectGroupTemplate(const t_char *user_def_name) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/