//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup ObjectEdSDK Object Editor SDK */
/*@{*/

#ifndef __CSDK_IOBJECTCONTAINER_H
#define __CSDK_IOBJECTCONTAINER_H

#include "../../Engine/Interfaces/iSdkInterface.h"
#include "iObjectInstance.h"
#include "iObjectTemplate.h"

namespace csdk {

//====================================================
// Flags used when querying a container instances (at iObjectContainer::GetInstances).

#define F_GETINST_NORMAL		(1<<0) //! Normal (not hidden, non grouped, not gizmos) instances.
#define F_GETINST_HIDDEN			(1<<1) //! Hidden instances.
#define F_GETINST_GROUPED		(1<<2) //! Instances that are part of another groups (but are not groups).
#define F_GETINST_GROUPS		(1<<3) //! Groups of other instances (and subgroups)
#define F_GETINST_EDITOR			(1<<4)	//! Usually temporary instances (used by the editor).
#define F_GETINST_GIZMO			(1<<5) //! Gizmo instances.

// By default we return all the instances but the groups (to keep compatibility with previous versions in which we didn't have groups).
#define F_GETINST_DEFAULT (F_GETINST_NORMAL|F_GETINST_HIDDEN|F_GETINST_GROUPED|F_GETINST_EDITOR|F_GETINST_GIZMO)

//====================================================

//! SDK interface to an object container.
/*! 
Object containers gather together all the object instances linked to the 
same owning surface. Example: for every terrain zone in the scene there will be a object container that 
will include the instances for the associated zone (with the global context of that zone). Also for each 
objects layer from each terrain zone there is also a container. Containers can be associated with any 
surface that can keep objects linked to it.

All the instances in a scene are part of an object container. The scene (the object project) is formed 
by multiple containers, one for every linking surface. An instance is part of a single containers 
(it cannot be linked to multiple surfaces). There could be multiple object projects in the scene
workspace but only one active. The new instances are always created in the active project containers.

Unlinked instances are part of the container referring to scene origin plane (usually XZ plane). 
This container can be identified by the fact that it has no link owner (GetLinkOwner return NULL).
Every object project has its own origin plane container so when the project is active unlinked 
instances are created there.
*/
class iObjectContainer: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iObjectContainer"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Object container interface"; }
	
	// [ Custom interface ]===================================

	//! Return the owner of the link represented by this container.
	/*! If the return pointer is NULL the container is referring to the origin plane and contains unlinked instances. */
	virtual iSdkInterface* GetLinkOwner() = 0;

	//! Return the instances part of this container.
	/*! Instance can migrate to a container to another (can change their link owner). Also instances
	can be deleted and removed from this container. So it is not recommended to store this array content
	for later use. 
	\param flags See F_GETINST_* for possible flags. */
	virtual t_readonly_array<iObjectInstance*>* GetInstances(uint flags = F_GETINST_DEFAULT) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/