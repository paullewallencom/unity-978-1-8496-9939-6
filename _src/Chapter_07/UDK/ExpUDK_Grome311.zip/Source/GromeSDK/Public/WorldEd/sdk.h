//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file WorldEd/sdk.h
	\brief World Editor SDK includes.

	Copyright (C) 2005-2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup WorldEdSDK World Editor SDK */
/*@{*/

#ifndef __CSDK_WORLDED_SDK_H
#define __CSDK_WORLDED_SDK_H

//===========================================================

// Include Editor SDK header.
#include "../Editor/sdk.h"

#include "Interfaces/iWorldEd.h"
#include "Interfaces/iWorldEdProject.h"
#include "Interfaces/iRoadNetwork.h"
#include "Interfaces/iGeometryEditEntity.h"

//===========================================================
#endif
/*@}*/