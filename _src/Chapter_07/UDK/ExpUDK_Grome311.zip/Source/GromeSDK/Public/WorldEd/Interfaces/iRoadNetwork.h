//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup WorldEdSDK World Editor SDK */
/*@{*/

#ifndef __CSDK_IROADNETWORK_H
#define __CSDK_IROADNETWORK_H

#include "../../../Public/Engine/Interfaces/iSdkInterface.h"
#include "./../../Public/TerrainEd/Interfaces/iTerrainZone.h"
#include "./../../Public/Engine/Interfaces/iTexture.h"

namespace csdk {

//====================================================

//! The road part ids
enum E_ROAD_PARTS
{
	C_ROAD_MAIN = 0,		//!< The main part of the road edge, representing the full length of an edge, without the intersection tips.
	C_ROAD_INT_OUT,		//!< The intersection part representing an edge which "leaves" the intersection
	C_ROAD_INT_IN,		//!< The intersection part representing an edge which "enters" the intersection
	C_ROAD_PARTS_NO
};

//! The road point modes
enum E_ROAD_POINT_MODES
{
	C_ROAD_POINT_SMOOTH = 0,	//!< The default tangents for this point will be reset to create smooth road geometry around this control point.
	C_ROAD_POINT_CORNER		//!< The default tangents for this point will be created to match the orientation of the incoming edges into the point, making the road geometry appear as a hard corner.
};

//! Types of corners for creating the road geometry around the control points, configured as corners (see the point mode types above)
enum E_ROAD_CORNER_TYPES
{
	C_ROAD_CORNER_HARD = 0,	//!< Default setting for the road corners, it creates hard-edged geometry around the control points
	C_ROAD_CORNER_ROUNDED	//!< This corner type creates a smooth corner (arc).
};

//! SDK interface to a road network.
/*! 
The road network is a set of spline based shapes which represent a complete network of roads, which share the same cross-section.
*/
class iRoadNetwork: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iRoadNetwork"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Road network interface"; }
	
	// [ Custom interface ]===================================

	//! Return the first edge of the road entity, given the terrain zone
	/*! This method returns the first found edge of the underlaying road entity spline, which spans within the boundaries of the specified terrain zone.
	The method returns a temporary handle, which can only be used to perform a full iteration on the edges of the specified zone, and should not be stored for later use.
	Also, several iterations done in PARALLEL (on two distinct zones), should be avoided.
	*/
	virtual t_handle GetFirstEdge(iTerrainZone* zone) = 0;

	//! Return the next edge of the road entity, given the terrain zone and a previous iteration handle.
	/*! The returned handle is a temporary handle and should not be stored for later use.*/
	virtual t_handle GetNextEdge(t_handle handle, iTerrainZone* zone) = 0; 

	//! Get the size of the geometry data for a given edge handle
	virtual t_error GetGeometrySize(t_handle handle, uint& index_count, uint& vertex_count, E_ROAD_PARTS part) = 0;

	//! Dump the geometry data for a given edge handle into a set of pre-allocated buffers.
	/*! The buffer pointers which are sent as parameters should be allocated to the appropriate size, which needs to be obtained from a GetGeometrySize call.
	The geometry is made of triangle lists. */
	virtual t_error GetGeometryData(t_handle handle, uint* index_buffer, t_float3* vertex_buffer, t_float2* texcoords, E_ROAD_PARTS part) = 0;

	//! Get the name of the material which is used to render the edge, given the edge handle
	virtual const t_char* GetMaterialName(t_handle handle) = 0;

	//! Get the number of texture channels given a handle to a road edge
	virtual uint GetTextureChannelsNo(t_handle handle) = 0;

	//! Get a texture given the edge handle and the texture channel
	virtual iTexture* GetTexture(t_handle handle, uint tex_channel_id, E_ROAD_PARTS part) = 0;

	//! Get the zone which owns the texture for the given channel.
	/*! This method is used to retrieve the zones which represent the owners of the texture added via link layers to the road entity. If the method
	returns NULL for the given channel id, then the texture is not a link texture, but a common one.*/
	virtual iTerrainZone* GetTextureZone(t_handle, uint tex_channel_id) = 0;

	//! Get the material channel id for the current texture channel.
	virtual uint	GetMaterialChannelId(t_handle, uint tex_channel_id) = 0;

	//! Check if the edge specified by the given handle is a transition edge (passes through several terrain zones)
	virtual t_bool IsTransitionEdge(t_handle handle) = 0;

	// [ Road construction / query methods ]===================================

	//! This method returns the total number of control points used by this road network
	/*! The control points are referenced by the points in the road roads. A control point can be referred by several roads, where intersections occur.*/
	virtual uint GetPointsNo() = 0;

	//! This method fills the given pre-allocated buffer with the positions of the road network control points (in world space).
	/*! The given buffer must be large enough to hold the position for the entire control point set of the road network. The size is determined by calling the GetPointsNo method, 
	to retrieve the total number of control points from the road network.*/
	virtual t_error	GetPointsPositions(t_float3* vertex_buffer) = 0;

	//! Get the number of roads from the road network
	/*! This method returns the number of road roads (or splines) from the road network. Each road can have its own custom properties, such as width, influence and material settings.*/
	virtual uint GetRoadsNo() = 0;

	//! Get a handle to the given road, given its index
	virtual t_handle GetRoad(int index) = 0;

	//! Get the name of a road, given its handle
	/*! The pointer returned by this method must NOT be stored as it may become invalid between two method calls. It should be copied into a string allocated by the caller.*/
	virtual const t_char* GetRoadName(t_handle road) = 0;

	//! Get the width of the road, given its handle.
	virtual float GetRoadWidth(t_handle road) = 0;

	//! Get the interpolation step size for the specified road, in world units.
	virtual float GetRoadStepSize(t_handle road) = 0;

	//! Get the road influence value (the size of the blending area between the road surface and the terrain surface), in world units.
	virtual float GetRoadInfluence(t_handle road) = 0;

	//! Get the material name for the specified road.
	virtual const t_char* GetRoadMaterialName(t_handle road) = 0;

	//! Get the number of channels for the specified road material.
	virtual uint GetRoadMaterialChanNo(t_handle road) = 0;

	//! Get the source interface for the specified material channel index
	/*! This method returns an interface for the data source of the material channel. This interface can be either an iTexture or or an iTerrainMaterialLayer. For the latter case, the
	material channel is linked to the terrain material layer, and each road component will receive an appropriate texture, corresponding to the terrain zone which lies underneath that particular
	road component.*/
	virtual iSdkInterface* GetRoadMaterialChanSrc(t_handle road, uint channel_id, E_ROAD_PARTS part = C_ROAD_MAIN) = 0;

	//! Get the mapping coordinates transformations for the specified road material channel
	virtual t_error GetRoadMaterialChanMapping(t_handle road, uint channel_id, t_float2* o_scale, t_float2* o_offset, float* o_rotation) = 0;

	//! Get the number of points used by the road road, given a handle to the road
	virtual uint GetRoadPointsNo(t_handle road) = 0;

	//! This method fills a pre-allocated buffer with indices of the points used by the road road.
	/*! Each index is a position of a control point into the global control point buffer for the road network. The buffer must be large enough to hold the total number of points used by the road.*/
	virtual t_error	GetRoadPointsIndices(t_handle road, uint* index_buffer) = 0;

	//! This method returns the width scale value for the given point on the road.
	/*! Note that if the road point is an intersection, the returned scale value will be the scale value of the intersection*/
	virtual float GetRoadPointScale(t_handle road, uint index) = 0;

	//! This method returns the banking angle of the given point on the road, in hexadecimal units.
	virtual float GetRoadPointBanking(t_handle road, uint index) = 0;

	//! This method returns the left and right influence scale of the given point on the road.
	virtual t_error GetRoadPointInfluenceScale(t_handle road, uint index, float* o_left_scale, float* o_right_scale) = 0;

	//! This method returns the point type for a given point on the road
	virtual E_ROAD_POINT_MODES GetRoadPointMode(t_handle road, uint index) = 0;

	//! This method returns the corner type for the given point on the road.
	virtual E_ROAD_CORNER_TYPES GetRoadPointCornerType(t_handle road, uint index) = 0;

	//! Get the number of edges making up a road specified by its handle.
	virtual uint GetRoadEdgesNo(t_handle road) = 0;

	//! Get a handle to the road, given the edge 
	virtual t_handle GetEdgeRoad(t_handle edge) = 0;

	//! Get a handle to a road edge.
	virtual t_handle GetRoadEdge(t_handle road, uint edge_index) = 0;

	//! Check if an edge is bridge (has geometry, but does not affect the terrain underneath)
	virtual t_bool IsBridgeEdge(t_handle edge) = 0;

	//! Check if an edge is hidden (doesn't have geometry, but affects the terrain underneath)
	virtual t_bool IsHiddenEdge(t_handle edge) = 0;

	//! Get the tangents computed for the points which make up the specified edge (the outgoing tangent for the starting edge point and the incoming tangent for the ending edge point)
	virtual t_error GetRoadEdgeTangents(t_handle edge, t_float3* t1, t_float3* t2) = 0;

	//! Get the material name for the specified road edge.
	/*! This method returns the user defined name of the custom material applied to this edge. If the edge does not own its own material (uses the road's material), the returned value is NULL.*/
	virtual const t_char* GetEdgeMaterialName(t_handle edge) = 0;

	//! Get the number of channels for the specified road edge material.
	/*! This method returns the number of material channels */
	virtual uint GetEdgeMaterialChanNo(t_handle edge) = 0;

	//! Get the source interface for the specified material channel index.
	/*! This method returns an interface for the data source of the material channel. This interface can be either an iTexture or or an iTerrainMaterialLayer. For the latter case, the
	material channel is linked to the terrain material layer, and the edge will receive an appropriate texture, corresponding to the terrain zone which lies underneath it.*/
	virtual iSdkInterface* GetEdgeMaterialChanSrc(t_handle edge, uint channel_id, E_ROAD_PARTS part = C_ROAD_MAIN) = 0;

	//! Get the mapping coordinates transformations for the specified road material channel
	virtual t_error GetEdgeMaterialChanMapping(t_handle edge, uint channel_id, t_float2* o_scale, t_float2* o_offset, float* o_rotation) = 0;

	//! This method adds a chunk of control points to the road network.
	/*!	\param no Number of vertices in the chunk
		\param vertices Vertex positions of the control points
		\param o_indices Output index buffer for the added control points.
		The output index buffer must have the same size as the vertex buffer and it will be filled with the actual positions of the control points in the chunk (some of them may have
		been already found in the network vertex pool). This buffer must be used for subsequent calls to AddRoad, in order to adjust the road index buffer.*/
	virtual t_error AddPoints(uint no, t_float3* vertices, uint* o_indices) = 0;

	//! This method creates a new road road, using the provided index buffer to sequence the points.
	/*! This method creates a new road, using the existing control points from the road network and the index buffer which is pased as parameter. The minimum size of the 
	index buffer must be 2 (to create at least an edge).*/
	virtual t_handle AddRoad(uint size, uint* indices) = 0;

	//! Set the name of a road, given its handle
	virtual t_error SetRoadName(t_handle road, const t_char* name) = 0;

	//! Set the width for the specified road, in world units.
	virtual t_error SetRoadWidth(t_handle road, float value) = 0;

	//! Set the interpolation step size for the specified road, in world units.
	virtual t_error SetRoadStepSize(t_handle road, float value) = 0;

	//! Set the road influence value (the size of the blending area between the road surface and the terrain surface), in world units.
	virtual t_error SetRoadInfluence(t_handle road, float value) = 0;

	//! Set the material on the specified road, using the user defined name to identify the material in the materials storage.
	virtual t_error SetRoadMaterial(t_handle road, const t_char* name) = 0;

	//! Set the source for the specified road and material channel.
	/*! The type of the interface provided as source, MUST be either one of iTexture or iTerrainMaterialLayer. If the road does not have a material,or the channel id is not consistent with the 
	current number of material channels or the type of the interface is unknown, the method returns an error code.*/
	virtual t_error SetRoadMaterialChanSrc(t_handle road, uint channel_id, iSdkInterface* source) = 0;

	//! Set the mapping for the specified road and material channel.
	virtual t_error SetRoadMaterialChanMapping(t_handle road, uint channel_id, t_float2* scale, t_float2* offset, float* rotation) = 0;

	//! Set the brigde flag on the specified edge (has geometry, but does not affect the terrain underneath)
	virtual t_error SetBridgeEdge(t_handle edge, t_bool value) = 0;

	//! Set the hidden flag on the specified edge(doesn't have geometry, but affects the terrain underneath)
	virtual t_error SetHiddenEdge(t_handle edge, t_bool value) = 0;

	//! Set the tangents for the points which make up the specified edge (the outgoing tangent for the starting edge point and the incoming tangent for the ending edge point)
	virtual t_error SetEdgeTangents(t_handle edge, t_float3* t1, t_float3* t2) = 0;

	//! Set the material name for the specified road edge.
	/*! This method uses the user defined name of the material to find it and apply it to this edge. If the material is not found the method returns an error code.*/
	virtual t_error SetEdgeMaterial(t_handle edge, const t_char* name) = 0;

	//! Set the source for the specified edge and material channel.
	/*! The type of the interface provided as source, MUST be either one of iTexture or iTerrainMaterialLayer. If the ede does not have a material,or the channel id is not consistent with the 
	current number of material channels or the type of the interface is unknown, the method returns an error code.*/
	virtual t_error SetEdgeMaterialChanSrc(t_handle edge, uint channel_id, iSdkInterface* source) = 0;

	//! Set the mapping coordinates transformations for the specified road material channel
	virtual t_error SetEdgeMaterialChanMapping(t_handle edge, uint channel_id, t_float2* scale, t_float2* offset, float* rotation) = 0;

	//! Set the width scale value for the given point on the road.
	virtual t_error SetRoadPointScale(t_handle road, uint index, float value) = 0;

	//! Set the banking angle of the given point on the road, in hexadecimal units.
	virtual t_error SetRoadPointBanking(t_handle road, uint index, float value) = 0;

	//! Set the left and right influence scale of the given point on the road.
	virtual t_error SetRoadPointInfluenceScale(t_handle road, uint index, float* left_scale, float* right_scale) = 0;

	//! This method configures the point mode for a given point on the road.
	virtual t_error SetRoadPointMode(t_handle road, uint index, E_ROAD_POINT_MODES mode) = 0;

	//! This method configures the corner type for the specifed point on the road.
	/*! If the point mode of the given road point is not CORNER, or the point tangents are collinear, the corner type will not affect the road geometry, as
	the road interpolation routine will smooth out the geometry */
	virtual t_error SetRoadPointCornerType(t_handle road, uint index, E_ROAD_CORNER_TYPES type) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/