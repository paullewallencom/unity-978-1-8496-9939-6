//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup WorldEdSDK World Editor SDK */
/*@{*/

#ifndef __CSDK_IWORLDEDPROJECT_H
#define __CSDK_IWORLDEDPROJECT_H

#include "iRoadNetwork.h"
#include "iGeometryEditEntity.h"

namespace csdk {

//====================================================

//! SDK interface to World editor engine node.
/*! This is a subinterface of iEdProject and expose the World editing interface. */
class iWorldEdProject: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iWorldEdProject"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "World editor project"; }

	//! Return an array with all the road entities from the project
	virtual t_readonly_array<iRoadNetwork*>* GetRoadNetworks(t_bool selected = C_FALSE) = 0;

	//! Return the array of editable geometry entities
	virtual t_readonly_array<iGeometryEditEntity*>* GetGeometryEditEntities(t_bool selected = C_FALSE) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/