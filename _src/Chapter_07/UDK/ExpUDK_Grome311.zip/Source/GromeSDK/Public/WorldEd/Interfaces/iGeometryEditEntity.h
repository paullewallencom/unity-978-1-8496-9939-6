//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup WorldEdSDK World Editor SDK */
/*@{*/

#ifndef __CSDK_IGEOMETRYEDITENTITY_H
#define __CSDK_IGEOMETRYEDITENTITY_H

#include "../../../Public/Engine/Interfaces/iSdkInterface.h"
#include "../../../Public/Engine/Interfaces/iGeomEntityTemplate.h"
#include "../../../Public/Engine/Interfaces/iGeomEntityInstance.h"
#include "../../../Public/Engine/Interfaces/iPropertyTable.h"
#include "../../../Public/Editor/Interfaces/iEditMesh.h"


namespace csdk {

#define C_GEOMETRY_EDIT_FINAL_STAGE		-1

//====================================================

//! Descriptor for the edit stage of an edit entity
struct sEntityEditStageDescriptor
{
	//! The name of the edit node on the stage
	t_string node;

	//! The label given to the stage
	t_string label;
};


//! Surface descriptor for the edit entities
struct sEntitySurfaceDescriptor
{
	//! Id of the surface
	int ID;

	//! Owner stage (the stage which generated the surface)
	int owner_stage;

	//! The name of the surface
	t_string name;

	//! The list of stages which modify the surface
	t_array<uint> stages;
};

//====================================================


//! SDK interface to an editable geometry entity
/*! 
The editable geometry entity is the main editable object type, handled by the World Editor Module.
It consisits of a "seed" or "root" node, usually a simple primitive object (or an existing geometry template, loaded from library) on top of which, several geometry
modifiers are added, to create a new geometry template. The edit entity also has a default geometry instance, which reveals the edit object in the world scene.
*/
class iGeometryEditEntity: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iGeometryEditEntity"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Geometry edit entity interface"; }
	
	// [ Custom interface ]===================================

	//! Get the selected status of the entity
	virtual t_bool		IsSelected() = 0;

	//! Get the geometry template for this editable entity, at the given edit stage (0 = source node, -1 = final stage)
	virtual iGeomEntityTemplate* GetGeometryTemplate(int stage = C_GEOMETRY_EDIT_FINAL_STAGE) = 0;

	//! Get the geometry instance for this editable entity at the given edit stage (0 = source node, -1 = final stage)
	virtual iGeomEntityInstance* GetGeometryInstance(int stage = C_GEOMETRY_EDIT_FINAL_STAGE) = 0;

	//! Get the number of surfaces at the given stage
	virtual uint							GetSurfacesNo(int stage = C_GEOMETRY_EDIT_FINAL_STAGE) = 0;

	//! Fill the given descriptor structure with the information about the surface with the specified index
	/*! The method returns a temporary pointer which must not be stored by the caller. */
	virtual sEntitySurfaceDescriptor*	GetSurfaceDescriptor(int stage, uint surface) = 0;

	//! Get the number of edit stages
	/*! This method returns the number of edit stages of the entity, including the source edit node, which is on the first stage (with index 0).*/
	virtual uint									GetEditStagesNo() = 0;

	//! Get the descriptor for the given edit stage index
	virtual sEntityEditStageDescriptor*		GetEditStageDescriptor(uint stage) = 0;

	//! Get the property table of the node for the given stage index
	virtual iPropertyTable*			GetEditStageProperties(uint stage) = 0;

	//! Apply the changes made to the edit entity
	virtual t_error						Update() = 0;

	//! Get the edit mesh for this entity at the given edit stage (0 = source node, -1 = final stage)
	virtual iEditMesh*					GetEditMesh(int stage = C_GEOMETRY_EDIT_FINAL_STAGE) = 0;
	
};

//====================================================
} // namespace csdk
#endif
/*@}*/