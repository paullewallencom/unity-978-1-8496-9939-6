//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup WorldEdSDK World Editor SDK */
/*@{*/

#ifndef __CSDK_IWORLDED_H
#define __CSDK_IWORLDED_H


#include "iWorldEdProject.h"
#include "iRoadNetwork.h"

namespace csdk {

//====================================================

//! Name used to register the iWorldEd interface with the SDK root.
#define C_WORLDED_INTERFACE_NAME		"World Editor"

//! SDK interface to world editor engine node.
/*! This interface can be obtained from the SDK root interface with a call to iRootInterface::GetInterface with C_WORLDED_INTERFACE_NAME as name. */
class iWorldEd: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char*		TypeString() { return "iWorldEd"; }

	virtual const char*		Name() { return C_WORLDED_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*		Description() { return "WORLD editor module"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to the current working terrain project.
	virtual iWorldEdProject*	GetCurrProject() = 0;

	//! Add a blank road network object to the current project
	virtual iRoadNetwork*	AddRoadNetwork(const t_char* name) = 0;

	//! Update the contents managed by the world editor
	virtual t_error			UpdateContents() = 0;	

};

//====================================================
} // namespace csdk
#endif
/*@}*/