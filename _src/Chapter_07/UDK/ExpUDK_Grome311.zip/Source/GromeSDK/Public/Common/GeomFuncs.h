//========================================================
/* Graphical Terrain Engine - QUAD Software */
/*! 
	\file GeomFuncs.h
	\brief Geometric computation routines.

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//=========================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_GEOM_FUNCS_H
#define __CSDK_GEOM_FUNCS_H

#include "Math.h"

namespace csdk {

//=========================================================

//! Check if two aabb's overlap.
/*! The aabbs are represented by the min/max vectors*/
inline t_bool gAABBOverlapMinMax(const t_float3& min1, const t_float3& max1, const t_float3& min2, const t_float3& max2)
{
	if(min1.x > max2.x || max1.x < min2.x) return C_FALSE;
	if(min1.y > max2.y || max1.y < min2.y) return C_FALSE;
	if(min1.z > max2.z || max1.z < min2.z) return C_FALSE;
	return C_TRUE;
}

//! Check if two aabb's overlap.
/*! One aabb is represented by the min/max vectors and the other in 8 points format.*/
inline t_bool gAABBOverlapMinMaxBBox(const t_float3 &min1, const t_float3 &max1, const t_float3 *aabb2)
{
	if(min1.x > aabb2[1].x || max1.x < aabb2[0].x) return C_FALSE;
	if(min1.y > aabb2[2].y || max1.y < aabb2[0].y) return C_FALSE;
	if(min1.z > aabb2[4].z || max1.z < aabb2[0].z) return C_FALSE;
	return C_TRUE;
}

//! Check if two 2D quads overlap (each quad is made of 4 floats: min x, max x, min y, max y).
inline int gQuadInsideTest(const float* big_bb, const float *small_bb)
{
	// Quick outside tests (fewer comparisons)
	if(small_bb[0] > big_bb[1]) return 0;
	if(small_bb[1] < big_bb[0]) return 0;
	if(small_bb[2] > big_bb[3]) return 0;
	if(small_bb[3] < big_bb[2]) return 0;
	// Inside test
	if((small_bb[0] >= big_bb[0]) &&
		(small_bb[1] <= big_bb[1]) &&
		(small_bb[2] >= big_bb[2]) &&
		(small_bb[3] <= big_bb[3]))
		return 1; // Inside (biggest no of comparison)
	return 2; // Overlap (medium comparisons no)
}

//=========================================================

inline char gColLnPl(const t_float3 &s1, const float d1, const t_float3 &s2, const float d2, t_float3 &c)
{
	float v = d2-d1;
	if(v)
	{
		v = d2/v;

		c.x = s2.x - v * (s2.x-s1.x);
		c.y = s2.y - v * (s2.y-s1.y);
		c.z = s2.z - v * (s2.z-s1.z);

		return 1;
	}
	else
		c = s1;

	return 0;
}

inline void gPlaneClip(const t_float4& pl, const t_float3* poly, const uint no1,
				t_float3*& clipped_poly, uint& no2, uint &alloc_no)
{
	// at start, allocate maximum double size to avoid reallocations
	if(alloc_no < (no1 << 1))
	{
		alloc_no = no1 << 1;
		clipped_poly = (t_float3*)realloc(clipped_poly, sizeof(t_float3)*alloc_no);
	}

	char infront;
	float dist, prior_dist;

	prior_dist = gPlaneDistance(pl, poly[0]);

	// first vertex
	if(prior_dist >= 0.f)
	{
		clipped_poly[0] = poly[0];
		infront = 1;
		no2 = 1;
	}
	else
	{
		infront = 0;
		no2 = 0;
	}

	// from 1...
	for(uint i=1; i<no1; i++)
	{
		dist = gPlaneDistance(pl, poly[i]);

		if(dist >= 0.f)
		{
			if(!infront)
			{
				// line clipping and two coordinates addition
				gColLnPl(poly[i-1], prior_dist,
					poly[i], dist, 
					clipped_poly[no2]);
				no2 ++;

				// now we are infront
				infront = 1;
			}

			// add the infront vertex
			clipped_poly[no2] = poly[i];
			no2 ++;
		}
		else
		{
			// previous it was infront
			if(infront)
			{
				// just add the intersection point
				gColLnPl(poly[i-1], prior_dist,
					poly[i], dist, 
					clipped_poly[no2]);
				no2 ++;

				// now we are behind
				infront = 0;
			}
			// else do nothing (still behind the plane)
		}

		prior_dist = dist;
	}

	// line from last vertext to the first
	if(no1 > 2)
	{
		dist = gPlaneDistance(pl, poly[0]);
		if(dist >= 0.f)
		{
			if(!infront)
			{
				gColLnPl(poly[no1-1], prior_dist,
					poly[0], dist, 
					clipped_poly[no2]);
				no2 ++;
				infront = 1;
			}
		}
		else
		{
			if(infront)
			{
				gColLnPl(poly[no1-1], prior_dist,
					poly[0], dist, 
					clipped_poly[no2]);
				no2 ++;
				infront = 0;
			}
		}
	}
}

inline void gPlanesClip(const t_float4 *pl, const uint pl_no,
				 t_float3 *poly, uint no1,
				 t_float3 *&clipped_poly, uint &no2)
{
	clipped_poly = NULL;
	no2 = 0;

	if(!no1) return;

	// first plane clipping
	uint temp_alloc_no = 0;
	gPlaneClip(pl[0], poly, no1, clipped_poly, no2, temp_alloc_no);
	if(!no2) 
	{
		if(clipped_poly) { free(clipped_poly); clipped_poly = NULL; }
		return;
	}

	// use 2 arrays and ping-pong between them to reuse mem allocation

	t_float3 *poly1; 
	uint poly1_no, poly1_alloc_no;

	t_float3 *poly2 = NULL;
	uint poly2_no = 0, poly2_alloc_no = 0;

	// clipping with remaining planes
	for(uint i=1; i<pl_no; i++)
	{
		poly1 = clipped_poly;
		poly1_no = no2;
		poly1_alloc_no = temp_alloc_no;

		gPlaneClip(pl[i], poly1, poly1_no, poly2, poly2_no, poly2_alloc_no);

		// change the 2 arrays to reuse their memory allocations

		// use clipped_poly as temporary and last clipped polygon
		clipped_poly = poly2;
		no2 = poly2_no;
		poly2 = poly1;

		if(!no2)
		{
			free(clipped_poly);
			clipped_poly = NULL;
			break;
		}
		// clipped_poly remains with the last clipped values while poly2 is the unused poly array

		poly2_no = poly1_no;
		temp_alloc_no = poly2_alloc_no;
		poly2_alloc_no = poly1_alloc_no;
	}

	// delete one of the arrays (the one that is not used in clipped_poly)
	if(poly2) free(poly2);
}

//=========================================================

inline t_error gVAngNorms(const t_float3* vert, const uint vert_no, 
							const uint* ind, const uint ind_no,
							const bool stripified, t_float3* &norm, const bool normalize)
{
	if(!vert || !ind) return C_PARAM_ERR;
	if(!norm) norm = (t_float3*)malloc(sizeof(t_float3)*vert_no);
	if(!norm) return C_ALLOC_ERR;

	t_float3 vect1, vect2, plane_norm, norm_vect;
	memset(norm, 0, vert_no * sizeof(t_float3));

	if(stripified)
	{
		uint i0, i1, i2 = 2;
		while(i2<ind_no)
		{
			// check for degenerate triangles and change strip
			if(ind[i2] == ind[i2-1]) { i2 +=2; continue; } // we can skip 2 vertices
			if(ind[i2] == ind[i2-2] || ind[i2-1] == ind[i2-2]) { i2 ++; continue; } // skip one vertex

			if(i2&1) // odd
			{ i0 = i2-1; i1 = i2-2; }
			else // even
			{ i0 = i2-2; i1 = i2-1; }

			// plane normals (counterclockwise geometry)
			vect1 = gSubVect(vert[ind[i1]], vert[ind[i0]]);
			vect2 = gSubVect(vert[ind[i2]], vert[ind[i0]]);
			gsNormVect(vect1); gsNormVect(vect2);
			plane_norm = gCrossProduct(vect1, vect2); gsNormVect(plane_norm);
			
			// weight with the angle
			norm_vect = gScalarMultVect(plane_norm, gVectAngle(vect1, vect2));
			norm[ind[i0]].x += norm_vect.x; norm[ind[i0]].y += norm_vect.y; norm[ind[i0]].z += norm_vect.z;
			
			// second vertex
			vect1 = gSubVect(vert[ind[i2]], vert[ind[i1]]);
			vect2 = gSubVect(vert[ind[i0]], vert[ind[i1]]);
			gsNormVect(vect1); gsNormVect(vect2);
			norm_vect = gScalarMultVect(plane_norm, gVectAngle(vect1, vect2));
			norm[ind[i1]].x += norm_vect.x; norm[ind[i1]].y += norm_vect.y; norm[ind[i1]].z += norm_vect.z;

			// third vertex
			vect1 = gSubVect(vert[ind[i0]], vert[ind[i2]]);
			vect2 = gSubVect(vert[ind[i1]], vert[ind[i2]]);
			gsNormVect(vect1); gsNormVect(vect2);
			norm_vect = gScalarMultVect(plane_norm, gVectAngle(vect1, vect2));
			norm[ind[i2]].x += norm_vect.x; norm[ind[i2]].y += norm_vect.y; norm[ind[i2]].z += norm_vect.z;
			
			i2 ++;
		}
	
		// normalize
		if(normalize)
		for(i2=0;i2<vert_no;i2++) gsNormVect(norm[i2]);
	}
	else
	{
		uint i = 0;
		// [CAUTION] ind_no must be a multiple of 3
		while(i<ind_no)
		{
			vect1 = gSubVect(vert[ind[i+1]], vert[ind[i]]);
			vect2 = gSubVect(vert[ind[i+2]], vert[ind[i]]);
			gsNormVect(vect1); gsNormVect(vect2);
			plane_norm = gCrossProduct(vect1, vect2); gsNormVect(plane_norm);

			// weight with the angle
			norm_vect = gScalarMultVect(plane_norm, gVectAngle(vect1, vect2));
			norm[ind[i]].x += norm_vect.x; norm[ind[i]].y += norm_vect.y; norm[ind[i]].z += norm_vect.z;
			
			// second vertex
			vect1 = gSubVect(vert[ind[i+2]], vert[ind[i+1]]);
			vect2 = gSubVect(vert[ind[i+0]], vert[ind[i+1]]);
			gsNormVect(vect1); gsNormVect(vect2);
			norm_vect = gScalarMultVect(plane_norm, gVectAngle(vect1, vect2));
			norm[ind[i+1]].x += norm_vect.x; norm[ind[i+1]].y += norm_vect.y; norm[ind[i+1]].z += norm_vect.z;

			// third vertex
			vect1 = gSubVect(vert[ind[i+0]], vert[ind[i+2]]);
			vect2 = gSubVect(vert[ind[i+1]], vert[ind[i+2]]);
			gsNormVect(vect1); gsNormVect(vect2);
			norm_vect = gScalarMultVect(plane_norm, gVectAngle(vect1, vect2));
			norm[ind[i+2]].x += norm_vect.x; norm[ind[i+2]].y += norm_vect.y; norm[ind[i+2]].z += norm_vect.z;
			
			i += 3;
		}

		// normalize
		if(normalize)
		for(i=0;i<vert_no;i++) gsNormVect(norm[i]);
	}

	return C_GENERIC_SUCCESS;
}

//=========================================================
}
#endif
/*@}*/