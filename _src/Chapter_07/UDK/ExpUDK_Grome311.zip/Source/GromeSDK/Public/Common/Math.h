//========================================================
/* Graphical Terrain Engine - QUAD Software */
/*! 
	\file Math.h
	\brief Math routines.

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//=========================================================
/*! \addtogroup EngineSDK Engine SDK */
/*@{*/

#ifndef __CSDK_MATH_FUNCS_H
#define __CSDK_MATH_FUNCS_H

#include <math.h> 
#include <float.h>

namespace csdk {

//=========================================================

//! Use fast math routines
#define D_FAST_MATH

// Common constants used in computations
#define C_PI		3.1415926f
#define C_2PI		6.2831852f
#define C_180_OVER_PI		57.2957f
#define C_SQRT2		1.41421356f

//! The near-zero tolerance value
#define C_EPSILON	0.000001f

#define M_MIN(A, B) ((A) <= (B) ? (A) : (B))
#define M_MAX(A, B) ((A) >= (B) ? (A) : (B))

inline float gSgnf(const float v)
{
	if(v > 0.f) return 1.f;
	if(v < 0.f) return -1.f;
	return 0.f;
}

// Trigonometric ===============================================

inline float gACos(const float a) 
{
	if(a <= -1.f) return 3.14159265358979323846f;
	if(a >= 1.f) return 0.f;
	return acosf(a);
}

void inline gSinCosf(float radians, float *sine, float *cosine)
{
#ifdef _WIN64
	*sine = sinf(radians);
	*cosine = cosf(radians);
#else // _WIN32
	_asm
	{
		fld		DWORD PTR [radians]
		fsincos
			
		mov edx, DWORD PTR [cosine]
		mov eax, DWORD PTR [sine]
			
		fstp DWORD PTR [edx]
		fstp DWORD PTR [eax]
	}
#endif
}


//! Fast, accurate ftol.
inline int gFloat2Int(float a)
{
   int RetVal;

#ifdef _WIN64
	RetVal = static_cast<int>(a);
#else
#ifdef _WIN32
   int CtrlwdHolder;
   int CtrlwdSetter;
   __asm 
   {
      fld    a					// push 'a' onto the FP stack
      fnstcw CtrlwdHolder		// store FPU control word
      movzx  eax, CtrlwdHolder	// move and zero extend word into eax
      and    eax, 0xFFFFF3FF	// set all bits except rounding bits to 1
      or     eax, 0x00000C00	// set rounding mode bits to round down
      mov    CtrlwdSetter, eax	// Prepare to set the rounding mode -- prepare to enter plaid!
      fldcw  CtrlwdSetter		// Entering plaid!
      fistp  RetVal				// Store and converted (to int) result
      fldcw  CtrlwdHolder		// Restore control word
   }
#elif _LINUX
	RetVal = static_cast<int>(a);
#endif
#endif

	return RetVal;
}

//! Over 15x faster than: (int)floorf(value).
inline int gFloor2Int(float a)
{
   int RetVal;

#ifdef _WIN64
	RetVal = static_cast<int>(floor(a));
#else
#ifdef _WIN32
   int CtrlwdHolder;
   int CtrlwdSetter;
   __asm 
   {
      fld    a					// push 'a' onto the FP stack
      fnstcw CtrlwdHolder		// store FPU control word
      movzx  eax, CtrlwdHolder	// move and zero extend word into eax
      and    eax, 0xFFFFF3FF	// set all bits except rounding bits to 1
      or     eax, 0x00000400	// set rounding mode bits to round down
      mov    CtrlwdSetter, eax	// Prepare to set the rounding mode -- prepare to enter plaid!
      fldcw  CtrlwdSetter		// Entering plaid!
      fistp  RetVal				// Store floored and converted (to int) result
      fldcw  CtrlwdHolder		// Restore control word
   }
#elif _LINUX
	RetVal = static_cast<int>(floor(a));
#endif
#endif

	return RetVal;
}

//! Over 15x faster than: (int)ceil(value)
inline int gCeil2Int(float a)
{
   int RetVal;

#ifdef _WIN64
	RetVal = static_cast<int>(ceil(a));
#else
#ifdef _WIN32
   int CtrlwdHolder;
   int CtrlwdSetter;
   __asm 
   {
      fld			a					// push 'a' onto the FP stack
      fnstcw	CtrlwdHolder		// store FPU control word
      movzx		eax, CtrlwdHolder	// move and zero extend word into eax
      and			eax, 0xFFFFF3FF	// set all bits except rounding bits to 1
      or			eax, 0x00000800	// set rounding mode bits to round down
      mov		CtrlwdSetter, eax	// Prepare to set the rounding mode -- prepare to enter plaid!
      fldcw		CtrlwdSetter		// Entering plaid!
      fistp		RetVal				// Store floored and converted (to int) result
      fldcw		CtrlwdHolder		// Restore control word
   }
#elif _LINUX
	RetVal = static_cast<int>(ceil(a));
#endif
#endif

	return RetVal;
}

//=========================================================

// This is the 'final' version of the AlmostEqualUlps function.
// The optional checks are included for completeness, but in many
// cases they are not necessary, or even not desirable.
inline bool gFAlmostEqual(float A, float B, int maxUlps = 10)
{
	// There are several optional checks that you can do, depending
	// on what behavior you want from your floating point comparisons.
	// These checks should not be necessary and they are included
	// mainly for completeness.

#ifdef  INFINITYCHECK
	// If A or B are infinity (positive or negative) then
	// only return true if they are exactly equal to each other -
	// that is, if they are both infinities of the same sign.
	// This check is only needed if you will be generating
	// infinities and you don't want them 'close' to numbers
	// near FLT_MAX.
	if (gIsInfinite(A) || gIsInfinite(B))
		return A == B;
#endif

#ifdef  NANCHECK
	// If A or B are a NAN, return false. NANs are equal to nothing,
	// not even themselves.
	// This check is only needed if you will be generating NANs
	// and you use a maxUlps greater than 4 million or you want to
	// ensure that a NAN does not equal itself.
	if (gIsNan(A) || gIsNan(B))
		return false;
#endif

#ifdef  SIGNCHECK
	// After adjusting floats so their representations are lexicographically
	// ordered as twos-complement integers a very small positive number
	// will compare as 'close' to a very small negative number. If this is
	// not desireable, and if you are on a platform that supports
	// subnormals (which is the only place the problem can show up) then
	// you need this check.
	// The check for A == B is because zero and negative zero have different
	// signs but are equal to each other.
	if (gSignBit(A) != gSignBit(B))
		return A == B;
#endif

	int aInt = *(int*)&A;
	// Make aInt lexicographically ordered as a twos-complement int
	if (aInt < 0)
		aInt = 0x80000000 - aInt;
	// Make bInt lexicographically ordered as a twos-complement int
	int bInt = *(int*)&B;
	if (bInt < 0)
		bInt = 0x80000000 - bInt;

	// Now we can compare aInt and bInt to find out how far apart A and B
	// are.
	int intDiff = aInt - bInt;
	intDiff = intDiff < 0 ? -intDiff : intDiff; //abs value required

	if (intDiff <= maxUlps)
		return true;

	return false;
}

//=========================================================

inline float gFAbs(const float f)
{
	int tmp = *(int*)&f;
	tmp &= 0x7FFFFFFF; // Remove the sign bit
	return *(float*)&tmp;
}

inline float gVectDist(const t_float3 &v1, const t_float3 &v2)
{
	return sqrtf((v1.x-v2.x)*(v1.x-v2.x) + (v1.y-v2.y)*(v1.y-v2.y) +(v1.z-v2.z)*(v1.z-v2.z));
}

inline float gVectSqrDist(const t_float3 &v1, const t_float3 &v2)
{
	return ((v1.x-v2.x)*(v1.x-v2.x) + (v1.y-v2.y)*(v1.y-v2.y) +(v1.z-v2.z)*(v1.z-v2.z));
}

inline t_float3 gAddVect(const t_float3& v1, const t_float3& v2)
{
	t_float3 v;
	v.x = v1.x + v2.x; v.y = v1.y + v2.y; v.z = v1.z + v2.z;
	return v;
}

inline t_float3 gSubVect(const t_float3& v1, const t_float3& v2)
{
	t_float3 v;
	v.x = v1.x - v2.x; v.y = v1.y - v2.y; v.z = v1.z - v2.z;
	return v;
}

inline t_float3 gGetInvVect(const t_float3& v)
{
	t_float3 v2;
	v2.x = -v.x; v2.y = -v.y; v2.z = -v.z;
	return v2;
}

inline float gDotProduct(const t_float3& v1, const t_float3& v2)
{
	return v1.x*v2.x + v1.y*v2.y + v1.z*v2.z;
}

inline t_float3 gCrossProduct(const t_float3& v1, const t_float3& v2)
{
	t_float3 result;
	result.x = v1.y * v2.z  -  v1.z * v2.y;
	result.y = v1.z * v2.x  -  v1.x * v2.z;
	result.z = v1.x * v2.y  -  v1.y * v2.x;
	return result;
}

inline t_float3 gCrossProductLH(const t_float3& v1, const t_float3& v2)
{
	t_float3 result_lh = gCrossProduct(v1, v2);
	result_lh = -result_lh;
	return result_lh;
}

inline t_float3 gScalarMultVect(const t_float3& v, const float s)
{
	t_float3 v2;
	v2.x = v.x * s; v2.y = v.y * s; v2.z = v.z * s;
	return v2;
}

inline float gVectSqrMagnitude(const t_float3& v)
{
	return v.x*v.x + v.y*v.y + v.z*v.z;
}

inline float gVectMagnitude(const t_float3& v)
{
	return sqrtf(gVectSqrMagnitude(v));
}

inline t_float3 gGetNormVect(const t_float3& v)
{
	return gScalarMultVect(v, 1.f/gVectMagnitude(v));
}

inline void gNormVect(t_float3& v)
{
	float m = 1.f/gVectMagnitude(v);
	v.x *= m; v.y *= m; v.z *= m;
}

inline void gsNormVect(t_float3& v)
{
	float m = gVectMagnitude(v);
	if(m > 0.001f) {
		m = 1.f/m;
		v.x *= m; v.y *= m; v.z *= m;
	}
}

inline float gVectAngle(const t_float3& v1, const t_float3& v2)
{
	return gACos(gDotProduct(v1, v2));
}

inline float gPlaneDistance(const t_float4& pl, const t_float3& v)
{
	return pl.x*v.x + pl.y*v.y + pl.z*v.z + pl.w;
}

inline void gTranslatePlane(t_float4 &pl, const t_float3 &t)
{
	pl.w -= gDotProduct(*(t_float3*)&pl.x, t);
}

inline void gNormalizePlane(t_float4& pl)
{
	float m = 1.f/sqrtf(pl.x*pl.x+pl.y*pl.y+pl.z*pl.z);
	pl.x *= m; pl.y *= m; pl.z *= m;		
}

inline t_float4 gMakePlane(const t_float3& v1, const t_float3& v2, const t_float3& v3)
{
	t_float4 pl;

	float v1x, v1y, v1z, v2x, v2y, v2z, v3x, v3y, v3z;

	v1x = v1.x; v1y = v1.y; v1z = v1.z;
	v2x = v2.x; v2y = v2.y; v2z = v2.z;
	v3x = v3.x; v3y = v3.y; v3z = v3.z;

	// Plane equ: A*x + B*y + C*z + D = 0
	pl.x = ( v1y - v2y ) * ( v1z - v3z ) - ( v1z - v2z ) * ( v1y - v3y );
	pl.y = ( v1z - v2z ) * ( v1x - v3x ) - ( v1x - v2x ) * ( v1z - v3z );
	pl.z = ( v1x - v2x ) * ( v1y - v3y ) - ( v1y - v2y ) * ( v1x - v3x );

	gNormalizePlane(pl);

	pl.w =- ( pl.x*v1x + pl.y*v1y + pl.z*v1z);

	return pl;
}

inline t_float4 gMakePlane(const t_float3& point, const t_float3& normal)
{
	t_float4 pl;
	pl.x = normal.x;
	pl.y = normal.y;
	pl.z = normal.z;
	pl.w = -gDotProduct(point, normal);
	return pl;
}

// Matrix operations ================================================

inline void gUnitMat(t_float4x4& m)
{
	m.m00 = 1.f; m.m01 = 0.f; m.m02 = 0.f; m.m03 = 0.f;
	m.m10 = 0.f; m.m11 = 1.f; m.m12 = 0.f; m.m13 = 0.f;
	m.m20 = 0.f; m.m21 = 0.f; m.m22 = 1.f; m.m23 = 0.f;
	m.m30 = 0.f; m.m31 = 0.f; m.m32 = 0.f; m.m33 = 1.f;
}

inline void gMultMat(t_float4x4 &mat, const t_float4x4& m1, const t_float4x4& m2)
{
	// Fill local variables first, this will ensure compiler that m1 members are different than m2 members

	float m1m00 = m1.m00, m1m01 = m1.m01, m1m02 = m1.m02, m1m03 = m1.m03;
	float m1m10 = m1.m10, m1m11 = m1.m11, m1m12 = m1.m12, m1m13 = m1.m13;
	float m1m20 = m1.m20, m1m21 = m1.m21, m1m22 = m1.m22, m1m23 = m1.m23;
	float m1m30 = m1.m30, m1m31 = m1.m31, m1m32 = m1.m32, m1m33 = m1.m33;

	float m2m00 = m2.m00, m2m01 = m2.m01, m2m02 = m2.m02, m2m03 = m2.m03;
	float m2m10 = m2.m10, m2m11 = m2.m11, m2m12 = m2.m12, m2m13 = m2.m13;
	float m2m20 = m2.m20, m2m21 = m2.m21, m2m22 = m2.m22, m2m23 = m2.m23;
	float m2m30 = m2.m30, m2m31 = m2.m31, m2m32 = m2.m32, m2m33 = m2.m33;
	
	mat.m00 = m1m00*m2m00 + m1m01*m2m10
			+ m1m02*m2m20 + m1m03*m2m30;
	mat.m01 = m1m00*m2m01 + m1m01*m2m11
			+ m1m02*m2m21 + m1m03*m2m31;
	mat.m02 = m1m00*m2m02 + m1m01*m2m12
			+ m1m02*m2m22 + m1m03*m2m32;
	mat.m03 = m1m00*m2m03 + m1m01*m2m13
			+ m1m02*m2m23 + m1m03*m2m33;

	mat.m10 = m1m10*m2m00 + m1m11*m2m10
			+ m1m12*m2m20 + m1m13*m2m30;
	mat.m11 = m1m10*m2m01 + m1m11*m2m11
			+ m1m12*m2m21 + m1m13*m2m31;
	mat.m12 = m1m10*m2m02 + m1m11*m2m12
			+ m1m12*m2m22 + m1m13*m2m32;
	mat.m13 = m1m10*m2m03 + m1m11*m2m13
			+ m1m12*m2m23 + m1m13*m2m33;

	mat.m20 = m1m20*m2m00 + m1m21*m2m10
			+ m1m22*m2m20 + m1m23*m2m30;
	mat.m21 = m1m20*m2m01 + m1m21*m2m11
			+ m1m22*m2m21 + m1m23*m2m31;
	mat.m22 = m1m20*m2m02 + m1m21*m2m12
			+ m1m22*m2m22 + m1m23*m2m32;
	mat.m23 = m1m20*m2m03 + m1m21*m2m13
			+ m1m22*m2m23 + m1m23*m2m33;

	mat.m30 = m1m30*m2m00 + m1m31*m2m10
			+ m1m32*m2m20 + m1m33*m2m30;
	mat.m31 = m1m30*m2m01 + m1m31*m2m11
			+ m1m32*m2m21 + m1m33*m2m31;
	mat.m32 = m1m30*m2m02 + m1m31*m2m12
			+ m1m32*m2m22 + m1m33*m2m32;
	mat.m33 = m1m30*m2m03 + m1m31*m2m13
			+ m1m32*m2m23 + m1m33*m2m33;
}

inline void gCompMultMat3(const t_float3& r, const t_float3& d, const t_float3& s, t_float4x4& o_m)
{
#ifdef D_FAST_MATH
	float sin_X, cos_X; gSinCosf(r.x, &sin_X, &cos_X);
	float sin_Y, cos_Y; gSinCosf(r.y, &sin_Y, &cos_Y);
	float sin_Z, cos_Z; gSinCosf(r.z, &sin_Z, &cos_Z);
#else
	const float sin_X = sinf(r.x);
	const float cos_X = cosf(r.x);
	const float sin_Y = sinf(r.y);
	const float cos_Y = cosf(r.y);
	const float sin_Z = sinf(r.z);
	const float cos_Z = cosf(r.z);
#endif
	const float sin_XY = sin_X*sin_Y;
	const float cos_sin_XY = cos_X*sin_Y;

	o_m.m00 = cos_Y * cos_Z * s.x;
	o_m.m01 = cos_Y * sin_Z * s.y;
	o_m.m02 = - sin_Y * s.z;
	o_m.m10 = (sin_XY * cos_Z - cos_X * sin_Z) * s.x;
	o_m.m11 = (sin_XY * sin_Z + cos_X * cos_Z) * s.y;
	o_m.m12 = sin_X * cos_Y * s.z;
	o_m.m20 = (cos_sin_XY * cos_Z + sin_X * sin_Z) * s.x;
	o_m.m21 = (cos_sin_XY * sin_Z - sin_X * cos_Z) * s.y;
	o_m.m22 = cos_X * cos_Y * s.z;
	// translation
	o_m.m30 = d.x; o_m.m31 = d.y; o_m.m32 = d.z;
	// homogenous
	o_m.m03 = 0.f; o_m.m13 = 0.f; o_m.m23 = 0.f; o_m.m33 = 1.f;
}

// Quaternions ====================================================

inline t_quat gAddQuat(const t_quat& q1, const t_quat& q2)
{
	t_quat q;
	q.w = q1.w+q2.w;
	q.x = q1.x+q2.x;
	q.y = q1.y+q2.y;
	q.z = q1.z+q2.z;
	return q;
}

inline t_quat gSubQuat(const t_quat& q1, const t_quat& q2)
{
	t_quat q;
	q.w = q1.w-q2.w;
	q.x = q1.x-q2.x;
	q.y = q1.y-q2.y;
	q.z = q1.z-q2.z;
	return q;
}

inline t_quat gMultQuat(const t_quat& q1, const t_quat& q2)
{
	float A, B, C, D, E, F, G, H;

	A = (q1.w + q1.x)*(q2.w + q2.x);
	B = (q1.z - q1.y)*(q2.y - q2.z);
	C = (q1.x - q1.w)*(q2.y + q2.z);
	D = (q1.y + q1.z)*(q2.x - q2.w);
	E = (q1.x + q1.z)*(q2.x + q2.y);
	F = (q1.x - q1.z)*(q2.x - q2.y);
	G = (q1.w + q1.y)*(q2.w - q2.z);
	H = (q1.w - q1.y)*(q2.w + q2.z);

	t_quat res;
	res.w =   B + (-E - F + G + H) * 0.5f;
	res.x =   A - ( E + F + G + H) * 0.5f; 
	res.y = - C + ( E - F + G - H) * 0.5f;
	res.z = - D + ( E - F - G + H) * 0.5f;

	return res;
}

inline float gQuatSqrMagnitude(const t_quat& q)
{
	return q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z;
}

inline t_quat gInvQuat(const t_quat& q)
{
	float i_N = 1.f/gQuatSqrMagnitude(q);
	t_quat q2;
	q2.w =   q.w*i_N;
	q2.x = - q.x*i_N;
	q2.y = - q.y*i_N;
	q2.z = - q.z*i_N;
	return q2;
}

inline t_quat gConjQuat(const t_quat& q)
{
	t_quat q2;
	q2.w =   q.w;
	q2.x = - q.x;
	q2.y = - q.y;
	q2.z = - q.z;
	return q2;
}

inline t_quat gRollQuat(float a)
{
	a *= 0.5f;
	t_quat quat;
#ifdef D_FAST_MATH
	gSinCosf(a, &quat.x, &quat.w);
#else
	quat.w = cosf(a);
	quat.x = sinf(a);
#endif
	quat.y = quat.z = 0.f;
	return quat;
}

inline t_quat gPitchQuat(float a)
{
	a *= 0.5f;
	t_quat quat;
#ifdef D_FAST_MATH
	gSinCosf(a, &quat.y, &quat.w);
#else
	quat.w = cosf(a);
	quat.y = sinf(a);
#endif
	quat.x = quat.z = 0.f;
	return quat;
}

inline t_quat gYawQuat(float a)
{
	a *= 0.5f;
	t_quat quat;
#ifdef D_FAST_MATH
	gSinCosf(a, &quat.z, &quat.w);
#else
	quat.w = cosf(a);
	quat.z = sinf(a);
#endif
	quat.x = quat.y = 0.f;
	return quat;
}

inline void gEuler2Quat(float roll, float pitch, float yaw, t_quat &quat)
{
	float cr, cp, cy, sr, sp, sy, cpcy, spsy;

	roll *= 0.5f; pitch *= 0.5f; yaw *= 0.5f;

#ifdef D_FAST_MATH
	gSinCosf(roll, &sr, &cr);
	gSinCosf(pitch, &sp, &cp);
	gSinCosf(yaw, &sy, &cy);
#else
	cr = cosf(roll); cp = cosf(pitch); cy = cosf(yaw);
	sr = sinf(roll); sp = sinf(pitch); sy = sinf(yaw);
#endif

	cpcy = cp * cy;
	spsy = sp * sy;

	quat.w = cr * cpcy + sr * spsy;
	quat.x = sr * cpcy - cr * spsy;
	quat.y = cr * sp * cy + sr * cp * sy;
	quat.z = cr * cp * sy - sr * sp * cy;
}

inline void gAxisRot2Quat(const t_float3& axis, float angle, t_quat &quat)
{	 
	angle *= 0.5f;
#ifdef D_FAST_MATH
	float sin_angle;
	gSinCosf(angle, &sin_angle, &quat.w);
#else
	quat.w = cosf(angle);
	const float sin_angle = sinf(angle);
#endif
	quat.x = axis.x * sin_angle;
	quat.y = axis.y * sin_angle;
	quat.z = axis.z * sin_angle;
}

inline void gAxisRot2Mat(const t_float3& axis, float angle, t_float4x4& mat)
{
	gUnitMat(mat);

#ifdef D_FAST_MATH
	float sin_angle, cos_angle;
	gSinCosf(angle, &sin_angle, &cos_angle);
#else
	const float cos_angle = cosf(angle);
	const float sin_angle = sinf(angle);
#endif

	float t = 1 - cos(angle);

	mat.m00 = t * axis.x * axis.x + cos_angle;
	mat.m01 = t * axis.x * axis.y + sin_angle * axis.z;
	mat.m02 = t * axis.x * axis.z - sin_angle * axis.y;

	mat.m10 = t * axis.x * axis.y - sin_angle * axis.z;
	mat.m11 = t * axis.y * axis.y + cos_angle;
	mat.m12 = t  * axis.y * axis.z + sin_angle *  axis.x;

	mat.m30 = t * axis.x * axis.z + sin_angle * axis.y;
	mat.m31 = t * axis.y * axis.z - sin_angle * axis.x;
	mat.m32 = t * axis.z * axis.z + cos_angle;
}

inline t_float3 gQuatRotate(const t_quat &quat, const t_float3 &v)
{
	t_quat q1, q2;
	q2.w = 0.f; q2.x = v.x; q2.y = v.y; q2.z = v.z;
	q1 = gMultQuat(quat, q2);
	q2 = gMultQuat(q1, gConjQuat(quat));
	t_float3 res;
	res.x = q2.x; res.y = q2.y; res.z = q2.z;
	return res;
}

inline t_float3 gQuatRotate2(const t_quat &quat, const t_float3 &v)
{
	t_quat q1, q2;
	q2.w = 0.f; q2.x = v.x; q2.y = v.y; q2.z = v.z;
	q1 = gMultQuat(gConjQuat(quat), q2);
	q2 = gMultQuat(q1, quat);
	t_float3 res; res.x = q2.x; res.y = q2.y; res.z = q2.z;
	return res;
}

#define C_QUAT_DELTA	0.00001f

inline void gQuatSlerp(const t_quat &from, const t_quat &to, const float t, t_quat &res)
{
	float to1[4], scale0, scale1;

	// calc cosine
	float cosom = from.x * to.x + from.y * to.y + from.z * to.z + from.w * to.w;

	// adjust signs (if necessary)
	if(cosom < 0.f)
	{
		cosom = -cosom;
		to1[0] = - to.x; to1[1] = - to.y; to1[2] = - to.z; to1[3] = - to.w;
	} 
	else
	{
		to1[0] = to.x; to1[1] = to.y; to1[2] = to.z; to1[3] = to.w;
	}

	// calculate coefficients

	if((1.f - cosom) > C_QUAT_DELTA)
	{
		// standard case (slerp)
		float omega = acosf(cosom);
		float sinom = sinf(omega);
		scale0 = sinf((1.f - t) * omega) / sinom;
		scale1 = sinf(t * omega) / sinom;
	}
	else
	{
		// "from" and "to" quaternions are very close 
		//  ... so we can do a linear interpolation
		scale0 = 1.f - t;
		scale1 = t;
	}

	// calculate final values
	res.x = scale0 * from.x + scale1 * to1[0];
	res.y = scale0 * from.y + scale1 * to1[1];
	res.z = scale0 * from.z + scale1 * to1[2];
	res.w = scale0 * from.w + scale1 * to1[3];
}

extern void gMatrix2Quat(const t_float4x4 &m, t_quat &quat);
extern void gQuat2Matrix(const t_quat &quat, t_float4x4 &m);

extern void gPosQuatScale2Matrix(const t_float3 &pos, const t_quat &quat, const t_float3 &scale, t_float4x4 &m);
extern void gPosQuat2Matrix(const t_float3 &pos, const t_quat &quat, t_float4x4 &m);

//! Compute a rotation matrix which transforms one vector into another.
extern void gVect2VectRotMat(const t_float3& v1, const t_float3& v2, t_float4x4& mat);

inline t_float3 gMultVectTMat(const t_float3 &v, const t_float4x4 &m)
{
	t_float3 res;

	res.x = v.x*m.m00 + v.y*m.m10 + v.z*m.m20 + m.m30;
	res.y = v.x*m.m01 + v.y*m.m11 + v.z*m.m21 + m.m31;
	res.z = v.x*m.m02 + v.y*m.m12 + v.z*m.m22 + m.m32;

	return res;
}

inline t_float3 gMultVectInvTMat(const t_float3 &v, const t_float4x4 &m)
{
	t_float3 v2, res;

	// Translation, then rotation

	// Minus translation
	v2.x = v.x - m.m30; v2.y = v.y - m.m31; v2.z = v.z - m.m32;
	// Translate the rotation part
	res.x = v2.x*m.m00 + v2.y*m.m01 + v2.z*m.m02;
	res.y = v2.x*m.m10 + v2.y*m.m11 + v2.z*m.m12;
	res.z = v2.x*m.m20 + v2.y*m.m21 + v2.z*m.m22;

	return res;
}

inline t_float3 gMultVectInvRotMat(const t_float3 &v, const t_float4x4 &m)
{
	t_float3 res;

	// Translate the rotation part
	res.x = v.x*m.m00 + v.y*m.m01 + v.z*m.m02;
	res.y = v.x*m.m10 + v.y*m.m11 + v.z*m.m12;
	res.z = v.x*m.m20 + v.y*m.m21 + v.z*m.m22;

	return res;
}

inline void gInvTMat(t_float4x4& o_res, const t_float4x4& m)
{
	// transpose of the rotation part
	o_res.m01 = m.m10; o_res.m10 = m.m01;
	o_res.m02 = m.m20; o_res.m20 = m.m02;
	o_res.m12 = m.m21; o_res.m21 = m.m12;

	o_res.m00 = m.m00; o_res.m11 = m.m11; o_res.m22 = m.m22;

	o_res.m03 = o_res.m13 = o_res.m23 = 0.f; o_res.m33 = 1.f;

	// negation of translation
	o_res.m30 = -m.m30; o_res.m31 = -m.m31; o_res.m32 = -m.m32;
}

inline void gCompInvMat(const t_float4x4& m, t_float4x4 &o_m)
{
	float det;
	float d12, d13, d23, d24, d34, d41;

#define m11 m.m[0][0]
#define m12 m.m[1][0]
#define m13 m.m[2][0]
#define m14 m.m[3][0]
#define m21 m.m[0][1]
#define m22 m.m[1][1]
#define m23 m.m[2][1]
#define m24 m.m[3][1]
#define m31 m.m[0][2]
#define m32 m.m[1][2]
#define m33 m.m[2][2]
#define m34 m.m[3][2]
#define m41 m.m[0][3]
#define m42 m.m[1][3]
#define m43 m.m[2][3]
#define m44 m.m[3][3]

	// Pre-compute 2x2 dets for last two rows when computing.

	// Cofactors of first two rows.
	d12 = (m31*m42-m41*m32);
	d13 = (m31*m43-m41*m33);
	d23 = (m32*m43-m42*m33);
	d24 = (m32*m44-m42*m34);
	d34 = (m33*m44-m43*m34);
	d41 = (m34*m41-m44*m31);

	o_m.m[0][0] = (m22 * d34 - m23 * d24 + m24 * d23);
	o_m.m[0][1] = -(m21 * d34 + m23 * d41 + m24 * d13);
	o_m.m[0][2] = (m21 * d24 + m22 * d41 + m24 * d12);
	o_m.m[0][3] = -(m21 * d23 - m22 * d13 + m23 * d12);

	// Compute determinant as early as possible using these cofactors.
	det = m11 * o_m.m[0][0]  + m12 * o_m.m[0][1] + m13 * o_m.m[0][2] + m14 * o_m.m[0][3];

	// Run singularity test.
	if (det == 0.f) 
	{
		gUnitMat(o_m);
	}
	else 
	{
		float invDet = 1.f / det;
		// Compute rest of inverse.
		o_m.m[0][0] *= invDet;
		o_m.m[0][1] *= invDet;
		o_m.m[0][2] *= invDet;
		o_m.m[0][3] *= invDet;

		o_m.m[1][0] = -(m12 * d34 - m13 * d24 + m14 * d23) * invDet;
		o_m.m[1][1] =  (m11 * d34 + m13 * d41 + m14 * d13) * invDet;
		o_m.m[1][2] = -(m11 * d24 + m12 * d41 + m14 * d12) * invDet;
		o_m.m[1][3] =  (m11 * d23 - m12 * d13 + m13 * d12) * invDet;

		// Pre-compute 2x2 dets for first two rows when computing cofactors of last two rows.
		d12 = m11*m22-m21*m12;
		d13 = m11*m23-m21*m13;
		d23 = m12*m23-m22*m13;
		d24 = m12*m24-m22*m14;
		d34 = m13*m24-m23*m14;
		d41 = m14*m21-m24*m11;

		o_m.m[2][0] =  (m42 * d34 - m43 * d24 + m44 * d23) * invDet;
		o_m.m[2][1] = -(m41 * d34 + m43 * d41 + m44 * d13) * invDet;
		o_m.m[2][2] =  (m41 * d24 + m42 * d41 + m44 * d12) * invDet;
		o_m.m[2][3] = -(m41 * d23 - m42 * d13 + m43 * d12) * invDet;
		o_m.m[3][0] = -(m32 * d34 - m33 * d24 + m34 * d23) * invDet;
		o_m.m[3][1] =  (m31 * d34 + m33 * d41 + m34 * d13) * invDet;
		o_m.m[3][2] = -(m31 * d24 + m32 * d41 + m34 * d12) * invDet;
		o_m.m[3][3] =  (m31 * d23 - m32 * d13 + m33 * d12) * invDet;
	}

#undef m11
#undef m12
#undef m13
#undef m14
#undef m21
#undef m22
#undef m23
#undef m24
#undef m31
#undef m32
#undef m33
#undef m34
#undef m41
#undef m42
#undef m43
#undef m44
}


// Curves ====================================================

//! Compute the position of a point on an interpolation curve described by the Hermite polynomial functions
inline void gHermiteGetPoint(const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1, t_float3& p)
{
	p.x = p0.x + t0.x * t + (-3 * p0.x + 3 * p1.x - 2 * t0.x - t1.x) * t * t + (2 * p0.x - 2 * p1.x + t0.x + t1.x) * t * t * t;
	p.y = p0.y + t0.y * t + (-3 * p0.y + 3 * p1.y - 2 * t0.y - t1.y) * t * t + (2 * p0.y - 2 * p1.y + t0.y + t1.y) * t * t * t;
	p.z = p0.z + t0.z * t + (-3 * p0.z + 3 * p1.z - 2 * t0.z - t1.z) * t * t + (2 * p0.z - 2 * p1.z + t0.z + t1.z) * t * t * t;
}

inline void gHermiteGetFirstDerivative(const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1, t_float3& p)
{
	p.x = t0.x + ( - 6 * p0.x + 6 * p1.x - 4 * t0.x - 2 * t1.x) * t + (6 * p0.x - 6 * p1.x + 3 * t0.x + 3 * t1.x ) * t * t;
	p.y = t0.y + ( - 6 * p0.y + 6 * p1.y - 4 * t0.y - 2 * t1.y) * t + (6 * p0.y - 6 * p1.y + 3 * t0.y + 3 * t1.y ) * t * t;
	p.z = t0.z + ( - 6 * p0.z + 6 * p1.z - 4 * t0.z - 2 * t1.z) * t + (6 * p0.z - 6 * p1.z + 3 * t0.z + 3 * t1.z ) * t * t;
}

inline void gHermiteGetSecondDerivative(const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1, t_float3& p)
{
	p.x = ( -6 * p0.x + 6 * p1.x - 4 * t0.x - 2 * t1.x ) + (12 * p0.x - 12 * p1.x + 6 * t0.x + 6 * t1.x ) * t;
	p.y = ( -6 * p0.y + 6 * p1.y - 4 * t0.y - 2 * t1.y ) + (12 * p0.y - 12 * p1.y + 6 * t0.y + 6 * t1.y ) * t;
	p.z = ( -6 * p0.z + 6 * p1.z - 4 * t0.z - 2 * t1.z ) + (12 * p0.z - 12 * p1.z + 6 * t0.z + 6 * t1.z ) * t;
}

//! Compute the tangent of a point on an interpolation curve described by the Hermite polynomial functions
inline void gHermiteGetTangent(const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1, t_float3& tangent)
{
	//The tangent is the normalization of the first derivative
	gHermiteGetFirstDerivative(t, t0, p0, p1, t1, tangent);
	gNormVect(tangent);
}

//! Compute the normal vector of a point on an interpolation curve described by the Hermite polynomial functions
inline void gHermiteGetNormal(const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1, t_float3& normal)
{
	t_float3 fd, sd;
	gHermiteGetFirstDerivative(t, t0, p0, p1, t1, fd);
	gHermiteGetSecondDerivative(t, t0, p0, p1, t1, sd);

	float fdp = gDotProduct(fd, fd);
	float sdp = gDotProduct(fd, sd);

	normal = gGetNormVect( gSubVect( gScalarMultVect( sd, fdp ), gScalarMultVect( fd, sdp ) ) ); 
}


inline float gCatmullRomGetValue(const float& tension, const float&t, const float& t0, const float& p0, const float& p1, const float& t1)
{
	return p0 + tension * (p1 - t0) * t + (3.f * (p1 - p0) - tension * (t1 - p0) - 2.f * tension * (p1 - t0)) * t * t + (-2.f * (p1 - p0) + tension * (t1 - p0) + tension * (p1 - t0)) * t * t * t;
}

//! This function computes the Catmull-Rom interpolation value for the given factor and control points.
inline t_float3 gCatmullRomGetPoint(const float& tension, const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1)
{
	t_float3 result;

	result.x = p0.x + tension * (p1.x - t0.x) * t + (3.f * (p1.x - p0.x) - tension * (t1.x - p0.x) - 2.f * tension * (p1.x - t0.x)) * t * t + (-2.f * (p1.x - p0.x) + tension * (t1.x - p0.x) + tension * (p1.x - t0.x)) * t * t * t;
	result.y = p0.y + tension * (p1.y - t0.y) * t + (3.f * (p1.y - p0.y) - tension * (t1.y - p0.y) - 2.f * tension * (p1.y - t0.y)) * t * t + (-2.f * (p1.y - p0.y) + tension * (t1.y - p0.y) + tension * (p1.y - t0.y)) * t * t * t;
	result.z = p0.z + tension * (p1.z - t0.z) * t + (3.f * (p1.z - p0.z) - tension * (t1.z - p0.z) - 2.f * tension * (p1.z - t0.z)) * t * t + (-2.f * (p1.z - p0.z) + tension * (t1.z - p0.z) + tension * (p1.z - t0.z)) * t * t * t;

	return result;
}

inline t_float3 gCatmullRomGetFirstDerivative(const float& tension, const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1)
{
	t_float3 result;

	result.x = tension * (p1.x - t0.x) + (6.f * (p1.x - p0.x) - 2.f * tension * (t1.x - p0.x) - 4.f * tension * (p1.x - t0.x)) * t + (-6.f * (p1.x - p0.x) + 3.f * tension * (t1.x - p0.x) + 3.f * tension * (p1.x - t0.x)) * t * t;
	result.y = tension * (p1.y - t0.y) + (6.f * (p1.y - p0.y) - 2.f * tension * (t1.y - p0.y) - 4.f * tension * (p1.y - t0.y)) * t + (-6.f * (p1.y - p0.y) + 3.f * tension * (t1.y - p0.y) + 3.f * tension * (p1.y - t0.y)) * t * t;
	result.z = tension * (p1.z - t0.z)  + (6.f * (p1.z - p0.z) - 2.f * tension * (t1.z - p0.z) - 4.f * tension * (p1.z - t0.z)) * t + (-6.f * (p1.z - p0.z) + 3.f * tension * (t1.z - p0.z) + 3.f * tension * (p1.z - t0.z)) * t * t;

	return result;
}

//! This function computes the tangent vector for the interpolation position given by t and the control points.
inline t_float3 gCatmullRomGetSecondDerivative(const float& tension, const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1)
{
	t_float3 result;

	result.x = (6.f * (p1.x - p0.x) - 2.f * tension * (t1.x - p0.x) - 4.f * tension * (p1.x - t0.x)) + (-12.f * (p1.x - p0.x) + 6.f * tension * (t1.x - p0.x) + 6.f * tension * (p1.x - t0.x)) * t ;
	result.y = (6.f * (p1.y - p0.y) - 2.f * tension * (t1.y - p0.y) - 4.f * tension * (p1.y - t0.y)) + (-12.f * (p1.y - p0.y) + 6.f * tension * (t1.y - p0.y) + 6.f * tension * (p1.y - t0.y)) * t ;
	result.z = (6.f * (p1.z - p0.z) - 2.f * tension * (t1.z - p0.z) - 4.f * tension * (p1.z - t0.z)) + (-12.f * (p1.z - p0.z) + 6.f * tension * (t1.z - p0.z) + 6.f * tension * (p1.z - t0.z)) * t ;

	return result;

}

//! This function computes the tangent vector for the interpolation position given by t and the control points.
inline t_float3 gCatmullRomGetTangent(const float& tension, const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1)
{
	//The tangent is the normalization of the first derivative
	return gGetNormVect( gCatmullRomGetFirstDerivative(tension, t, t0, p0, p1, t1 ) );
}

inline t_float3 gCatmullRomGetNormal(const float& tension, const float& t, const t_float3& t0, t_float3& p0, t_float3& p1, t_float3& t1)
{
	t_float3 fd = gCatmullRomGetFirstDerivative(tension, t, t0, p0, p1, t1);
	t_float3 sd = gCatmullRomGetSecondDerivative(tension, t, t0, p0, p1, t1);

	float fdp = gDotProduct(fd, fd);
	float sdp = gDotProduct(fd, sd);

	return gGetNormVect( gSubVect( gScalarMultVect( sd, fdp ), gScalarMultVect( fd, sdp ) ) );
}

//! Get the interpolated position of a point on a bezier patch defined by equidistant control points, given the patch parameters
inline float gBezierGetValue(const float u, float v, float* cp)
{
//Basis functions (Bernstein polynomials)
#define B0(t) ((1.0f - t) * (1.0f - t) * (1.0f - t))
#define B1(t) (3.0f * t * (1.0f - t) * (1.0f - t))
#define B2(t) (3.0f * t * t * (1.0f - t))
#define B3(t) (t * t * t)

//Derivatives of the basis functions
#define dB0(t) ((6.0f * t) - (3.0f * t * t) - 3.0f)
#define dB1(t) (3.0f - (12.0f * t) + (9.0f * t * t))
#define dB2(t) ((6.0f * t) - (9.0f * t * t))
#define dB3(t) (3.0f * t * t)

	return	B0(u) * ( B0(v)  * cp[0]  + B1(v)  * cp[4]  + B2(v)  * cp[8] + B3(v)  * cp[12]) + 
				B1(u) * ( B0(v)  * cp[1]  + B1(v)  * cp[5]  + B2(v)  * cp[9] + B3(v)  * cp[13]) + 
				B2(u) * ( B0(v)  * cp[2]  + B1(v)  * cp[6]  + B2(v)  * cp[10] + B3(v)  * cp[14]) + 
				B3(u) * ( B0(v)  * cp[3]  + B1(v)  * cp[7]  + B2(v)  * cp[11] + B3(v)  * cp[15]);

#undef B0
#undef B1
#undef B2
#undef B3
#undef dB0
#undef dB1
#undef dB2
#undef dB3
}

//====================================================

//! Class template for computing the barycentric coordinates of a point relative to a given triangle. 

/*! Typically, this class will be instantiated for either <float> or <double> type, depending on the desired precision.

This code precomputes and stores data that speed up computing
the barycentric coordinates. This is particularly useful when
repeatedly evaluating different points on the same triangle.

Based on a code by Ivan Neulander.
*/
template <class T> class cBarycentric 
{
	int _proj; //!< Which dimension we discard.

	T _v0[3];  //!< Original position of point that we moved to the origin.

	T _v1[2];  //!< The other two points with one dimension discarded.
	T _v2[2]; 

	T _bv1[2]; //!< Precomputed precursor to barycentric.
	T _bv2[2];

public:

	cBarycentric() { Init(); }

	cBarycentric(const T *v0, const T *v1, const T *v2) 
	{ Init(v0, v1, v2); }

	static void Diff(const T *a, const T *b, T *res) 
	{
		res[0] = a[0] - b[0];
		res[1] = a[1] - b[1];
		res[2] = a[2] - b[2];
	}

	void Init() 
	{
		_proj = -1;
		_v0[0] = _v0[1] = _v0[2] = 0;
		_v1[0] =_v1[1] = 0;
		_v2[0] =_v2[1] = 0;
		_bv1[0] =_bv1[1] = 0;
		_bv2[0] =_bv2[1] = 0;
	}

	/*! Call this to specify the 3 verts of the triangle for which barycentric coordinates are to be computed. */
	void Init(const T *iv0, const T *iv1, const T *iv2)
	{
		// Invoke this method before evaluating or testing any barycentric
		// coords. It reads in the verts (iv0, iv1, iv2) of the triangle to
		// be used as a basis for barycentric coordinates, and precomputes
		// needed information. Returns 'true' if triangle is valid, false
		// otherwise.

		T v1[3], v2[3];

		Init();

		// copy iv0
		_v0[0] = iv0[0];
		_v0[1] = iv0[1];
		_v0[2] = iv0[2];

		// translate everything to place iv0 at origin
		Diff(iv1, iv0, v1);
		Diff(iv2, iv0, v2);

		// The system we're solving is overdetermined; We solve using one of
		// the following projections: (y,z), (z,x), (x,y): namely, the one
		// that yields the biggest determinant. So we just need to decide
		// which dimension to discard.

		T det0 = v1[1]*v2[2] - v2[1]*v1[2];
		T det1 = v1[2]*v2[0] - v2[2]*v1[0];
		T det2 = v1[0]*v2[1] - v2[0]*v1[1];

		T adet0 = fabs(det0);
		T adet1 = fabs(det1);
		T adet2 = fabs(det2);

		// Pick proj according to the biggest among adet0, adet1, adet2.
		// Note that if they're all zero, then proj will be assigned 2, so
		// that's the only case where we need to check before dividing by
		// adet2.
		int proj = adet0 > adet1 ? 
			(adet0 > adet2 ? 0 : 2) : (adet1 > adet2 ? 1 : 2);

		T detInv;
		switch(proj) 
		{
		case 0:
			detInv = 1 / det0;
			_proj = 0;

			_bv1[0] = detInv*v1[1];
			_bv1[1] = detInv*v1[2];
			_bv2[0] = detInv*v2[1];
			_bv2[1] = detInv*v2[2];

			_v1[0] = v1[1];
			_v1[1] = v1[2];
			_v2[0] = v2[1];
			_v2[1] = v2[2];

			break;

		case 1:
			detInv = 1/det1;
			_proj = 1;

			_bv1[0] = detInv*v1[2];
			_bv1[1] = detInv*v1[0];
			_bv2[0] = detInv*v2[2];
			_bv2[1] = detInv*v2[0];

			_v1[0] = v1[2];
			_v1[1] = v1[0];
			_v2[0] = v2[2];
			_v2[1] = v2[0];

			break;

		case 2:
			if(adet2 == 0) return;

			detInv = 1/det2;
			_proj = 2;

			_bv1[0] = detInv*v1[0];
			_bv1[1] = detInv*v1[1];
			_bv2[0] = detInv*v2[0];
			_bv2[1] = detInv*v2[1];

			_v1[0] = v1[0];
			_v1[1] = v1[1];
			_v2[0] = v2[0];
			_v2[1] = v2[1];

			break;
		}
	}

	/*! True iff a non-degenerate triangle has been specified using constructor or Init(). */
	bool IsValid() const { return _proj >= 0; }

	/*! Attempts to compute barycentric coords of point 'pos' relative
	to the triangle specified using constructor or Init().  This
	method works even if the point lies outside triangle; however
	the point must always be coplanar with the triangle. Returns
	true on success, false on failure (i.e. triangle is
	degenerate or uninitialized). */
	bool Eval(const T *pos, T *bary) 
	{
		T p0, p1;
		switch(_proj) {
	case 0:
		p0 = pos[1] - _v0[1];
		p1 = pos[2] - _v0[2];
		break;
	case 1:
		p0 = pos[2] - _v0[2];
		p1 = pos[0] - _v0[0];
		break;
	case 2:
		p0 = pos[0] - _v0[0];
		p1 = pos[1] - _v0[1];
		break;
	default:
		return false;
		}

		bary[1] = _bv2[1]*p0 - _bv2[0]*p1;
		bary[2] = _bv1[0]*p1 - _bv1[1]*p0;
		bary[0] = 1 - bary[1] - bary[2];

		return true;
	}

	/*! This is an optimized version of Eval(). It only computes
	barycentric coordinates if point 'pos' lies within the
	triangle. If so, it returns true. Otherwise it returns
	false. As with Eval(), it assumes that 'pos' is coplanar with
	triangle. */
	bool Test(const T *pos, T *bary, T min = 0, T max = 1) 
	{
		T p0, p1;

		switch(_proj) {
	case 0:
		p0 = pos[1] - _v0[1];
		p1 = pos[2] - _v0[2];
		break;
	case 1:
		p0 = pos[2] - _v0[2];
		p1 = pos[0] - _v0[0];
		break;
	case 2:
		p0 = pos[0] - _v0[0];
		p1 = pos[1] - _v0[1];
		break;
	default:
		return false;
		}

		bary[1] = _bv2[1]*p0 - _bv2[0]*p1;
		if (bary[1] < min || bary[1] > max) return false;

		bary[2] = _bv1[0]*p1 - _bv1[1]*p0;
		if (bary[2] < min || bary[2] > max) return false;

		bary[0] = 1 - bary[1] - bary[2];
		return bary[0] >= min;
	}

	void GetBarycentricPos(const float *vert1, const float *vert2, const float *vert3, const float *bary_points, float *o_pos)
	{
		o_pos[0] = bary_points[0] * vert1[0] + bary_points[1] * vert2[0] + bary_points[2] * vert3[0];
		o_pos[1] = bary_points[0] * vert1[1] + bary_points[1] * vert2[1] + bary_points[2] * vert3[1];
		o_pos[2] = bary_points[0] * vert1[2] + bary_points[1] * vert2[2] + bary_points[2] * vert3[2];
	}

};


//=========================================================

}
#endif
/*@}*/