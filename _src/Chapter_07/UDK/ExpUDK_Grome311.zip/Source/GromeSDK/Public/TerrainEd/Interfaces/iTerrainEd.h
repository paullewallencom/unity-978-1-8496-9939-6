//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINED_H
#define __CSDK_ITERRAINED_H


#include "../../Editor/Interfaces/iEditorLayer.h"
#include "iTerrainEdProject.h"
#include "iTerrainZone.h"

namespace csdk {

//====================================================

//! Name used to register the iTerrainEd interface with the SDK root.
#define C_TERRAINED_INTERFACE_NAME		"Terrain Editor"

//! SDK interface to terrain editor engine node.
/*! This interface can be obtained from the SDK root interface with a call to 
iRootInterface::GetInterface with C_TERRAINED_INTERFACE_NAME as name. */
class iTerrainEd: public iSdkInterface
{
public:
	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char*		TypeString() { return "iTerrainEd"; }

	virtual const char*		Name() { return C_TERRAINED_INTERFACE_NAME; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char*		Description() { return "Terrain editor module"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to the current working terrain project.
	virtual iTerrainEdProject* GetCurrProject() = 0;
	
	//! Update the terrain surface for the current project after it has been modified.
	virtual t_error		UpdateSurface() = 0;
	
	//! Get the height value from an world position
	virtual float			GetHeight(float x, float z) = 0;

	//! Get the height value from the specified position, by inspecting the currently selected zones.
	virtual float			GetSelectionHeight(float x, float z) = 0;
	
	//! Add a cluster of terrain zones to the current active project
	/*! This function is used to add a compact cluster of terrain zones to the active project.
		\param name Every zone in the cluster is given this name after creation;
		\param zones_u The number of zones along the width of the cluster (aligned with world X axis);
		\param zones_v The number of zones along the height of the cluster (aligned with world Z axis);
		\param tile_no The tile number for each zone in the cluster.
		\param tile_size The tile size for each zone in the cluster.
		\param position The center position of the cluster in world space.
		\param zones This list is filled with interfaces from each zone from the new cluster (it must be allocated by the caller).
	*/
	virtual t_error		AddTerrainZones(const t_char *name, uint zones_u, uint zones_v, uint tile_no, float tile_size,
											t_float3 position, iTerrainZone** zones) = 0;

	//! Delete terrain zones.
	/*! After deletion, the zones interfaces are still valid and must be closed by the client but they
	will point to blank zones (all their operations have no effect).
	\param zones_no Number of zones in the zones array.
	\param zones Array with pointers to terrain zones. 
	\param del_objects Objects on the terrain should be deleted or not. */
	virtual t_error		DeleteTerrainZones(uint zones_no, iTerrainZone** zones, t_bool del_objects) = 0;

	//! Move an editor layer to a new position within its stack.
	/*! This function is used to change the position of an editor layer.
		\param layer The layer to be moved;
		\param position The new position which the layer needs to be moved at.
	*/
	virtual t_error		MoveLayer(iEditorLayer* layer, uint position) = 0;

	//! Add a new layer to the current terrain project.
	/*! The method adds a new layer of the given type into the specified position.
		\param type The type string of the layer to be added
		\param name The name of the layer. If this parameter is NULL, a default name will be used according to the layer type.
		\param id The position of the new layer. If this parameter is -1, the layer will be added on top of its layer stack.
	*/
	virtual iEditorLayer*		AddLayer(const char* type, const t_char* name, int id) = 0;

	//! Return an interface to a terrain editor layer, based on the desired layer type and position in the terrain layer stack.
	/*!	The function searches for the specified layer type stack in the terrain editor scene and returns the layer indicated by the position id.
	The interface needs to be closed with a call to CloseInterface when no longer needed.
		\param type The type string of the layer
		\param id The position id of the layer in its stack (0 being bottommost)
	*/
	virtual iEditorLayer*		GetLayer(const char* type, uint id) = 0;

	//! Return the number of layers given the stack type
	/*!	The function returns the number of valid layers on the stack specified by the layer interface type
		\param type The type string of the layer.
	*/
	virtual uint					GetLayersNo(const char* type) = 0;

	//! Get the zones contained within a given rectangular area
	virtual t_error			GetTerrainZones(const t_float3& min, const t_float3& max, t_array<iTerrainZone*>*  zones, t_bool get_swapped) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/