//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file TerrainEd/sdk.h
	\brief Terrain Editor SDK includes.

	Copyright (C) 2005-2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_TERRAINED_SDK_H
#define __CSDK_TERRAINED_SDK_H

//===========================================================

// Include Editor SDK header.
#include "../Editor/sdk.h"

#include "Interfaces/iTerrainEd.h"
#include "Interfaces/iTerrainZone.h"
#include "Interfaces/iTerrainHeightmap.h"
#include "Interfaces/iTerrainMaterialLayer.h"
#include "Interfaces/iTerrainDetailsLayer.h"
#include "Interfaces/iTerrainObjectsLayer.h"
#include "Interfaces/iTerrainSelectionmap.h"
#include "Interfaces/iTerrainRoadLayer.h"
#include "Interfaces/iTerrainMeshLayer.h"
#include "Interfaces/iTerrainDecalLayer.h"
#include "Plugins/iTriggerPlugin.h"

//===========================================================
#endif
/*@}*/