//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINSELECTIONMAP_H
#define __CSDK_ITERRAINSELECTIONMAP_H

#include "../../Editor/Interfaces/iEditorLayer.h"
#include "../../Engine/Interfaces/iPropertyTableOwner.h"
#include "iTerrainZone.h"

namespace csdk {

//====================================================

//! SDK interface to terrain editor engine node.
class iTerrainSelectionmap: public iEditorLayer
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainSelectionmap"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain editor selectionmap layer"; }
	
	//! Return the interface to browse the per layer properties (for a specific zone).
	/*! \warning The returned interface is shared among calls. So if you call this function
	for a zone and then you call it again, the same interface pointer is used but it will
	reflect the properties for the second zone. */
	virtual iPropertyTableOwner* GetProperties(iTerrainZone* zone) = 0;

	//! Return the selection data for a specified terrain zone into an allocated buffer.
	virtual t_error	GetData(csdk::iTerrainZone* zone, float* buffer) = 0;

	//! Copy the selection data to the specified zone layer.
	virtual t_error	SetData(csdk::iTerrainZone* zone, const float* buffer) = 0;

	//! Get a single selection value from this layer for the specified zone and vertex position inside the zone.
	virtual float		GetValue(csdk::iTerrainZone* zone, csdk::uint u, csdk::uint v) = 0;

	//! Set a single selection value from this layer for the specified zone and vertex position inside the zone.
	virtual t_error	SetValue(csdk::iTerrainZone* zone, csdk::uint u, csdk::uint v, float value) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/