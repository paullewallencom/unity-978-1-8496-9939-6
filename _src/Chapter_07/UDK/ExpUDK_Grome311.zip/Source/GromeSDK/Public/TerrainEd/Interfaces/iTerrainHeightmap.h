//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINHEIGHTMAP_H
#define __CSDK_ITERRAINHEIGHTMAP_H

#include "../../Editor/Interfaces/iEditorLayer.h"
#include "../../Engine/Interfaces/iPropertyTableOwner.h"
#include "iTerrainZone.h"


namespace csdk {

//====================================================

//! Heightmap operation types
enum E_HMAP_OPERATIONS
{
	//!< Default heightmap stack operation, hmap values are added to stack contents
	C_HMAP_ADD = 0,

	//!< Level heightmaps overwrite the contents of the stack with the absolute heightmap values stored in the layer.
	/*! The level heightmaps store the relevant surface data in values that are different from FLT_MAX. The surface portions which have the special value FLT_MAX will
	be discarded when computing the heightmap stack, revealing the contents of the stack beneath the level heightmap.*/
	C_HMAP_LVL
};

//! Heightmap layer specific flags
#define F_LAYER_TEMP			0x01//!< The layer is not persistent (will not be saved with the zone, it is created at runtime using the data provided by a different layer stack)


//====================================================


//! SDK interface to terrain editor engine node.
class iTerrainHeightmap: public iEditorLayer
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainHeightmap"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain editor heightmap layer"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to browse the per layer properties (for a specific zone).
	/*! \warning The returned interface is shared among calls. So if you call this function
	for a zone and then you call it again, the same interface pointer is used but it will
	reflect the properties for the second zone. */
	virtual iPropertyTableOwner* GetProperties(iTerrainZone* zone) = 0;

	//! Return the heightmap data for a specified terrain zone into an allocated buffer.
	/*! This function copies the contents of the data assigned to the specified zone into the allocated buffer, supplied as parameter.
		The buffer must be large enough to store the data.
	*/
	virtual t_error	GetData(iTerrainZone* zone, float* buffer) = 0;

	//! Copy the heightmap data to the specified zone layer.
	/*! This function copies the heightmap data from the buffer supplied as parameter to the layer data assigned to the specified zone.
		The buffer must hold enough data to fill the zone layer.
	*/
	virtual t_error	SetData(iTerrainZone* zone, const float* buffer) = 0;

	//! Get a single heightmap value from this layer for the specified zone and vertex position inside the zone.
	virtual float	GetValue(iTerrainZone* zone, csdk::uint u, csdk::uint v) = 0;

	//! Set a single heightmap value from this layer for the specified zone and vertex position inside the zone.
	virtual t_error	SetValue(iTerrainZone* zone, csdk::uint u, csdk::uint v, float value) = 0;

	//! Assign the heightmap layer to the specified zone.
	virtual t_error	Assign(iTerrainZone* zone) = 0;

	//! Get the heightmap operation type for the specified terrain zone
	virtual E_HMAP_OPERATIONS GetHmapOperation(iTerrainZone* zone) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/