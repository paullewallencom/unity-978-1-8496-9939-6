//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINMESHLAYER_H
#define __CSDK_ITERRAINMESHLAYER_H

#include "../../Editor/Interfaces/iEditorLayer.h"
#include "../../Engine/Interfaces/iPropertyTableOwner.h"
#include "iTerrainZone.h"

namespace csdk {

//! SDK material layer definition structure.
struct sMeshLayerDefinition
{
	//! LOD distance set for the mesh layer
	float lod_distance;

    sMeshLayerDefinition()
    {
        lod_distance = 0.f;
    }
};


//====================================================

//! SDK interface to terrain editor mesh layer engine node.
class iTerrainMeshLayer: public iEditorLayer
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainMeshLayer"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain editor mesh layer"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to browse the per layer properties (for a specific zone).
	/*! \warning The returned interface is shared among calls. So if you call this function
	for a zone and then you call it again, the same interface pointer is used but it will
	reflect the properties for the second zone. */
	virtual iPropertyTableOwner* GetProperties(iTerrainZone* zone) = 0;

	//! Assign the road layer to the specified zone, linking it to the given road network interface.
	virtual t_error	Assign(iTerrainZone* zone) = 0;

	//! Clear the layer data from the specified zone
	virtual t_error	Clear(iTerrainZone* zone) = 0;

	//! Return the final editing result surface interface.
	virtual iGeomEntityTemplate* GetGeomEntityTemplate(iTerrainZone* zone) = 0;

	//! Return the mesh layer definition for the specified zone
	/*! The returned structure is temporary and should not be stored between calls.*/
	virtual const sMeshLayerDefinition* GetMeshLayerDefinition(iTerrainZone* zone) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/