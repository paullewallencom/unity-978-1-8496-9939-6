//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINWATERLAYER_H
#define __CSDK_ITERRAINWATERLAYER_H

#include "../../Editor/Interfaces/iEditorLayer.h"
#include "../../Engine/Interfaces/iPropertyTableOwner.h"
#include "iTerrainZone.h"

namespace csdk {

//====================================================

enum E_TERRAINWATERLAYER_TYPES
{
	C_TERRAINWATERLAYER_LAKE = 0,	//!< "Lake Water".
	C_TERRAINWATERLAYER_OCEAN	//!< "Ocean Water".
};

//! This structure specifies the defining parameters of a water layer
struct sTerrainWaterParams
{
	//! The type of the layer (see E_TERRAINWATERLAYER_TYPES).
	uint	type;

	//! The size of the water mask
	uint mask_size;

	//! Number of tiles for the water plane geometry.
	uint tiles_no;

	//! Water level (height from the zero ground).
	float water_level;

	//! The type-specific parameter structure (filled according to the water layer type)
	void* type_params;
};

//====================================================

//! How many textures we use to color the lake surface.
#define C_LAKE_COLORING_TEXTURES_NO	2

//! Structure to hold information about lake water colors.
struct sLakeWaterColorsParams
{
	//! Global water color (before applying reflection and lighting).
	t_float3 global_color;

	//! How much to use reflection and how much is the plain lighting color.
	float reflectivity;

	//! Color textures used to affect the lake surface.
	iImage *coloring_textures[C_LAKE_COLORING_TEXTURES_NO];
};

//! Structure to hold parameters about lake water lighting.
struct sLakeWaterLightingParams
{
	t_float3 ambient_color;
	t_float3 diffuse_color;
	t_float3 specular_color;

	//! Factor to be multiplied with the final specular color.
	float specular_shine;
	//! Power exponent used when computing the specular color.
	float specular_exp;
	//! Additional distortion applied to specular thru the bumps.
	float specular_distort;
	//! Additional distortion applied to the entire lighting normals thru the bumps.
	float light_perturb;
};

//! How many bump textures we use for distorting the lake water reflection, refraction, lighting.
#define C_LAKE_BUMPS_NO		2

//! Structure to hold parameters about lake water waves.
struct sLakeWaterWavesParams
{
	//! Bump textures to simulate waves (distort reflection, refraction and lighting).
	iImage *waves_bump_texs[C_LAKE_BUMPS_NO];

	//! Tiling used for the bump textures.
	t_float2 waves_tiling[C_LAKE_BUMPS_NO];

	//! The amount of distort the bumps are introducing.
	float waves_perturb[C_LAKE_BUMPS_NO];

	//! Speed of movement for the bump textures.
	float waves_speed[C_LAKE_BUMPS_NO];

	//! Direction of movement for the bump textures.
	t_float2 waves_dir[C_LAKE_BUMPS_NO];

	//! Waves texture spin rotation.
	float waves_rot[C_LAKE_BUMPS_NO];
};

//! Lake water params structure (found in sTerrainWaterParams::type_params).
struct sLakeWaterParams
{
	//! Color parameters.
	sLakeWaterColorsParams colors_params;

	//! Lighting parameters.
	sLakeWaterLightingParams lighting_params;

	//! Waves parameters.
	sLakeWaterWavesParams waves_params;
};

//====================================================

//! Ocean water params structure (found in sTerrainWaterParams::type_params).
struct sOceanWaterParams
{	
	//! Image node id for diffuse color
	iImage* diffuse_img;
	//! Image node id for shadow texture
	iImage* shadow_img;
};	

//====================================================

//! A point from a lake shoreline contour.
struct sLakeShorelinePoint
{
	//! Position of the point.
	t_float3 pos;

	//! Normal in this point (direction on which the waves are moving).
	t_float3 normal;
};

//! Possible stages for a lake water wave.
enum E_LAKE_WAVE_STAGE
{
	C_LAKE_WAVE_STAGE_START_OFFSHORE, //!< Wave is offshore and start entering towards the land.
	C_LAKE_WAVE_STAGE_ENTER_SHORE, //!< Wave is entering the shore line from offshore.
	C_LAKE_WAVE_STAGE_ENTER_ONSHORE, //!< Wave is entering the shore land from contour shoreline.
	C_LAKE_WAVE_STAGE_EXIT_ONSHORE, //!< Wave is exiting the land to the shoreline.
	C_LAKE_WAVE_STAGE_EXIT_SHORE, //!< Wave is exiting shore line and going offshore.
	C_LAKE_WAVE_STAGE_END_OFFSHORE, //!< Wave is offshore after exiting the shore line.
	C_LAKE_WAVE_STAGES_NO
};

//! Parameters for creating waves along a shoreline contour.
struct sLakeShorelineWaveSet
{
	//! Image to be used for the waves.
	iImage *texture;

	//! Random seed used when computing various random numbers for this wave set.
	/*! Use the same seed and for different wave sets to have the same random numbers in the same simulation pass. */
	uint random_seed;

	//! Controls how much the waves from this wave set are scattered.
	/*! This is between 0 (no scattering, only a single wave for the entire contour) to 1 (full scattering, that is each contour point is a wave). */
	float scattering_amount;

	//! Minimum rotation to be applied to the wave quads.
	float wave_rotation_min;
	//! Maximum rotation to be applied to the wave quads.
	float wave_rotation_max;

	//! A random minimum bias to be applied as gap between simulation steps.
	/*! Use the same value for gap_bias_min and gap_bias_max to have equal non-random gaps. */
	float gap_bias_min;
	//! A random maximum bias to be applied to the gap between simulation steps.
	/*! Use the same value for gap_bias_min and gap_bias_max to have equal non-random gaps. */
	float gap_bias_max;

	// Per stage settings.
	//! Min and maximum stage distances (in world units). 
	/*! C_LAKE_WAVE_STAGE_ENTER_SHORE and C_LAKE_WAVE_STAGE_EXIT_SHORE are always 0, since shoreline
	contour (the center) is taken as reference. Distances are always positive, while the direction changes. */
	float stage_dist[C_LAKE_WAVE_STAGES_NO][2];
	//! Min and maximum stage speed (units per second).
	float stage_speed[C_LAKE_WAVE_STAGES_NO][2];
	//! Min and maximum opacity (between 0 = full transparent and 1 = full opaque).
	float stage_opacity[C_LAKE_WAVE_STAGES_NO][2];
	//! Min and maximum wave length (units).
	float stage_length[C_LAKE_WAVE_STAGES_NO][2];
	//! Min and maximum wave width ratio compared with length.
	float stage_width_ratio[C_LAKE_WAVE_STAGES_NO][2];
};

//! Contour data for lake water type.
struct sLakeShoreContourData
{
	//! Points defining the contour.
	t_readonly_array<sLakeShorelinePoint> *points;

	//! Sets of waves (shifting textures) from the contour.
	t_readonly_array<sLakeShorelineWaveSet> *wave_sets;
};

//====================================================

//! SDK interface to terrain editor water layer engine node.
class iTerrainWaterLayer: public iEditorLayer
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainWaterLayer"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain editor water layer"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to browse the per layer properties (for a specific zone).
	/*! \warning The returned interface is shared among calls. So if you call this function
	for a zone and then you call it again, the same interface pointer is used but it will
	reflect the properties for the second zone. */
	virtual iPropertyTableOwner* GetProperties(iTerrainZone* zone) = 0;

	//! Return the water mask for a specified terrain zone into an allocated buffer.
	/*! This function copies the contents of the data assigned to the specified zone into the allocated buffer, supplied as parameter.
		The buffer must be large enough to store the data.
	*/
	virtual t_error	GetData(iTerrainZone* zone, uchar* buffer) = 0;

	//! Copy the water data to the specified zone layer.
	/*! This function copies the mask data from the buffer supplied as parameter to the layer data assigned to the specified zone.
		The buffer must hold enough data to fill the zone layer.
	*/
	virtual t_error	SetData(iTerrainZone* zone, const uchar* buffer) = 0;

	//! Get a single water mask value from this layer for the specified zone and texel.
	virtual uchar		GetValue(iTerrainZone* zone, csdk::uint u, csdk::uint v) = 0;

	//! Set a single water mask value from this layer for the specified zone and texel.
	virtual t_error	SetValue(iTerrainZone* zone, csdk::uint u, csdk::uint v, uchar value) = 0;

	//! Get the water parameters table for the specified zone.
	/*! \warning The returned pointer is reused between calls so you should not store the pointer for future usage. */
	virtual const sTerrainWaterParams* GetParameters(iTerrainZone* zone) = 0;

	// Shoreline data ======================================

	//! Return the number of contours for the shoreline.
	virtual uint GetShoreContoursNo(iTerrainZone* zone) = 0;

	//! Return the shoreline data.
	/*! The data is specific to water type (lake, ocean etc). See s*ShoreContourData for actual structures.
	\warning The returned pointer is reused between calls so you should not store the pointer for future usage. */
	virtual void* GetShoreContourData(iTerrainZone* zone, uint contour_index) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/