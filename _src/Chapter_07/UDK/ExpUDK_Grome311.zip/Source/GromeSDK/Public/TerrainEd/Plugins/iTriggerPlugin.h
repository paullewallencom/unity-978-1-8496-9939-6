//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief Terrain editing trigger plugins event constants.

	Copyright (C) 2008 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup EditorSDK Editor SDK */
/*@{*/

#ifndef __CSDK_TERRAINED_ITRIGGERPLUGIN_H
#define __CSDK_TERRAINED_ITRIGGERPLUGIN_H

#include "../../Editor/Plugins/iTriggerPlugin.h"

namespace csdk {

//====================================================
// NOT IMPLEMENTED !
// Terrain editor trigger ids (for iTerrainEd module):

// Terrain zones operations:

//! Called before a terrain zone is about to be created.
#define C_TRIGGERID_TERRAINZONE_BEFORE_CREATE		1
//! Called after a terrain zone is created.
#define C_TRIGGERID_TERRAINZONE_AFTER_CREATE			2
//! Called before a terrain zone is about to be deleted from scene.
#define C_TRIGGERID_TERRAINZONE_BEFORE_DELETE		3
//! Called after a terrain zone is deleted from scene.
#define C_TRIGGERID_TERRAINZONE_AFTER_DELETE			4
//! Called before a terrain zone is about to be swapped out to disk.
#define C_TRIGGERID_TERRAINZONE_BEFORE_SWAP			5
//! Called after a terrain zone is swapped out to disk.
#define C_TRIGGERID_TERRAINZONE_AFTER_SWAP			6
//! Called before a terrain zone is about to be unswapped from disk.
#define C_TRIGGERID_TERRAINZONE_BEFORE_UNSWAP	7
//! Called after a terrain zone is unswapped from disk.
#define C_TRIGGERID_TERRAINZONE_AFTER_UNSWAP		8

// Layers operations:

//! Called before a terrain layer is about to be created.
#define C_TRIGGERID_TERRAINLAYER_BEFORE_ADD			20
//! Called after a terrain layer is created.
#define C_TRIGGERID_TERRAINLAYER_AFTER_ADD			21
//! Called before a terrain layer is about to be deleted.
#define C_TRIGGERID_TERRAINLAYER_BEFORE_DELETE		22
//! Called after a terrain layer is deleted.
#define C_TRIGGERID_TERRAINLAYER_AFTER_DELETE		23
//! Called before a terrain layer is about to be assigned to selected zones.
#define C_TRIGGERID_TERRAINLAYER_BEFORE_ASSIGN	24
//! Called after a terrain layer is assigned to selected zones.
#define C_TRIGGERID_TERRAINLAYER_AFTER_ASSIGN		25
//! Called before a terrain layer is about to be cleared from selected zones.
#define C_TRIGGERID_TERRAINLAYER_BEFORE_CLEAR		26
//! Called after a terrain layer is cleared from selected zones.
#define C_TRIGGERID_TERRAINLAYER_AFTER_CLEAR			27
//! Called before a terrain layer is about to be disabled.
#define C_TRIGGERID_TERRAINLAYER_BEFORE_DISABLE	28
//! Called before a terrain layer is disabled.
#define C_TRIGGERID_TERRAINLAYER_AFTER_DISABLE		29
//! Called before a terrain layer is about to be marked in use or not.
#define C_TRIGGERID_TERRAINLAYER_BEFORE_USE			30
//! Called after a terrain layer is marked in use or not.
#define C_TRIGGERID_TERRAINLAYER_AFTER_USE				31
//! Called before a terrain layer is about to be moved to another position in stack.
#define C_TRIGGERID_TERRAINLAYER_BEFORE_MOVE		32
//! Called after a terrain layer is moved to another position in stack.
#define C_TRIGGERID_TERRAINLAYER_AFTER_MOVE			33

//====================================================
}; // namespace csdk
#endif
/*@}*/