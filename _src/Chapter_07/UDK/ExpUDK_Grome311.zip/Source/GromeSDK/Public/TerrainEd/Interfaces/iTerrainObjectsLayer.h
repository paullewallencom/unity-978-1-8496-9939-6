//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2011 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINOBJECTSLAYER_H
#define __CSDK_ITERRAINOBJECTSLAYER_H

#include "../../Editor/Interfaces/iEditorLayer.h"
#include "../../Engine/Interfaces/iPropertyTableOwner.h"
#include "../../ObjectEd/Interfaces/iObjectContainer.h"
#include "iTerrainZone.h"

namespace csdk {

//! SDK objects layer definition structure.
struct sObjectsLayerDefinition
{
	// Nothing included here for now.

    sObjectsLayerDefinition()
    {
    }
};

//====================================================

//! SDK interface to terrain editor objects layer engine node.
class iTerrainObjectsLayer: public iEditorLayer
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainObjectsLayer"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain editor objects layer"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to browse the per layer properties (for a specific zone).
	/*! \warning The returned interface is shared among calls. So if you call this function
	for a zone and then you call it again, the same interface pointer is used but it will
	reflect the properties for the second zone. */
	virtual iPropertyTableOwner* GetProperties(iTerrainZone* zone) = 0;

	//! Assign the objects layer to the specified zone, linking it to the given road network interface.
	virtual t_error	Assign(iTerrainZone* zone) = 0;

	//! Clear the layer data from the specified zone
	virtual t_error	Clear(iTerrainZone* zone) = 0;

	//! Return the objects layer definition for the specified zone
	/*! The returned structure is temporary and should not be stored between calls.*/
	virtual const sObjectsLayerDefinition* GetObjectsLayerDefinition(iTerrainZone* zone) = 0;

	//! Return the container with all the objects from this layer.
	/*! Returned interface should be closed (CloseInterface) by the user when no longer needed. */
	virtual iObjectContainer* GetObjectContainer(iTerrainZone* zone) = 0;

	//! Return the terrain zone associated with an objects container from this layer.
	/*! Returned interface should be closed (CloseInterface) by the user when no longer needed. */
	virtual iTerrainZone* GetObjectContainerZone(iObjectContainer* container) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/