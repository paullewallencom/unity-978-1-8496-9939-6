//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINDETAILSLAYER_H
#define __CSDK_ITERRAINDETAILSLAYER_H

#include "../../Editor/Interfaces/iEditorLayer.h"
#include "../../Engine/Interfaces/iPropertyTableOwner.h"
#include "iTerrainZone.h"

namespace csdk {

//====================================================

enum E_TERRAINDETAILLAYER_TYPES
{
	C_TERRAINDETAILLAYER_BILLBOARD = 0,	//! Billboard layer type (used to represent grass, etc)
	C_TERRAINDETAILLAYER_3DOBJECTS,			//! 3D Objects layer type
	C_TERRAINDETAILLAYER_TYPES_NO
};

//! These are generic indications of how the detail dynamic lighting should look (usually to match the underlaying surface).
enum E_TERRAINDETAILLAYER_LIGHTING
{
	C_DETAIL_LIGHTING_NONE = 0, //!< No lighting.
	C_DETAIL_LIGHTING_DIFFUSE, //!< Simple diffuse lighting.
	C_DETAIL_LIGHTING_SPECULAR, //!< Diffuse + specular highlights.
	C_DETAIL_LIGHTING_NO
};

//! Supported links of detail layers with other types of layers.
enum E_TERRAINDETAILLAYER_LINK 
{
	C_DETAIL_LINK_DIFFUSE = 0, //!< Detail layer link to a material layer for diffuse coloring.
	C_DETAIL_LINK_LIGHTMAP //!< Detail layer link to a lightmap layer.
};

//====================================================

//! This structure specifies the defining parameters of a detail layer
struct sTerrainDetailsParams
{
	//! The size of the density mask
	uint mask_size;

	//! Distance beyond which the details begin to fade out
	float fade_start;

	//! Distance beyond which the details are completely invisible
	float fade_end;

	//! The noise seed value
	uint	seed;

	//! Type of lighting
	E_TERRAINDETAILLAYER_LIGHTING lighting_mode;

	//! The type of the layer
	uint	type;

	//! The type-specific parameter structure (filled according to the detail layer type)
	void* type_params;
};

//! Billboard item structure
struct sBillboardItemParams
{
	//! Minimum possible size of the billboard in world units
	float min_size;
	//! Maximum possible size of the billboard in world units
	float max_size;
	//! The density of the objects specified by this item
	uint	density;
};

//! Billboard params structure
struct sBillboardParams
{
	//! The billboard texture
	iTexture* texture;
	//! Image node id for diffuse color
	iImage* diffuse_img;
	//! Image node id for shadow texture
	iImage* shadow_img;
	//! Vertical align of the texture.
	/*! Between 0.0 and 1.0 (1.0 = completely facing the camera). */
	float valign;

	//! Wind direction
	t_float3 wind_dir;
	//! Wind scaling.
	float wind_scale;
	//! Wind strength (maximum travel distance).
	float wind_strength;
	//! Wind speed
	float wind_speed;
	//! Minimum wind noise to make the blades not move synchronized (to create turbulences).
	float wind_min_noise;
	//! Maximum wind noise to make the blades not move synchronized (to create turbulences).
	float wind_max_noise;

	//! Maximum amplitude (distance) of the shaking (use zero to have this detail unaffected).
	float shake_amplitude;
	//! Speed of shaking.
	float shake_speed;
	//! Duration of shaking after the actor stop moving.
	float shake_duration;

	//!Billboard items no
	uint items_no;
	//! Billboard items
	sBillboardItemParams* items;
};

//! Detail object item structure
struct sDetailObjectItemParams
{
	//! Object
	iGeomEntityTemplate* object;

	//! Density
	uint density;

	//! Min scale factor
	float min_scale;

	//! Max scale factor
	float max_scale;
};

//! Detail object params structure
struct sDetailObjectParams
{	
	//! Image node id for diffuse color
	iImage* diffuse_img;
	//! Image node id for shadow texture
	iImage* shadow_img;
	//! Number of items
	uint items_no;
	//! Item list
	sDetailObjectItemParams* items;
};	

//====================================================

//! This structure specifies the defining parameters when assigning a detail layer to a zone (iTerrainDetailsLayer::Assign).
struct sTerrainDetailsDefinition
{
	//! The size of the density mask
	uint mask_size;

	//! Distance beyond which the details begin to fade out
	float fade_start;

	//! Distance beyond which the details are completely invisible
	float fade_end;

	//! The noise seed value
	uint	seed;

	//! Type of lighting
	E_TERRAINDETAILLAYER_LIGHTING lighting_mode;

	//! The type of the layer
	uint	type;

	//! The type-specific parameter structure (filled according to the detail layer type).
	/*! For now this can be either sBillboardDefinition or sDetailObjectDefinition. */
	void* type_params;
};

//! Billboard item definition structure
struct sBillboardItemDefinition
{
	//! Minimum possible size of the billboard in world units
	float min_size;
	//! Maximum possible size of the billboard in world units
	float max_size;
	//! The density of the objects specified by this item
	uint	density;
};

//! Billboard definition structure
struct sBillboardDefinition
{
	//! The billboard image
	iImage* texture_image;
	//! Vertical align of the texture.
	/*! Between 0.0 and 1.0 (1.0 = completely facing the camera). */
	float valign;

	//! Wind direction
	t_float3 wind_dir;
	//! Wind scaling.
	float wind_scale;
	//! Wind strength (maximum travel distance).
	float wind_strength;
	//! Wind speed
	float wind_speed;
	//! Minimum wind noise to make the blades not move synchronized (to create turbulences).
	float wind_min_noise;
	//! Maximum wind noise to make the blades not move synchronized (to create turbulences).
	float wind_max_noise;

	//! Maximum amplitude (distance) of the shaking (use zero to have this detail unaffected).
	float shake_amplitude;
	//! Speed of shaking.
	float shake_speed;
	//! Duration of shaking after the actor stop moving.
	float shake_duration;

	//!Billboard items no
	uint items_no;
	//! Billboard items
	sBillboardItemDefinition* items;
};

//! Detail object item definition structure
struct sDetailObjectItemDefinition
{
	//! Object
	iGeomEntityTemplate* object;

	//! Density
	uint density;

	//! Min scale factor
	float min_scale;

	//! Max scale factor
	float max_scale;
};

//! Detail object definition structure
struct sDetailObjectDefinition
{	
	//! Number of items
	uint items_no;
	//! Item list
	sDetailObjectItemDefinition* items;
};	

//====================================================

//! SDK interface to terrain editor details layer engine node.
class iTerrainDetailsLayer: public iEditorLayer
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainDetailsLayer"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain editor details layer"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to browse the per layer properties (for a specific zone).
	/*! \warning The returned interface is shared among calls. So if you call this function
	for a zone and then you call it again, the same interface pointer is used but it will
	reflect the properties for the second zone. */
	virtual iPropertyTableOwner* GetProperties(iTerrainZone* zone) = 0;

	//! Return the detail density data for a specified terrain zone into an allocated buffer.
	/*! This function copies the contents of the data assigned to the specified zone into the allocated buffer, supplied as parameter.
		The buffer must be large enough to store the data.
	*/
	virtual t_error GetData(iTerrainZone* zone, uchar* buffer) = 0;

	//! Copy the detail density data to the specified zone layer.
	/*! This function copies the density mask data from the buffer supplied as parameter to the layer data assigned to the specified zone.
		The buffer must hold enough data to fill the zone layer.
	*/
	virtual t_error SetData(iTerrainZone* zone, const uchar* buffer) = 0;

	//! Get a single detail density value from this layer for the specified zone and mask texel.
	virtual uchar GetValue(iTerrainZone* zone, uint u, uint v) = 0;

	//! Set a single detail density value from this layer for the specified zone and mask texel.
	virtual t_error SetValue(iTerrainZone* zone, uint u, uint v, uchar value) = 0;

	//! Get the detail parameters table for the specified zone
	virtual const sTerrainDetailsParams* GetParameters(iTerrainZone* zone) = 0;

	//! Assign a detail layer to a terrain zone.
	virtual t_error Assign(iTerrainZone* zone, sTerrainDetailsDefinition* definition) = 0;

	//! Link the detail layer to another layer.
	/*! This (for now) is used to link the detail layer coloring to another material layer (for diffuse coloring or lightmap). */
	virtual t_error Link(iEditorLayer *layer, E_TERRAINDETAILLAYER_LINK link) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/