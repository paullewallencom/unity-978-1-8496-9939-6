//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINMATERIALLAYER_H
#define __CSDK_ITERRAINMATERIALLAYER_H

#include "../../Editor/Interfaces/iEditorLayer.h"
#include "../../Engine/Interfaces/iTexture.h"
#include "../../Engine/Interfaces/iPropertyTableOwner.h"
#include "iTerrainZone.h"

namespace csdk {

//! Commonly used  texture channel ids for terrain materials
#define C_TEX_CHANNEL_MASK			0
#define C_TEX_CHANNEL_TEXTURE		1

//! SDK texture mapping structure used by the texture channel.
/*!
scale, rotation and offset members is all you need to construct the necessary texture generation matrix 
(and planes) to obtain the texture matrix from the vertex positions.

texgen_planes and tex_matrix are precomputed values for the texture generation planes and 
matrix in case you are using a right handed coordinate system with fixed pipeline. 
The planes are used for horizontal and vertical mapping while the texture matrix is used to apply 
scaling and spinning (rotation.y). 

In case you are using a different coordinate system or you need just one texture matrix to be
multiplied with the vertex positions to obtain the texture coordinates, you must use
scale, rotation and offset members to construct that matrix.
*/
struct sTextureMapping
{
	//! Texture scale.
	/*! If rotation.x and rotation.y are present (there is a custom orientation), the scaling is in world space
	(because when rotations are used the vertex coordinates positions are used to automatically generate the 
	texture coordinates which are in world space). If rotation.x and rotation.y are zero (the mapping is horizontal), 
	the scale represent the tiling in texture space (1 represents the entire terrain zone, 2 texture is tiled twice etc). */
	t_float3 scale;

	//! Texture rotation (X and Z are horizontal and vertical rotation, while Y is the spin).
	t_float3 rotation;

	//! Texture offset (in X and Y, Z is to be ignored).
	t_float3 offset;

	// =============================
	// Right handed precomputed values:

	//! Texture generation planes in case we are using texture mapping rotation.
	/*! This member contains 2 planes. Texture U coordinate is obtained
	by multiplying the vertex position with the first plane and V by multiplying it with the second.
	Not used when assigning the material (we are computing them from rotation). 
	Used only when obtaining the texture channels. */
	t_float4 texgen_planes[2];

	//! Texture matrix (only when getting data, ignored when setting the texture mapping)
	/*! This matrix is obtained from the scaling and the spinning. */
	t_float4x4 tex_matrix;

};

//! SDK texture channel structure used by the material definition structure
struct sTextureChannel
{
	//! The channel id.
	uint id;

	//! Interface to an opened  texture.
	/*! On input (at iMaterialLayer::Assign) this texture is internally duplicated after assignment so it should
	be freed on return if no longer used. On output (at iMaterialLayer::GetTextureChannel) this contain an interface
	to the internal layer texture and cannot be freed with SDK calls. */
	iTexture* source;

	//! The width of the new texture (if interface not present)
	uint width;

	//! The height of the new texture (if interface not present)
	uint height;

	//! The color of the new texture (if interface not present)
	t_float4 color;

	//! Texture mapping (if not present, defaults are used)
	sTextureMapping* mapping;

	sTextureChannel()
	{
		id = 0;
		source = NULL;
		mapping = NULL;
		width = 0;
		height = 0;
	}
};

//! SDK material layer definition structure.
struct sMaterialDefinition
{
	//! Material name
	t_char* name;

	//! Number of channels provided
	uint		channels_no;

	//! List of texture channels
	sTextureChannel* channels;

	//! Custom property table of the material.
	/*! The structure of this property table depends on the material. NULL if the material
	doesn't have custom properties (the most common case). */
	iPropertyTable *properties;

	sMaterialDefinition()
	{
		name = NULL;
		channels_no = 0;
		channels = NULL;
		properties = NULL;
	}
};

//====================================================

//! SDK interface to terrain editor engine node.
class iTerrainMaterialLayer: public iEditorLayer
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainMaterialLayer"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain editor material layer"; }
	
	// [ Custom interface ]===================================

	//! Return the interface to browse the per layer properties (for a specific zone).
	/*! \warning The returned interface is shared among calls. So if you call this function
	for a zone and then you call it again, the same interface pointer is used but it will
	reflect the properties for the second zone. */
	virtual iPropertyTableOwner* GetProperties(iTerrainZone* zone) = 0;

	//! Assign the material specified by the material definition to the zone.
	virtual t_error	Assign(iTerrainZone* zone, sMaterialDefinition* material) = 0;

	//! Clear the layer data from the specified zone
	virtual t_error	Clear(iTerrainZone* zone) = 0;

	//! Get the material definition which has been previously assigned to the specified zone.
	/*!	\param zone The zone containing the material data to be retrieved.
		\return The full material definition for the material data assigned to the zone. The definition contains all the texture channels required by the material.
		\warning The returned structure is reused between calls. So a new GetMaterial call will destroy the previous 
		call structure. For future uses you need to copy the structure (referring any interfaces contained in the structure)
		or to remake the same call to GetMaterial. */
	virtual const sMaterialDefinition* GetMaterial(iTerrainZone* zone) = 0;

	//! Get the texture channel for a material currently assigned to the specified zone
	/*!	\param zone The zone containing the material data to be retrieved.
		\param channel The index of the requested channel.
		\return The texture channel definition structure  for the material assigned to the zone, if the layer has material data for this zone, and NULL otherwise.
	*/
	virtual const sTextureChannel* GetTextureChannel(iTerrainZone* zone, const uint channel) = 0;

	//! Return the pixels buffer from the material currently assigned to the specified zone for the given texture channel 
	/*!	\param zone The zone containing the material assigned for this layer.
		\param channel The index of the channel containing the texture to be modified.
		\param px The starting position of the pixel buffer on horizontal
		\param py The starting position of the pixel buffer on vertical
		\param dx The horizontal size of the pixel buffer.
		\param dy The vertical size of the pixel buffer.
		\param buffer The pixel buffer to receive the data from the channel texture. The data format is interpreted as unsigned byte and the pixel format is
		given by the internal texture format of the texture channel. The buffer must be large enough to store the pixels at the specified format and data type.
	*/	
	virtual t_error GetPixels(iTerrainZone* zone, const uint channel, const uint px, const uint py, const uint dx, const uint dy, uchar* buffer) = 0;

	//! Copy the pixels from the buffer into the texture from the  channel id of the material assigned to the zone.
	/*!	\param zone The zone containing the material assigned for this layer.
		\param channel The index of the channel containing the texture to be modified.
		\param px The starting position of the pixel buffer on horizontal
		\param py The starting position of the pixel buffer on vertical
		\param dx The horizontal size of the pixel buffer.
		\param dy The vertical size of the pixel buffer.
		\param buffer The pixel buffer to be copied into the channel texture. The data format is interpreted as unsigned byte.
		\warning The pixel format of the buffer must match the internal pixel format of the texture from the texture channel.
	*/	
	virtual t_error SetPixels(iTerrainZone* zone, const uint channel, const uint px, const uint py, const uint dx, const uint dy,  uchar* buffer) = 0;

	//! Return the texture mapping from a zone for a texture channel given the x, z index of the vertex.
	/*!	\param zone The zone containing material data from this layer.
		\param channel The material texture channel index to retrieve the mapping from.
		\param vert_x Vertex OX index.
		\param vert_z Vertex OZ index.s
		\return The texture mapping (UV) of the vertex on that color layer. NULL if an error occurs (like invalid parameters).
		\warning Returned pointer may be temporary and should not be stored.
	*/
	virtual const t_float2* GetTextureUVMap(iTerrainZone* zone, const uint channel, const uint vert_x, const uint vert_z) = 0;

	//! Return the texture mapping buffer from a zone for the specified texture channel.
	/*! 
		\param zone The zone containing material data from this layer.
		\param channel The material texture channel index to retrieve the mapping from.
		\param o_texmap Previously allocated array to contain the texmap. The allocation size should be at least (zone X TilesNo + 1) * (zone Z TilesNo + 1) * sizeof(csdk::t_float2)
	*/
	virtual t_error GetTextureUVMap(iTerrainZone* zone, const uint channel, t_float2 *o_texmap) = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/