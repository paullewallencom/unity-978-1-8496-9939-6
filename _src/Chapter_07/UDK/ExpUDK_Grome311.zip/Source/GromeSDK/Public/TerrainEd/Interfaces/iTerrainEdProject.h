//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2007 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINEDPROJECT_H
#define __CSDK_ITERRAINEDPROJECT_H

#include "iTerrainZone.h"

namespace csdk {

//====================================================

//! SDK interface to terrain editor engine node.
/*! This is a subinterface of iEdProject and expose the terrain editing interface. */
class iTerrainEdProject: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainEdProject"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain editor project"; }

	//! Return an array with all the terrain zones from this project.
	/*! You can use this array to enumerate all the terrain zones from this project.
	Terrain zones contain the editing layers and also the final terrain surface information. 
	For more details refer to \c iTerrainZone. 
	When the interfaces are no longer used call CloseInterface on each of them
	(or use gCloseInterfaces on the entire array). */
	virtual t_readonly_array<iTerrainZone*>* GetTerrainZones() = 0;

};

//====================================================
} // namespace csdk
#endif
/*@}*/