//====================================================
/* Core SDK - QUAD Software */
/*! 
	\file 
	\brief 

	Copyright (C) 2006-2010 Quad Software
	This software is provided 'as-is', without any express or implied warranty.  In no event 
	will Quad Software be held liable for any damages arising from the use of this software.
*/
//====================================================
/*! \addtogroup TerrainEdSDK Terrain Editor SDK */
/*@{*/

#ifndef __CSDK_ITERRAINZONE_H
#define __CSDK_ITERRAINZONE_H

#include "../../Engine/Interfaces/iGeomEntityTemplate.h"
#include "../../ObjectEd/Interfaces/iObjectContainer.h"
#include "../../Editor/Interfaces/iEditorLayer.h"

namespace csdk {

//====================================================

// Snapshot flags (used for iTextureZone::Snapshot).
#define F_ZONE_SNAPSHOT_CLEAR	(1<<0)	//!< This flag indicates wether the zone snapshot method should clear the image or not
#define F_ZONE_SNAPSHOT_VFLIP	(1<<1)	//!< Flip the zone vertically when taking its snapshot (as seen from top view)
#define F_ZONE_SNAPSHOT_HFLIP	(1<<2)	//!< Flip the zone horizontally when taking the snapshot (as seen from top view)
#define F_ZONE_SNAPSHOT_LIT			(1<<3)	//!< Leave lighting on if present.

//====================================================

//! SDK interface to a terrain zone.
/*! 
As geometry, a terrain zone is a square grid of vertices elevated on OY. The pivot is in the center of the zone 
and the grid is spreading on OX and OZ axes. Every square from the grid is called a tile. You can access the
zone dimensions (in tiles per OX and OZ, for now both with the same value), the size of a tile (the same
size for all the tiles), the position of the zone center and the heightmap (elevations on OY). 

You can also have access to the raw data of the geometrical surface (surface template and its instance) to get vertex
attributes (positions, normals, colors, texture coordinates). For this you use GetGeomEntityTemplate and 
GetGeomEntityInstance to get the geometry template and its unique instance associated with the terrain zone.

You also have access to the objects residing (linked to) on the terrain zone (part of an object container). See
\c iTerrainZone::GetObjectContainer and \c iObjectContainer for more details. 

\warning Some functions will not operate if the zone is swapped. You must unswap (load) the zone to memory
to access all its data.
*/
class iTerrainZone: public iSdkInterface
{
public:

	//! Interface type string for this interface (the type id can be obtained with this as parameter to iRootInterface::GetTypeId).
	static const char* TypeString() { return "iTerrainZone"; }

	//! Return the long name (the description) of the interface (or the entity supporting this interface).
	virtual const char* Description() { return "Terrain zone interface"; }
	
	// [ Custom interface ]===================================

	//! Indicate if the terrain zone is selected (in editing application).
	virtual t_bool IsSelected() = 0;

	//! Return the geometry template interface containing the geometric representation of the zone.
	/*! You can also use OpenSubinterface to obtain this interface.
	Call CloseInterface when the interface is no longer needed. 
	\warning This interface is not available If this zone is swapped. */
	virtual iGeomEntityTemplate* GetGeomEntityTemplate() = 0;

	//! Return the geometry instance interface containing the geometric representation of the zone.
	/*! You can also use OpenSubinterface to obtain this interface.
	Call CloseInterface when the interface is no longer needed. 
	\warning This interface is not available If this zone is swapped. */
	virtual iGeomEntityInstance* GetGeomEntityInstance() = 0;

	//! Return the transformation matrix for the terrain zone.
	/*! This matrix is the same as the terrain surface instance transformation matrix. For now the terrain
	zone have only translation. The translation part of the matrix represents the zone center position. */
	virtual const t_float4x4* GetTransformMatrix() = 0;

	//! Return width of the terrain zone in tiles no.
	/*! \warning This function returns 0 if the zone is swapped. */
	virtual uint GetXTilesNo() = 0;
	//! Return height of the terrain zone in tiles no.
	/*! \warning This function returns 0 if the zone is swapped. */
	virtual uint GetZTilesNo() = 0;

	//! Return the size of a x tile in engine internal units.
	/*! \warning This function returns 0 if the zone is swapped. */
	virtual float GetXTileSize() = 0;
	//! Return the size of a y tile in engine internal units.
	/*! \warning This function returns 0 if the zone is swapped. */
	virtual float GetZTileSize() = 0;

	//! Return the terrain zone bounding box (axis aligned).
	/*! This is the same bounding box as that exposed by the zone geometry entity (iGeomEntity::GetBBox).
	The difference is that, when the zone is swapped, the geometry entity is not available, but this function
	will still return the zone bounding box. */
	virtual const t_float3* GetBBox() = 0;

	//! Return the final heightmap of the zone.
	/*! The returned heightmap is for (tiles_no+1)*(tiles_no+1) vertices. 
	\warning The memory may be temporary 	and the pointer should not be stored for later use. 
	\warning The returned array is shared among calls and should be stored / used immediately before 
	any other call to GetHeightmap (on any other zone). 
	\warning The heightmap is not available if the zone is swapped. */
	virtual const float* GetHeightmap() = 0;

	//! Return the list of layers of the specified type which have been assigned to this zone.
	/*! The method returns a list of layers currently assigned to the zone. The layer order in the list is 0 = bottommost layer in its stack.
		\param type The type string of the layers to be retrieved.
		\warning The list is temporary and it may be reused across multiple method calls.
		\warning The layers are not available if the zone is swapped (the function returns NULL). */
	virtual t_readonly_array<csdk::iEditorLayer*>* GetAssignedLayers(const char* type) = 0;

	//! Return the global container with objects linked to the terrain zone.
	/*! Objects may also belong to this zone but they are organized per layers. These layered objects are not contained
	in this container. They need to be obtained from the layer interfaces (see iTerrainObjectsLayer).
	Call CloseInterface when the interface is no longer needed.
	\warning The object container is not available if the zone is swapped. */
	virtual iObjectContainer* GetObjectContainer() = 0;

	//! Select or deselect a terrain zone (in the editing application).
	virtual t_error Select(const t_bool select) = 0;

	//! Take a snapshot of the terrain into the given image, with respect to the image's placement in world space, given as a min-max bbox.
	virtual t_error Snapshot(iImage* image, const t_float3& min, const t_float3& max, int32 flags) = 0;

	//! Test if a shape file intersects (lay on top as seen from above) this zone (plus an extent on the border).
	/*! \param shape_file_name Complete path to the shape file.
	\param border_extent World unit with which to extend the zone boundaries when doing the test. Use a positive value to intersect with 
	shapes that are outside the zone but at a distance smaller than border_extent (this is useful when you apply various filtering effects on the
	shape, like blurring, and you want to test if the result of blurring is intersecting the terrain zone). */
	virtual t_bool IntersectShape(const t_char *shape_file_name, const float border_extent = 0) = 0;

	//! Test if the zone contains data for the specified layer
	virtual t_bool HasLayer(iEditorLayer* layer) = 0;
};

//====================================================
} // namespace csdk
#endif
/*@}*/