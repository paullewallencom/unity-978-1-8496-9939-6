OgreCollada SDK v0.1a
---------------------

http://ogrecollada.sourceforge.net

If you get an error message upon running the ColladaViewer about an incorrect configuration then you need to download and install the Microsoft Visual C++ 2008 Redistributable Package in order to run the ColladaViewer.

You can download the 32bit redistributable package here: http://www.microsoft.com/downloads/details.aspx?FamilyID=9b2da534-3e03-4391-8a4d-074b9f2bc1bf&displaylang=en

You can download the 64bit redistributable package here: http://www.microsoft.com/downloads/details.aspx?familyid=BD2A6171-E2D6-4230-B809-9A8D7548C1B6&displaylang=en